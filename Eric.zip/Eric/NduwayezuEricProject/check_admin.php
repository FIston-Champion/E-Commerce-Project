<?php
require_once 'config.php';

echo "<h1>Admin Account Checker & Fixer</h1>";
echo "<style>
body { font-family: Arial, sans-serif; padding: 2rem; background: #f5f5f5; }
.success { background: #d4edda; border: 1px solid #c3e6cb; padding: 1rem; margin: 1rem 0; border-radius: 5px; color: #155724; }
.error { background: #f8d7da; border: 1px solid #f5c6cb; padding: 1rem; margin: 1rem 0; border-radius: 5px; color: #721c24; }
.info { background: #d1ecf1; border: 1px solid #bee5eb; padding: 1rem; margin: 1rem 0; border-radius: 5px; color: #0c5460; }
.code { background: #f4f4f4; padding: 0.5rem; border-radius: 3px; font-family: monospace; }
button { background: #007bff; color: white; padding: 1rem 2rem; border: none; border-radius: 5px; cursor: pointer; font-size: 1rem; margin: 0.5rem; }
button:hover { background: #0056b3; }
</style>";

// Check if admin exists
$check_sql = "SELECT * FROM users WHERE email = 'admin@artisanmarket.com'";
$result = $conn->query($check_sql);

if ($result->num_rows === 0) {
    echo "<div class='error'>";
    echo "<h2>❌ Admin Account NOT Found!</h2>";
    echo "<p>The admin account doesn't exist in the database.</p>";
    echo "</div>";
    
    echo "<div class='info'>";
    echo "<h3>🔧 Fix: Create Admin Account</h3>";
    echo "<form method='POST'>";
    echo "<button type='submit' name='create_admin'>Create Admin Account</button>";
    echo "</form>";
    echo "</div>";
    
    if (isset($_POST['create_admin'])) {
        $password_hash = password_hash('admin123', PASSWORD_DEFAULT);
        $insert_sql = "INSERT INTO users (full_name, email, password, user_type, status, created_at) 
                      VALUES ('Admin User', 'admin@artisanmarket.com', ?, 'admin', 'active', NOW())";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("s", $password_hash);
        
        if ($stmt->execute()) {
            echo "<div class='success'>";
            echo "<h2>✅ Admin Account Created Successfully!</h2>";
            echo "<p><strong>Email:</strong> admin@artisanmarket.com</p>";
            echo "<p><strong>Password:</strong> admin123</p>";
            echo "<p><a href='admin_login.php'>Go to Admin Login</a></p>";
            echo "</div>";
        } else {
            echo "<div class='error'>Error creating admin: " . $stmt->error . "</div>";
        }
    }
} else {
    $admin = $result->fetch_assoc();
    
    echo "<div class='success'>";
    echo "<h2>✅ Admin Account Found!</h2>";
    echo "<p><strong>ID:</strong> {$admin['id']}</p>";
    echo "<p><strong>Name:</strong> {$admin['full_name']}</p>";
    echo "<p><strong>Email:</strong> {$admin['email']}</p>";
    echo "<p><strong>User Type:</strong> {$admin['user_type']}</p>";
    echo "<p><strong>Status:</strong> {$admin['status']}</p>";
    echo "</div>";
    
    // Test password
    echo "<div class='info'>";
    echo "<h3>🔍 Testing Password</h3>";
    
    $test_password = 'admin123';
    $stored_hash = $admin['password'];
    
    echo "<p><strong>Testing password:</strong> <span class='code'>admin123</span></p>";
    echo "<p><strong>Stored hash:</strong> <span class='code'>" . substr($stored_hash, 0, 50) . "...</span></p>";
    
    if (password_verify($test_password, $stored_hash)) {
        echo "<div class='success'>";
        echo "<h3>✅ Password is CORRECT!</h3>";
        echo "<p>The password 'admin123' works with the stored hash.</p>";
        echo "<p><strong>This means:</strong> Your password should work for login!</p>";
        echo "<p><a href='admin_login.php'>Try Admin Login Now</a></p>";
        echo "</div>";
    } else {
        echo "<div class='error'>";
        echo "<h3>❌ Password Does NOT Match!</h3>";
        echo "<p>The password 'admin123' does NOT match the stored hash.</p>";
        echo "<p><strong>This is why you're getting 'Invalid password' error!</strong></p>";
        echo "</div>";
        
        echo "<div class='info'>";
        echo "<h3>🔧 Fix Options:</h3>";
        
        // Option 1: Reset password
        echo "<form method='POST'>";
        echo "<h4>Option 1: Reset Password to 'admin123'</h4>";
        echo "<button type='submit' name='reset_password'>Reset Password</button>";
        echo "</form>";
        
        // Option 2: Delete and recreate
        echo "<form method='POST'>";
        echo "<h4>Option 2: Delete & Recreate Admin Account</h4>";
        echo "<button type='submit' name='recreate_admin' style='background: #dc3545;'>Delete & Recreate</button>";
        echo "</form>";
        echo "</div>";
    }
    
    // Handle password reset
    if (isset($_POST['reset_password'])) {
        $new_hash = password_hash('admin123', PASSWORD_DEFAULT);
        $update_sql = "UPDATE users SET password = ? WHERE email = 'admin@artisanmarket.com'";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("s", $new_hash);
        
        if ($stmt->execute()) {
            echo "<div class='success'>";
            echo "<h2>✅ Password Reset Successfully!</h2>";
            echo "<p><strong>New Password:</strong> admin123</p>";
            echo "<p><a href='admin_login.php'>Try Login Now</a></p>";
            echo "</div>";
            echo "<script>setTimeout(function(){ window.location.href='admin_login.php'; }, 2000);</script>";
        } else {
            echo "<div class='error'>Error resetting password: " . $stmt->error . "</div>";
        }
    }
    
    // Handle recreate
    if (isset($_POST['recreate_admin'])) {
        // Delete old
        $delete_sql = "DELETE FROM users WHERE email = 'admin@artisanmarket.com'";
        $conn->query($delete_sql);
        
        // Create new
        $new_hash = password_hash('admin123', PASSWORD_DEFAULT);
        $insert_sql = "INSERT INTO users (full_name, email, password, user_type, status, created_at) 
                      VALUES ('Admin User', 'admin@artisanmarket.com', ?, 'admin', 'active', NOW())";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("s", $new_hash);
        
        if ($stmt->execute()) {
            echo "<div class='success'>";
            echo "<h2>✅ Admin Account Recreated!</h2>";
            echo "<p><strong>Email:</strong> admin@artisanmarket.com</p>";
            echo "<p><strong>Password:</strong> admin123</p>";
            echo "<p><a href='admin_login.php'>Try Login Now</a></p>";
            echo "</div>";
            echo "<script>setTimeout(function(){ window.location.href='admin_login.php'; }, 2000);</script>";
        } else {
            echo "<div class='error'>Error recreating admin: " . $stmt->error . "</div>";
        }
    }
}

echo "<hr>";
echo "<div class='info'>";
echo "<h3>💡 Common Issues & Solutions:</h3>";
echo "<ul>";
echo "<li><strong>Issue:</strong> Password hash is incorrect<br><strong>Solution:</strong> Click 'Reset Password' button above</li>";
echo "<li><strong>Issue:</strong> Typing password wrong<br><strong>Solution:</strong> Make sure to type exactly: <span class='code'>admin123</span> (lowercase, no spaces)</li>";
echo "<li><strong>Issue:</strong> Email is wrong<br><strong>Solution:</strong> Use exactly: <span class='code'>admin@artisanmarket.com</span></li>";
echo "<li><strong>Issue:</strong> Old hash from database.sql<br><strong>Solution:</strong> Click 'Reset Password' to create fresh hash</li>";
echo "</ul>";
echo "</div>";

echo "<div class='info'>";
echo "<h3>🔒 About Password Hashing:</h3>";
echo "<p>Passwords are stored as <strong>hashes</strong> for security. Each time you hash 'admin123', you get a different hash string, but they all verify correctly.</p>";
echo "<p>The old hash from database.sql might not work on your system due to PHP version differences.</p>";
echo "<p><strong>Solution:</strong> Generate a fresh hash using the buttons above!</p>";
echo "</div>";
?>