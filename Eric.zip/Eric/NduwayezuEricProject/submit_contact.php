<?php
// Include database configuration
require_once 'config.php';

// Set header for JSON response
header('Content-Type: application/json');

// Initialize response array
$response = [
    'success' => false,
    'message' => 'An error occurred',
    'errors' => []
];

// Check if request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $response['message'] = 'Invalid request method';
    echo json_encode($response);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    $response['message'] = 'Invalid input data';
    echo json_encode($response);
    exit;
}

// Validate and sanitize input
$errors = [];
$data = [];

// First Name
if (empty($input['first_name'])) {
    $errors['first_name'] = 'First name is required';
} else {
    $data['first_name'] = clean_input($input['first_name']);
    if (strlen($data['first_name']) < 2) {
        $errors['first_name'] = 'First name must be at least 2 characters';
    }
}

// Last Name
if (empty($input['last_name'])) {
    $errors['last_name'] = 'Last name is required';
} else {
    $data['last_name'] = clean_input($input['last_name']);
    if (strlen($data['last_name']) < 2) {
        $errors['last_name'] = 'Last name must be at least 2 characters';
    }
}

// Email
if (empty($input['email'])) {
    $errors['email'] = 'Email is required';
} else {
    $data['email'] = clean_input($input['email']);
    if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
}

// Phone (optional)
if (!empty($input['phone'])) {
    $data['phone'] = clean_input($input['phone']);
    // Basic phone validation
    if (!preg_match('/^[\d\s\-\+\(\)]{10,20}$/', $data['phone'])) {
        $errors['phone'] = 'Invalid phone number format';
    }
} else {
    $data['phone'] = null;
}

// Subject
if (empty($input['subject'])) {
    $errors['subject'] = 'Subject is required';
} else {
    $data['subject'] = clean_input($input['subject']);
}

// Message
if (empty($input['message'])) {
    $errors['message'] = 'Message is required';
} else {
    $data['message'] = clean_input($input['message']);
    if (strlen($data['message']) < 10) {
        $errors['message'] = 'Message must be at least 10 characters';
    }
}

// Check for validation errors
if (!empty($errors)) {
    $response['message'] = 'Please fix the validation errors';
    $response['errors'] = $errors;
    echo json_encode($response);
    exit;
}

// Get IP address
$ip_address = $_SERVER['REMOTE_ADDR'];

try {
    // Prepare SQL statement
    $sql = "INSERT INTO contact_messages (first_name, last_name, email, phone, subject, message, status, created_at, ip_address) 
            VALUES (?, ?, ?, ?, ?, ?, 'unread', NOW(), ?)";
    
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    
    // Bind parameters
    $stmt->bind_param(
        "sssssss",
        $data['first_name'],
        $data['last_name'],
        $data['email'],
        $data['phone'],
        $data['subject'],
        $data['message'],
        $ip_address
    );
    
    // Execute the statement
    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = 'Thank you for your message! We will get back to you within 24 hours.';
        $response['message_id'] = $stmt->insert_id;
        
        // Send email notification (optional)
        sendContactNotification($data);
    } else {
        throw new Exception("Failed to execute statement: " . $stmt->error);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    $response['message'] = 'An error occurred while saving your message. Please try again later.';
    // Log the error for debugging (remove in production)
    error_log("Contact form error: " . $e->getMessage());
}

// Close database connection
$conn->close();

// Return JSON response
echo json_encode($response);

// Function to send email notification
function sendContactNotification($data) {
    $to = "admin@artisanmarket.com"; // Change to your admin email
    $subject = "New Contact Form Submission: " . $data['subject'];
    
    $message = "
    <html>
    <head>
        <title>New Contact Message</title>
    </head>
    <body>
        <h2>New Contact Form Submission</h2>
        <table border='1' cellpadding='10' cellspacing='0'>
            <tr>
                <th>Field</th>
                <th>Value</th>
            </tr>
            <tr>
                <td><strong>Name</strong></td>
                <td>{$data['first_name']} {$data['last_name']}</td>
            </tr>
            <tr>
                <td><strong>Email</strong></td>
                <td>{$data['email']}</td>
            </tr>
            <tr>
                <td><strong>Phone</strong></td>
                <td>" . ($data['phone'] ?: 'Not provided') . "</td>
            </tr>
            <tr>
                <td><strong>Subject</strong></td>
                <td>{$data['subject']}</td>
            </tr>
            <tr>
                <td><strong>Message</strong></td>
                <td>" . nl2br(htmlspecialchars($data['message'])) . "</td>
            </tr>
            <tr>
                <td><strong>Submitted At</strong></td>
                <td>" . date('Y-m-d H:i:s') . "</td>
            </tr>
            <tr>
                <td><strong>IP Address</strong></td>
                <td>{$_SERVER['REMOTE_ADDR']}</td>
            </tr>
        </table>
    </body>
    </html>
    ";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: Artisan Market <noreply@artisanmarket.com>" . "\r\n";
    $headers .= "Reply-To: {$data['email']}" . "\r\n";
    
    // Uncomment to send email
    // mail($to, $subject, $message, $headers);
}
?>