<?php
require_once 'config.php';

if (!is_logged_in() || !is_admin()) {
    redirect('admin_login.php');
}

$user_id = (int)$_GET['id'];
$success = '';
$error = '';

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $full_name = clean_input($_POST['full_name']);
    $email = clean_input($_POST['email']);
    $user_type = clean_input($_POST['user_type']);
    $status = clean_input($_POST['status']);
    $phone = clean_input($_POST['phone']);
    
    // Check if email already exists for another user
    $check_sql = "SELECT id FROM users WHERE email = ? AND id != ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("si", $email, $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $error = "Email already exists for another user!";
    } else {
        $update_sql = "UPDATE users SET full_name = ?, email = ?, user_type = ?, status = ?, phone = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("sssssi", $full_name, $email, $user_type, $status, $phone, $user_id);
        
        if ($stmt->execute()) {
            $success = "User updated successfully!";
        } else {
            $error = "Error updating user: " . $stmt->error;
        }
    }
}

// Handle password reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    if ($new_password !== $confirm_password) {
        $error = "Passwords do not match!";
    } elseif (strlen($new_password) < 5) {
        $error = "Password must be at least 5 characters!";
    } else {
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $update_sql = "UPDATE users SET password = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("si", $password_hash, $user_id);
        
        if ($stmt->execute()) {
            $success = "Password reset successfully!";
        } else {
            $error = "Error resetting password: " . $stmt->error;
        }
    }
}

// Get user details
$user_sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($user_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    redirect('admin.php');
}

// Get user statistics
$orders_count = $conn->query("SELECT COUNT(*) as count FROM orders WHERE user_id = $user_id")->fetch_assoc()['count'];
$total_spent = $conn->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM orders WHERE user_id = $user_id AND payment_status = 'paid'")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --success: #10b981; --danger: #ef4444;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; --border: #e2e8f0;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh; padding: 2rem;
        }
        .container {
            max-width: 800px; margin: 0 auto; background: var(--background);
            border-radius: 30px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; padding: 3rem 2rem; text-align: center;
        }
        .header i { font-size: 3rem; margin-bottom: 1rem; }
        .header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
        .body { padding: 3rem 2.5rem; }
        .alert {
            padding: 1rem; border-radius: 15px; margin-bottom: 1.5rem;
            display: flex; align-items: center; gap: 0.75rem;
        }
        .alert-success { background: #d1fae5; border-left: 4px solid var(--success); color: #065f46; }
        .alert-error { background: #fee2e2; border-left: 4px solid var(--danger); color: #991b1b; }
        .user-stats {
            display: grid; grid-template-columns: repeat(2, 1fr); gap: 1.5rem;
            margin-bottom: 2rem;
        }
        .stat-card {
            background: #f8fafc; padding: 1.5rem; border-radius: 15px;
            border: 2px solid var(--border); text-align: center;
        }
        .stat-number {
            font-size: 2rem; font-weight: 800; color: var(--primary);
            margin-bottom: 0.5rem;
        }
        .stat-label { color: #6b7280; font-weight: 500; }
        .form-section {
            background: #f8fafc; padding: 2rem; border-radius: 15px;
            margin-bottom: 2rem; border: 2px solid var(--border);
        }
        .form-section h3 {
            color: var(--primary); margin-bottom: 1.5rem;
            font-size: 1.5rem;
        }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label {
            display: block; margin-bottom: 0.75rem; font-weight: 600;
            color: var(--text); font-size: 0.95rem;
        }
        .form-group input,
        .form-group select {
            width: 100%; padding: 1rem; border: 2px solid var(--border);
            border-radius: 15px; font-size: 1rem; font-family: inherit;
            background: var(--background); color: var(--text);
        }
        .form-group input:focus,
        .form-group select:focus {
            outline: none; border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(99,102,241,0.1);
        }
        .form-row {
            display: grid; grid-template-columns: repeat(2, 1fr); gap: 1.5rem;
        }
        .btn {
            width: 100%; padding: 1.1rem; border: none; border-radius: 15px;
            font-size: 1.1rem; font-weight: 700; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            gap: 0.75rem; text-decoration: none; margin-top: 1rem;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; box-shadow: 0 8px 20px rgba(99,102,241,0.3);
        }
        .btn-primary:hover { transform: translateY(-3px); }
        .btn-danger {
            background: linear-gradient(135deg, var(--danger), #dc2626); color: white;
        }
        .btn-secondary {
            background: linear-gradient(135deg, #6b7280, #4b5563); color: white;
        }
        @media (max-width: 768px) {
            .form-row, .user-stats { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-user-edit"></i>
            <h1>Edit User</h1>
            <p><?php echo htmlspecialchars($user['full_name']); ?></p>
        </div>

        <div class="body">
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="user-stats">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $orders_count; ?></div>
                    <div class="stat-label">Total Orders</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number">$<?php echo number_format($total_spent, 2); ?></div>
                    <div class="stat-label">Total Spent</div>
                </div>
            </div>

            <!-- User Information Form -->
            <div class="form-section">
                <h3><i class="fas fa-user"></i> User Information</h3>
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Full Name</label>
                        <input type="text" name="full_name" required value="<?php echo htmlspecialchars($user['full_name']); ?>">
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-envelope"></i> Email</label>
                        <input type="email" name="email" required value="<?php echo htmlspecialchars($user['email']); ?>">
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Phone</label>
                        <input type="text" name="phone" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label><i class="fas fa-shield-alt"></i> User Type</label>
                            <select name="user_type" required>
                                <option value="customer" <?php echo $user['user_type'] === 'customer' ? 'selected' : ''; ?>>Customer</option>
                                <option value="artisan" <?php echo $user['user_type'] === 'artisan' ? 'selected' : ''; ?>>Artisan</option>
                                <option value="admin" <?php echo $user['user_type'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label><i class="fas fa-toggle-on"></i> Status</label>
                            <select name="status" required>
                                <option value="active" <?php echo $user['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $user['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                <option value="suspended" <?php echo $user['status'] === 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                            </select>
                        </div>
                    </div>

                    <button type="submit" name="update_user" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update User Information
                    </button>
                </form>
            </div>

            <!-- Password Reset Form -->
            <div class="form-section">
                <h3><i class="fas fa-key"></i> Reset Password</h3>
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> New Password</label>
                        <input type="password" name="new_password" placeholder="Enter new password" required>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-lock"></i> Confirm Password</label>
                        <input type="password" name="confirm_password" placeholder="Confirm new password" required>
                    </div>

                    <button type="submit" name="reset_password" class="btn btn-danger">
                        <i class="fas fa-key"></i> Reset Password
                    </button>
                </form>
            </div>

            <a href="admin.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>
</body>
</html>