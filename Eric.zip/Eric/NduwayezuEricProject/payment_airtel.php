<?php
require_once 'config.php';

if (!is_logged_in() || !isset($_SESSION['pending_order'])) {
    redirect('cart.php');
}

$order_info = $_SESSION['pending_order'];
$order_id = $order_info['order_id'];
$order_number = $order_info['order_number'];
$amount = $order_info['amount'];
$phone = $order_info['phone'];

$payment_initiated = false;
$payment_success = false;
$error_message = '';

// Handle payment initiation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    $momo_phone = clean_input($_POST['momo_phone']);
    
    // NOTE: This is a SIMULATION for development
    // In production, you would integrate with actual MTN MoMo API
    // See PAYMENT_INTEGRATION_GUIDE.md for real API setup
    
    // ==========================================
    // SIMULATION: Random success/failure for testing
    // ==========================================
    $payment_initiated = true;
    $payment_success = (rand(1, 10) > 2); // 80% success rate for testing
    
    /* ==========================================
       REAL MTN MOMO API INTEGRATION (Use in Production)
       ==========================================
       
    // MTN MoMo API Configuration
    $api_user = 'YOUR_API_USER';
    $api_key = 'YOUR_API_KEY';
    $subscription_key = 'YOUR_SUBSCRIPTION_KEY';
    $environment = 'sandbox'; // or 'production'
    
    // Generate transaction reference
    $transaction_ref = 'TXN-' . time() . '-' . rand(1000, 9999);
    
    // MTN MoMo API endpoint
    $url = "https://{$environment}.momodeveloper.mtn.com/collection/v1_0/requesttopay";
    
    // Prepare request
    $data = [
        'amount' => (string)$amount,
        'currency' => 'RWF',
        'externalId' => $order_number,
        'payer' => [
            'partyIdType' => 'MSISDN',
            'partyId' => $momo_phone
        ],
        'payerMessage' => 'Payment for Order ' . $order_number,
        'payeeNote' => 'Artisan Market Purchase'
    ];
    
    // Make API request
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $api_key,
        'X-Reference-Id: ' . $transaction_ref,
        'X-Target-Environment: ' . $environment,
        'Ocp-Apim-Subscription-Key: ' . $subscription_key,
        'Content-Type: application/json'
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $payment_initiated = true;
    $payment_success = ($http_code == 202); // 202 = Accepted
    
    if (!$payment_success) {
        $error_message = "Payment failed. Please try again.";
    }
    
    ========================================== */
    
    if ($payment_success) {
        // Update order payment status
        $update_sql = "UPDATE orders SET payment_status = 'paid' WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        
        // Clear cart
        $user_id = $order_info['user_id'];
        $clear_cart = "DELETE FROM cart WHERE user_id = ?";
        $stmt = $conn->prepare($clear_cart);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        
        // Clear pending order
        unset($_SESSION['pending_order']);
        $_SESSION['order_success'] = $order_number;
        
        // Redirect after 3 seconds
        header("refresh:3;url=order_success.php");
    } else {
        $error_message = "Payment failed. Please check your Mobile Money balance and PIN, then try again.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MTN Mobile Money Payment - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #FFCC00 0%, #FFA500 100%);
            min-height: 100vh; display: flex; align-items: center; justify-content: center;
            padding: 2rem;
        }
        
        .payment-card {
            background: white; max-width: 500px; width: 100%;
            border-radius: 30px; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        .payment-header {
            background: #FFCC00; padding: 2rem; text-align: center;
        }
        .mtn-logo {
            font-size: 3rem; font-weight: 800; color: #000; margin-bottom: 0.5rem;
        }
        .payment-body { padding: 2.5rem; }
        
        .order-info {
            background: #f8fafc; padding: 1.5rem;
            border-radius: 15px; margin-bottom: 2rem;
        }
        .info-row {
            display: flex; justify-content: space-between;
            padding: 0.75rem 0; border-bottom: 1px solid #e2e8f0;
        }
        .info-row:last-child { border-bottom: none; }
        .amount {
            font-size: 2rem; font-weight: 800; color: #FFCC00; text-align: center;
            margin: 1.5rem 0;
        }
        
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 600; }
        .form-group input {
            width: 100%; padding: 1rem; border: 2px solid #e2e8f0;
            border-radius: 10px; font-size: 1rem; font-family: inherit;
        }
        .form-group input:focus {
            outline: none; border-color: #FFCC00;
        }
        
        .btn {
            padding: 1.25rem 2rem; border: none; border-radius: 50px;
            font-weight: 700; cursor: pointer; width: 100%; font-size: 1.1rem;
            display: flex; align-items: center; justify-content: center; gap: 0.5rem;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: #FFCC00; color: #000;
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(255,204,0,0.4); }
        .btn-secondary {
            background: #6b7280; color: white; margin-top: 1rem;
        }
        
        .instructions {
            background: #dbeafe; border-left: 4px solid #3b82f6;
            padding: 1rem; border-radius: 10px; margin-bottom: 2rem;
            color: #1e40af; font-size: 0.9rem; line-height: 1.6;
        }
        
        .processing {
            text-align: center; padding: 2rem;
        }
        .spinner {
            width: 80px; height: 80px; margin: 0 auto 1.5rem;
            border: 6px solid #f3f4f6;
            border-top-color: #FFCC00;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .success {
            text-align: center; padding: 2rem;
        }
        .success-icon {
            width: 100px; height: 100px; background: #10b981;
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            margin: 0 auto 1.5rem; color: white; font-size: 3rem;
        }
        
        .error {
            background: #fee2e2; border-left: 4px solid #ef4444;
            padding: 1rem; border-radius: 10px; color: #991b1b;
            margin-bottom: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="payment-card">
        <div class="payment-header">
            <div class="mtn-logo">MTN</div>
            <p style="color: #000; font-size: 1.1rem; font-weight: 600;">Mobile Money Payment</p>
        </div>
        
        <div class="payment-body">
            <?php if (!$payment_initiated): ?>
                <!-- Payment Form -->
                <div class="order-info">
                    <div class="info-row">
                        <span>Order Number:</span>
                        <strong><?php echo $order_number; ?></strong>
                    </div>
                    <div class="info-row">
                        <span>Amount to Pay:</span>
                        <strong>RWF <?php echo number_format($amount * 1000, 0); ?></strong>
                    </div>
                </div>
                
                <div class="amount">$<?php echo number_format($amount, 2); ?></div>
                
                <div class="instructions">
                    <strong>📱 Payment Instructions:</strong>
                    <ol style="margin-top: 0.5rem; padding-left: 1.5rem;">
                        <li>Enter your MTN Mobile Money number</li>
                        <li>Click "Pay with MTN MoMo"</li>
                        <li>Check your phone for payment prompt</li>
                        <li>Enter your PIN to confirm</li>
                    </ol>
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-mobile-alt"></i> MTN Mobile Money Number</label>
                        <input type="tel" name="momo_phone" 
                               placeholder="078XXXXXXX" 
                               pattern="078[0-9]{7}"
                               value="<?php echo htmlspecialchars($phone); ?>"
                               required
                               title="Enter valid MTN number (078XXXXXXX)">
                        <small style="color: #6b7280; display: block; margin-top: 0.5rem;">
                            ℹ️ Only MTN numbers starting with 078
                        </small>
                    </div>
                    
                    <button type="submit" name="confirm_payment" class="btn btn-primary">
                        <i class="fas fa-check-circle"></i> Pay with MTN MoMo
                    </button>
                    
                    <a href="checkout.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Checkout
                    </a>
                </form>
                
            <?php elseif ($payment_success): ?>
                <!-- Payment Success -->
                <div class="success">
                    <div class="success-icon">
                        <i class="fas fa-check"></i>
                    </div>
                    <h2 style="color: #10b981; margin-bottom: 1rem;">Payment Successful!</h2>
                    <p style="color: #6b7280; margin-bottom: 1.5rem;">
                        Your MTN Mobile Money payment has been received.
                    </p>
                    <p style="color: #6b7280;">
                        Order #<?php echo $order_number; ?><br>
                        Amount: $<?php echo number_format($amount, 2); ?>
                    </p>
                    <p style="color: #3b82f6; margin-top: 1.5rem; font-weight: 600;">
                        <i class="fas fa-spinner fa-spin"></i> Redirecting to order confirmation...
                    </p>
                </div>
                
            <?php else: ?>
                <!-- Payment Failed -->
                <div class="error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                </div>
                
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-mobile-alt"></i> MTN Mobile Money Number</label>
                        <input type="tel" name="momo_phone" 
                               placeholder="078XXXXXXX" 
                               pattern="078[0-9]{7}"
                               value="<?php echo htmlspecialchars($phone); ?>"
                               required>
                    </div>
                    
                    <button type="submit" name="confirm_payment" class="btn btn-primary">
                        <i class="fas fa-redo"></i> Try Again
                    </button>
                    
                    <a href="checkout.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Checkout
                    </a>
                </form>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>