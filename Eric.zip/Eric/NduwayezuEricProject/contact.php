<?php
require_once 'config.php';

$success = '';
$error = '';

// Handle contact form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_contact'])) {
    $firstName = clean_input($_POST['firstName']);
    $lastName = clean_input($_POST['lastName']);
    $email = clean_input($_POST['email']);
    $phone = clean_input($_POST['phone']);
    $subject = clean_input($_POST['subject']);
    $message = clean_input($_POST['message']);
    
    if (empty($firstName) || empty($lastName) || empty($email) || empty($message)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        $insert_sql = "INSERT INTO contact_messages (first_name, last_name, email, phone, subject, message, status, created_at) 
                      VALUES (?, ?, ?, ?, ?, ?, 'unread', NOW())";
        $stmt = $conn->prepare($insert_sql);
        
        if ($stmt) {
            $stmt->bind_param("ssssss", $firstName, $lastName, $email, $phone, $subject, $message);
            
            if ($stmt->execute()) {
                $success = "Thank you for contacting us! We'll get back to you soon.";
                $_POST = array();
            } else {
                $error = "Failed to send message: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "Database error: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root { --primary-color: #2563eb; --success-color: #10b981; --danger-color: #ef4444; --dark-color: #1f2937; --light-color: #f3f4f6; --white: #fff; --border-color: #e5e7eb; --text-color: #374151; --text-light: #6b7280; --shadow: 0 4px 6px rgba(0,0,0,0.1); }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: var(--text-color); background-color: var(--light-color); }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .navbar { background-color: var(--white); box-shadow: var(--shadow); position: sticky; top: 0; z-index: 1000; }
        .nav-wrapper { display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; }
        .logo { display: flex; align-items: center; gap: 0.5rem; font-size: 1.5rem; font-weight: 700; color: var(--primary-color); text-decoration: none; }
        .nav-links { display: flex; list-style: none; gap: 2rem; }
        .nav-links a { color: var(--text-color); font-weight: 500; text-decoration: none; }
        .nav-links a.active { color: var(--primary-color); }
        .nav-icon { position: relative; font-size: 1.25rem; color: var(--text-color); text-decoration: none; }
        .cart-count { position: absolute; top: -8px; right: -8px; background: var(--danger-color); color: var(--white); font-size: 0.75rem; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .btn { padding: 0.75rem 1.5rem; border: none; border-radius: 0.5rem; font-weight: 500; cursor: pointer; text-decoration: none; }
        .btn-primary { background-color: var(--primary-color); color: var(--white); }
        .btn-sm { padding: 0.5rem 1rem; font-size: 0.875rem; }
        .btn-block { width: 100%; }
        .btn-lg { padding: 1rem 2rem; font-size: 1.125rem; }
        .page-header { background: linear-gradient(135deg, var(--primary-color), #7c3aed); color: var(--white); padding: 3rem 0; text-align: center; }
        .page-header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
        .contact-section { padding: 4rem 0; }
        .contact-layout { display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; margin-bottom: 3rem; }
        .contact-info, .contact-form-container { background: var(--white); border-radius: 1rem; padding: 2rem; box-shadow: var(--shadow); }
        .info-card { display: flex; gap: 1.5rem; padding: 1.5rem; margin-bottom: 1.5rem; background: var(--light-color); border-radius: 0.75rem; }
        .info-icon { width: 50px; height: 50px; background: linear-gradient(135deg, var(--primary-color), #7c3aed); color: var(--white); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.25rem; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 0.875rem; border: 2px solid var(--border-color); border-radius: 0.5rem; font-family: inherit; }
        .form-group textarea { resize: vertical; min-height: 150px; }
        .alert { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1.5rem; }
        .alert-success { background: #dcfce7; border-left: 4px solid var(--success-color); color: #065f46; }
        .alert-error { background: #fee2e2; border-left: 4px solid var(--danger-color); color: #991b1b; }
        @media (max-width: 992px) { .contact-layout, .form-row { grid-template-columns: 1fr; } .nav-links { display: none; } }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="index.php" class="logo"><i class="fas fa-store"></i><span>Artisan Market</span></a>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php" class="active">Contact</a></li>
                </ul>
                <div style="display: flex; gap: 1.5rem; align-items: center;">
                    <a href="login.php" class="nav-icon"><i class="fas fa-user"></i></a>
                    <a href="cart.php" class="nav-icon"><i class="fas fa-shopping-cart"></i><span class="cart-count">0</span></a>
                    <a href="register.php" class="btn btn-primary btn-sm">Sell Products</a>
                </div>
            </div>
        </div>
    </nav>

    <section class="page-header">
        <div class="container">
            <h1>Contact Us</h1>
            <p>We'd love to hear from you!</p>
        </div>
    </section>

    <section class="contact-section">
        <div class="container">
            <div class="contact-layout">
                <div class="contact-info">
                    <h2>Get In Touch</h2>
                    <p style="color: var(--text-light); margin-bottom: 2rem;">Have questions? We're here to help!</p>

                    <div class="info-card">
                        <div class="info-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <div><h3>Address</h3><p>KN 4 Ave, Kigali, Rwanda</p></div>
                    </div>

                    <div class="info-card">
                        <div class="info-icon"><i class="fas fa-phone"></i></div>
                        <div><h3>Phone</h3><p>+250 788 123 456</p></div>
                    </div>

                    <div class="info-card">
                        <div class="info-icon"><i class="fas fa-envelope"></i></div>
                        <div><h3>Email</h3><p>info@artisanmarket.com</p></div>
                    </div>

                    <div class="info-card">
                        <div class="info-icon"><i class="fas fa-clock"></i></div>
                        <div><h3>Business Hours</h3><p>Mon-Fri: 9AM-6PM<br>Sat: 10AM-4PM</p></div>
                    </div>
                </div>

                <div class="contact-form-container">
                    <h2>Send Message</h2>

                    <?php if ($success): ?>
                        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                    <?php endif; ?>

                    <?php if ($error): ?>
                        <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="form-row">
                            <div class="form-group">
                                <label>First Name *</label>
                                <input type="text" name="firstName" required value="<?php echo $_POST['firstName'] ?? ''; ?>">
                            </div>
                            <div class="form-group">
                                <label>Last Name *</label>
                                <input type="text" name="lastName" required value="<?php echo $_POST['lastName'] ?? ''; ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>Email *</label>
                                <input type="email" name="email" required value="<?php echo $_POST['email'] ?? ''; ?>">
                            </div>
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="tel" name="phone" value="<?php echo $_POST['phone'] ?? ''; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Subject *</label>
                            <select name="subject" required>
                                <option value="">Select subject</option>
                                <option value="General Inquiry">General Inquiry</option>
                                <option value="Product Question">Product Question</option>
                                <option value="Order Issue">Order Issue</option>
                                <option value="Become a Seller">Become a Seller</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Message *</label>
                            <textarea name="message" required><?php echo $_POST['message'] ?? ''; ?></textarea>
                        </div>

                        <button type="submit" name="submit_contact" class="btn btn-primary btn-block btn-lg">
                            <i class="fas fa-paper-plane"></i> Send Message
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
</body>
</html>