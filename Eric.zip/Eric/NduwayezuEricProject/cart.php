<?php
require_once 'config.php';

$user_id = is_logged_in() ? $_SESSION['user_id'] : null;
$session_id = session_id();

// Handle cart actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add') {
        $product_id = (int)$_POST['product_id'];
        $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
        
        if ($user_id) {
            $sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("iiii", $user_id, $product_id, $quantity, $quantity);
        } else {
            $sql = "INSERT INTO cart (session_id, product_id, quantity) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE quantity = quantity + ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("siii", $session_id, $product_id, $quantity, $quantity);
        }
        $stmt->execute();
    }
    
    if ($_POST['action'] === 'update') {
        $cart_id = (int)$_POST['cart_id'];
        $quantity = (int)$_POST['quantity'];
        $sql = "UPDATE cart SET quantity = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $quantity, $cart_id);
        $stmt->execute();
    }
    
    if ($_POST['action'] === 'remove') {
        $cart_id = (int)$_POST['cart_id'];
        $sql = "DELETE FROM cart WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $cart_id);
        $stmt->execute();
    }
    header("Location: cart.php");
    exit;
}

// Get cart items
if ($user_id) {
    $sql = "SELECT c.*, p.name, p.price, p.image, p.stock FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
} else {
    $sql = "SELECT c.*, p.name, p.price, p.image, p.stock FROM cart c JOIN products p ON c.product_id = p.id WHERE c.session_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $session_id);
}
$stmt->execute();
$cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$subtotal = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart_items));
$shipping = $subtotal > 0 ? 5.00 : 0;
$total = $subtotal + $shipping;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cart - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f3f4f6; color: #374151; }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .navbar { background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); padding: 1rem 0; position: sticky; top: 0; z-index: 100; }
        .nav { display: flex; justify-content: space-between; align-items: center; }
        .logo { font-size: 1.5rem; font-weight: 700; color: #2563eb; text-decoration: none; }
        .nav-links { display: flex; gap: 2rem; list-style: none; }
        .nav-links a { color: #374151; text-decoration: none; font-weight: 500; }
        .user-info { display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 1rem; background: #f3f4f6; border-radius: 0.5rem; }
        .user-avatar { width: 35px; height: 35px; border-radius: 50%; background: linear-gradient(135deg, #2563eb, #7c3aed); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 600; }
        .btn { padding: 0.75rem 1.5rem; border: none; border-radius: 0.5rem; font-weight: 500; cursor: pointer; text-decoration: none; display: inline-block; text-align: center; }
        .btn-primary { background: #2563eb; color: #fff; }
        .btn-danger { background: #ef4444; color: #fff; }
        .btn-block { width: 100%; }
        .header { background: linear-gradient(135deg, #2563eb, #7c3aed); color: #fff; padding: 3rem 0; text-align: center; margin-bottom: 2rem; }
        .cart-layout { display: grid; grid-template-columns: 1fr 400px; gap: 2rem; padding: 2rem 0; }
        .cart-items, .summary { background: #fff; padding: 2rem; border-radius: 1rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .cart-item { display: grid; grid-template-columns: 100px 1fr auto; gap: 1.5rem; padding: 1.5rem; border-bottom: 1px solid #e5e7eb; align-items: center; }
        .cart-item img { width: 100px; height: 100px; object-fit: cover; border-radius: 0.5rem; }
        .qty-control { display: flex; gap: 0.5rem; align-items: center; }
        .qty-btn { width: 30px; height: 30px; border: 2px solid #e5e7eb; background: #fff; border-radius: 0.25rem; cursor: pointer; }
        .summary-row { display: flex; justify-content: space-between; padding: 0.75rem 0; border-bottom: 1px solid #e5e7eb; }
        .summary-total { font-size: 1.25rem; font-weight: 700; margin-top: 1rem; padding-top: 1rem; border-top: 2px solid #1f2937; }
        .empty { text-align: center; padding: 4rem 2rem; }
        @media (max-width: 992px) { .cart-layout { grid-template-columns: 1fr; } .nav-links { display: none; } }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav">
                <a href="index.php" class="logo"><i class="fas fa-store"></i> Artisan Market</a>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
                <div style="display: flex; gap: 1rem; align-items: center;">
                    <?php if (is_logged_in()): ?>
                        <div class="user-info">
                            <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
                            <span><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                        </div>
                        <a href="logout.php" class="btn" style="background: #ef4444; color: #fff; padding: 0.5rem 1rem;">Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="btn-primary btn" style="padding: 0.5rem 1rem;">Login</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <div class="header">
        <h1>Shopping Cart</h1>
        <p>Review your items</p>
    </div>

    <div class="container">
        <?php if (empty($cart_items)): ?>
            <div class="cart-items">
                <div class="empty">
                    <i class="fas fa-shopping-cart" style="font-size: 5rem; color: #9ca3af; margin-bottom: 1rem;"></i>
                    <h3>Your cart is empty</h3>
                    <a href="products.php" class="btn btn-primary" style="margin-top: 2rem;">Browse Products</a>
                </div>
            </div>
        <?php else: ?>
            <div class="cart-layout">
                <div class="cart-items">
                    <h2 style="margin-bottom: 1.5rem;">Cart Items</h2>
                    <?php foreach ($cart_items as $item): ?>
                        <div class="cart-item">
                            <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            <div>
                                <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                                <p style="color: #2563eb; font-size: 1.25rem; font-weight: 700;">$<?php echo number_format($item['price'], 2); ?></p>
                            </div>
                            <div style="text-align: right;">
                                <div class="qty-control" style="margin-bottom: 1rem;">
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="update">
                                        <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                        <input type="hidden" name="quantity" value="<?php echo max(1, $item['quantity'] - 1); ?>">
                                        <button type="submit" class="qty-btn">-</button>
                                    </form>
                                    <span><?php echo $item['quantity']; ?></span>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="action" value="update">
                                        <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                        <input type="hidden" name="quantity" value="<?php echo $item['quantity'] + 1; ?>">
                                        <button type="submit" class="qty-btn">+</button>
                                    </form>
                                </div>
                                <p style="font-weight: 700; margin-bottom: 1rem;">$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></p>
                                <form method="POST">
                                    <input type="hidden" name="action" value="remove">
                                    <input type="hidden" name="cart_id" value="<?php echo $item['id']; ?>">
                                    <button type="submit" class="btn btn-danger" style="padding: 0.5rem 1rem; font-size: 0.875rem;">Remove</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="summary">
                    <h2 style="margin-bottom: 1.5rem;">Order Summary</h2>
                    <div class="summary-row"><span>Subtotal</span><span>$<?php echo number_format($subtotal, 2); ?></span></div>
                    <div class="summary-row"><span>Shipping</span><span>$<?php echo number_format($shipping, 2); ?></span></div>
                    <div class="summary-row summary-total"><span>Total</span><span style="color: #2563eb;">$<?php echo number_format($total, 2); ?></span></div>
                    
                    <?php if (is_logged_in()): ?>
                        <a href="checkout.php" class="btn btn-primary btn-block" style="margin-top: 1.5rem; font-size: 1.125rem;"><i class="fas fa-lock"></i> Checkout</a>
                    <?php else: ?>
                        <p style="text-align: center; margin: 1.5rem 0;">Please login to checkout</p>
                        <a href="login.php" class="btn btn-primary btn-block">Login</a>
                    <?php endif; ?>
                    
                    <a href="products.php" class="btn btn-block" style="margin-top: 1rem; background: #f3f4f6; color: #374151;">Continue Shopping</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>