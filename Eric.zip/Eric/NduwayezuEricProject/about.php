<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Local Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #2563eb;
            --secondary-color: #7c3aed;
            --success-color: #10b981;
            --dark-color: #1f2937;
            --light-color: #f3f4f6;
            --white: #ffffff;
            --border-color: #e5e7eb;
            --text-color: #374151;
            --text-light: #6b7280;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.15);
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
            background-color: var(--white);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        /* Navigation */
        .navbar {
            background-color: var(--white);
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary-color);
            text-decoration: none;
        }

        .logo i {
            font-size: 1.75rem;
        }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 2rem;
        }

        .nav-links a {
            color: var(--text-color);
            font-weight: 500;
            transition: color 0.3s ease;
            text-decoration: none;
        }

        .nav-links a:hover,
        .nav-links a.active {
            color: var(--primary-color);
        }

        .nav-actions {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .nav-icon {
            position: relative;
            font-size: 1.25rem;
            color: var(--text-color);
            transition: color 0.3s ease;
            text-decoration: none;
        }

        .nav-icon:hover {
            color: var(--primary-color);
        }

        .cart-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #ef4444;
            color: var(--white);
            font-size: 0.75rem;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: var(--white);
        }

        .btn-sm {
            padding: 0.5rem 1rem;
            font-size: 0.875rem;
        }

        /* Page Header */
        .page-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: var(--white);
            padding: 4rem 0;
            text-align: center;
        }

        .page-header h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .page-header p {
            font-size: 1.25rem;
            opacity: 0.9;
            max-width: 700px;
            margin: 0 auto;
        }

        /* About Section */
        .about-section {
            padding: 4rem 0;
        }

        .about-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            align-items: center;
            margin-bottom: 4rem;
        }

        .about-text h2 {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .about-text p {
            margin-bottom: 1.5rem;
            line-height: 1.8;
            color: var(--text-color);
        }

        .about-image {
            width: 100%;
            height: 400px;
            object-fit: cover;
            border-radius: 1rem;
            box-shadow: var(--shadow-lg);
        }

        /* Mission Vision */
        .mission-vision {
            background-color: var(--light-color);
            padding: 4rem 0;
        }

        .mission-vision-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .mv-card {
            background-color: var(--white);
            padding: 2.5rem;
            border-radius: 1rem;
            box-shadow: var(--shadow);
            text-align: center;
        }

        .mv-card i {
            font-size: 3rem;
            color: var(--primary-color);
            margin-bottom: 1.5rem;
        }

        .mv-card h3 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .mv-card p {
            line-height: 1.8;
            color: var(--text-color);
        }

        /* Values Section */
        .values-section {
            padding: 4rem 0;
        }

        .section-title {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 3rem;
            color: var(--dark-color);
        }

        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .value-card {
            background-color: var(--white);
            padding: 2rem;
            border-radius: 1rem;
            box-shadow: var(--shadow);
            transition: transform 0.3s ease;
        }

        .value-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .value-card i {
            font-size: 2.5rem;
            color: var(--primary-color);
            margin-bottom: 1rem;
        }

        .value-card h3 {
            font-size: 1.25rem;
            margin-bottom: 0.75rem;
            color: var(--dark-color);
        }

        .value-card p {
            color: var(--text-color);
            line-height: 1.6;
        }

        /* Team Section */
        .team-section {
            background-color: var(--light-color);
            padding: 4rem 0;
        }

        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }

        .team-card {
            background-color: var(--white);
            border-radius: 1rem;
            overflow: hidden;
            box-shadow: var(--shadow);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .team-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .team-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            background-color: var(--light-color);
        }

        .team-info {
            padding: 1.5rem;
        }

        .team-info h3 {
            margin-bottom: 0.5rem;
            color: var(--dark-color);
        }

        .team-info .role {
            color: var(--primary-color);
            font-weight: 500;
            margin-bottom: 1rem;
        }

        .team-info p {
            color: var(--text-color);
            font-size: 0.9rem;
            line-height: 1.6;
        }

        /* CTA Section */
        .cta-section {
            padding: 4rem 0;
            text-align: center;
        }

        .cta-content {
            max-width: 700px;
            margin: 0 auto;
        }

        .cta-content h2 {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: var(--dark-color);
        }

        .cta-content p {
            font-size: 1.125rem;
            margin-bottom: 2rem;
            color: var(--text-color);
        }

        .cta-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-lg {
            padding: 1rem 2rem;
            font-size: 1.125rem;
        }

        .btn-secondary {
            background-color: transparent;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
        }

        .btn-secondary:hover {
            background-color: var(--primary-color);
            color: var(--white);
        }

        /* Footer */
        .footer {
            background-color: var(--dark-color);
            color: var(--white);
            padding: 3rem 0 1rem;
        }

        .footer-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .footer-col h3 {
            margin-bottom: 1rem;
            color: var(--white);
        }

        .footer-col p {
            opacity: 0.8;
            line-height: 1.8;
        }

        .footer-col ul {
            list-style: none;
        }

        .footer-col ul li {
            margin-bottom: 0.5rem;
        }

        .footer-col ul li a {
            color: var(--white);
            opacity: 0.8;
            transition: opacity 0.3s ease;
            text-decoration: none;
        }

        .footer-col ul li a:hover {
            opacity: 1;
        }

        .social-links {
            display: flex;
            gap: 1rem;
        }

        .social-links a {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
            transition: background-color 0.3s ease;
        }

        .social-links a:hover {
            background-color: var(--primary-color);
        }

        .footer-bottom {
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            opacity: 0.8;
        }

        /* Responsive */
        @media (max-width: 992px) {
            .nav-links {
                display: none;
            }

            .about-content {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .page-header h1 {
                font-size: 2rem;
            }

            .about-text h2 {
                font-size: 1.5rem;
            }

            .section-title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="index.php" class="logo">
                    <i class="fas fa-store"></i>
                    <span>Artisan Market</span>
                </a>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="about.php" class="active">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
                <div class="nav-actions">
                    <a href="login.php" class="nav-icon"><i class="fas fa-user"></i></a>
                    <a href="cart.php" class="nav-icon">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="cart-count" id="cartCount">0</span>
                    </a>
                    <a href="register.php" class="btn btn-primary btn-sm">Sell Products</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <h1>About Us</h1>
            <p>Connecting local artisans with customers who value authentic, handcrafted quality</p>
        </div>
    </section>

    <!-- About Section -->
    <section class="about-section">
        <div class="container">
            <div class="about-content">
                <div class="about-text">
                    <h2>Our Story</h2>
                    <p>
                        Artisan Market was founded with a simple yet powerful vision: to create a platform where local artisans 
                        can showcase their handcrafted products and connect directly with customers who appreciate authentic, 
                        high-quality craftsmanship.
                    </p>
                    <p>
                        We believe that every handmade product tells a story – the story of the artisan's skill, passion, 
                        and dedication to their craft. Our marketplace provides a space where these stories can be shared 
                        and celebrated.
                    </p>
                    <p>
                        By bringing together talented artisans and discerning customers, we're not just facilitating 
                        transactions; we're building a community that values tradition, sustainability, and the human 
                        touch in an increasingly automated world.
                    </p>
                </div>
                <img src="https://images.unsplash.com/photo-1452860606245-08befc0ff44b?w=800" alt="Artisan at work" class="about-image">
            </div>

            <div class="about-content" style="flex-direction: row-reverse;">
                <div class="about-text">
                    <h2>What We Do</h2>
                    <p>
                        We provide a comprehensive e-commerce platform specifically designed for local artisans. 
                        Our marketplace makes it easy for craftspeople to:
                    </p>
                    <ul style="margin-left: 2rem; margin-bottom: 1.5rem;">
                        <li>Create their online storefront</li>
                        <li>List and manage their products</li>
                        <li>Reach customers beyond their local market</li>
                        <li>Process orders and payments securely</li>
                        <li>Build their brand and customer base</li>
                    </ul>
                    <p>
                        For customers, we offer a curated selection of authentic handmade products, from jewelry 
                        and home decor to art and clothing – all crafted with care by talented local artisans.
                    </p>
                </div>
                <img src="https://images.unsplash.com/photo-1556912998-c57cc6b63cd7?w=800" alt="Handmade products" class="about-image">
            </div>
        </div>
    </section>

    <!-- Mission & Vision -->
    <section class="mission-vision">
        <div class="container">
            <div class="mission-vision-grid">
                <div class="mv-card">
                    <i class="fas fa-bullseye"></i>
                    <h3>Our Mission</h3>
                    <p>
                        To empower local artisans by providing them with the tools, platform, and support they need 
                        to thrive in the digital marketplace while preserving traditional craftsmanship and 
                        promoting sustainable business practices.
                    </p>
                </div>
                <div class="mv-card">
                    <i class="fas fa-eye"></i>
                    <h3>Our Vision</h3>
                    <p>
                        To become the leading marketplace for handmade products, where every purchase supports 
                        local artisans, celebrates cultural heritage, and contributes to building sustainable 
                        communities through authentic craftsmanship.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Values Section -->
    <section class="values-section">
        <div class="container">
            <h2 class="section-title">Our Core Values</h2>
            <div class="values-grid">
                <div class="value-card">
                    <i class="fas fa-handshake"></i>
                    <h3>Authenticity</h3>
                    <p>We ensure every product is genuinely handmade by verified local artisans.</p>
                </div>
                <div class="value-card">
                    <i class="fas fa-leaf"></i>
                    <h3>Sustainability</h3>
                    <p>We promote eco-friendly practices and sustainable business models.</p>
                </div>
                <div class="value-card">
                    <i class="fas fa-users"></i>
                    <h3>Community</h3>
                    <p>We foster connections between artisans and customers who share common values.</p>
                </div>
                <div class="value-card">
                    <i class="fas fa-award"></i>
                    <h3>Quality</h3>
                    <p>We maintain high standards for craftsmanship and customer service.</p>
                </div>
                <div class="value-card">
                    <i class="fas fa-chart-line"></i>
                    <h3>Growth</h3>
                    <p>We support artisans in growing their businesses and reaching new markets.</p>
                </div>
                <div class="value-card">
                    <i class="fas fa-heart"></i>
                    <h3>Passion</h3>
                    <p>We celebrate the passion and dedication behind every handcrafted product.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="team-section">
        <div class="container">
            <h2 class="section-title">Meet Our Team</h2>
            <div class="team-grid">
                <div class="team-card">
                    <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=500" alt="Team member" class="team-image">
                    <div class="team-info">
                        <h3>John Doe</h3>
                        <p class="role">Founder & CEO</p>
                        <p>Passionate about empowering artisans and building sustainable communities.</p>
                    </div>
                </div>
                <div class="team-card">
                    <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=500" alt="Team member" class="team-image">
                    <div class="team-info">
                        <h3>Jane Smith</h3>
                        <p class="role">Operations Director</p>
                        <p>Ensuring smooth operations and excellent customer experience.</p>
                    </div>
                </div>
                <div class="team-card">
                    <img src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=500" alt="Team member" class="team-image">
                    <div class="team-info">
                        <h3>Mike Johnson</h3>
                        <p class="role">Artisan Relations</p>
                        <p>Supporting artisans and helping them succeed on our platform.</p>
                    </div>
                </div>
                <div class="team-card">
                    <img src="https://images.unsplash.com/photo-1580489944761-15a19d654956?w=500" alt="Team member" class="team-image">
                    <div class="team-info">
                        <h3>Sarah Williams</h3>
                        <p class="role">Marketing Lead</p>
                        <p>Spreading the word about our amazing artisans and their work.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2>Join Our Community</h2>
                <p>
                    Whether you're an artisan looking to showcase your work or a customer seeking unique, 
                    handcrafted products, we'd love to have you join our community.
                </p>
                <div class="cta-buttons">
                    <a href="register.php" class="btn btn-primary btn-lg">Become a Seller</a>
                    <a href="products.php" class="btn btn-secondary btn-lg">Browse Products</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <h3>About Us</h3>
                    <p>We connect local artisans with customers who appreciate handmade quality and craftsmanship.</p>
                </div>
                <div class="footer-col">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><a href="products.php">Products</a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="register.php">Become a Seller</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Customer Service</h3>
                    <ul>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Shipping Info</a></li>
                        <li><a href="#">Returns</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Connect With Us</h3>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-facebook"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 Artisan Market. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script>
        // Update cart count
        function updateCartCount() {
            const cart = localStorage.getItem('cart');
            const cartData = cart ? JSON.parse(cart) : [];
            const totalItems = cartData.reduce((sum, item) => sum + item.quantity, 0);
            document.getElementById('cartCount').textContent = totalItems;
        }

        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            updateCartCount();
        });
    </script>
</body>
</html>