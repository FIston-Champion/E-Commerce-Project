<?php
require_once 'config.php';

// Get all products from database
$search = isset($_GET['search']) ? clean_input($_GET['search']) : '';
$category = isset($_GET['category']) ? clean_input($_GET['category']) : 'all';
$sort = isset($_GET['sort']) ? clean_input($_GET['sort']) : 'featured';
$min_price = isset($_GET['min_price']) ? (float)$_GET['min_price'] : 0;
$max_price = isset($_GET['max_price']) ? (float)$_GET['max_price'] : 999999;

// Build SQL query
$sql = "SELECT p.*, u.full_name as artisan_name 
        FROM products p 
        LEFT JOIN users u ON p.user_id = u.id 
        WHERE p.status = 'active' AND p.price BETWEEN ? AND ?";

$params = [$min_price, $max_price];
$types = "dd";

// Add search filter
if (!empty($search)) {
    $sql .= " AND (p.name LIKE ? OR p.description LIKE ?)";
    $search_param = "%$search%";
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "ss";
}

// Add category filter
if ($category !== 'all') {
    $sql .= " AND p.category = ?";
    $params[] = $category;
    $types .= "s";
}

// Add sorting
switch ($sort) {
    case 'price-low':
        $sql .= " ORDER BY p.price ASC";
        break;
    case 'price-high':
        $sql .= " ORDER BY p.price DESC";
        break;
    case 'name':
        $sql .= " ORDER BY p.name ASC";
        break;
    default:
        $sql .= " ORDER BY p.created_at DESC"; // Show newest products first
}

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();
$products = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get product count
$product_count = count($products);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root { --primary-color: #2563eb; --danger-color: #ef4444; --dark-color: #1f2937; --light-color: #f3f4f6; --white: #ffffff; --border-color: #e5e7eb; --text-color: #374151; --text-light: #6b7280; --shadow: 0 4px 6px rgba(0,0,0,0.1); --shadow-lg: 0 10px 25px rgba(0,0,0,0.15); }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: var(--text-color); background-color: var(--light-color); }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .navbar { background-color: var(--white); box-shadow: var(--shadow); position: sticky; top: 0; z-index: 1000; }
        .nav-wrapper { display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; }
        .logo { display: flex; align-items: center; gap: 0.5rem; font-size: 1.5rem; font-weight: 700; color: var(--primary-color); text-decoration: none; }
        .logo i { font-size: 1.75rem; }
        .nav-links { display: flex; list-style: none; gap: 2rem; }
        .nav-links a { color: var(--text-color); font-weight: 500; text-decoration: none; }
        .nav-links a.active { color: var(--primary-color); }
        .nav-icon { position: relative; font-size: 1.25rem; color: var(--text-color); text-decoration: none; }
        .cart-count { position: absolute; top: -8px; right: -8px; background-color: var(--danger-color); color: var(--white); font-size: 0.75rem; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .btn { padding: 0.5rem 1rem; border: none; border-radius: 0.5rem; font-weight: 500; cursor: pointer; text-decoration: none; }
        .btn-primary { background-color: var(--primary-color); color: var(--white); }
        .btn-sm { padding: 0.5rem 1rem; font-size: 0.875rem; }
        .page-header { background: linear-gradient(135deg, var(--primary-color), #7c3aed); color: var(--white); padding: 3rem 0; text-align: center; }
        .page-header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
        .products-section { padding: 3rem 0; }
        .products-layout { display: grid; grid-template-columns: 280px 1fr; gap: 2rem; }
        .products-sidebar { background-color: var(--white); padding: 1.5rem; border-radius: 1rem; box-shadow: var(--shadow); height: fit-content; position: sticky; top: 100px; }
        .filter-section { margin-bottom: 2rem; padding-bottom: 2rem; border-bottom: 1px solid var(--border-color); }
        .filter-section:last-child { border-bottom: none; margin-bottom: 0; padding-bottom: 0; }
        .filter-section h3 { font-size: 1.125rem; margin-bottom: 1rem; color: var(--dark-color); }
        .search-box { position: relative; }
        .search-box input { width: 100%; padding: 0.75rem 2.5rem 0.75rem 1rem; border: 2px solid var(--border-color); border-radius: 0.5rem; font-size: 0.9rem; }
        .search-box i { position: absolute; right: 1rem; top: 50%; transform: translateY(-50%); color: var(--text-light); }
        .filter-select { width: 100%; padding: 0.75rem; border: 2px solid var(--border-color); border-radius: 0.5rem; font-size: 0.9rem; cursor: pointer; background-color: var(--white); }
        .price-inputs input { width: 100%; padding: 0.75rem; border: 2px solid var(--border-color); border-radius: 0.5rem; font-size: 0.9rem; }
        .btn-block { width: 100%; }
        .products-header { margin-bottom: 1.5rem; padding: 1rem; background-color: var(--white); border-radius: 0.5rem; box-shadow: var(--shadow); }
        .products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 2rem; }
        .product-card { background-color: var(--white); border-radius: 1rem; overflow: hidden; box-shadow: var(--shadow); transition: transform 0.3s ease, box-shadow 0.3s ease; }
        .product-card:hover { transform: translateY(-5px); box-shadow: var(--shadow-lg); }
        .product-image { width: 100%; height: 250px; object-fit: cover; background-color: var(--light-color); }
        .product-info { padding: 1.5rem; }
        .product-title { font-size: 1.25rem; margin-bottom: 0.5rem; color: var(--dark-color); }
        .product-artisan { color: var(--text-light); font-size: 0.875rem; margin-bottom: 0.5rem; }
        .product-description { color: var(--text-color); font-size: 0.9rem; margin-bottom: 1rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .product-footer { display: flex; justify-content: space-between; align-items: center; }
        .product-price { font-size: 1.5rem; font-weight: 700; color: var(--primary-color); }
        .btn-add-cart { padding: 0.5rem 1rem; background-color: var(--primary-color); color: var(--white); border: none; border-radius: 0.5rem; cursor: pointer; font-weight: 500; }
        @media (max-width: 992px) { .products-layout { grid-template-columns: 1fr; } .nav-links { display: none; } }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="index.php" class="logo"><i class="fas fa-store"></i><span>Artisan Market</span></a>
                <ul class="nav-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php" class="active">Products</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
                <div style="display: flex; gap: 1.5rem; align-items: center;">
                    <a href="login.php" class="nav-icon"><i class="fas fa-user"></i></a>
                    <a href="cart.php" class="nav-icon"><i class="fas fa-shopping-cart"></i><span class="cart-count">0</span></a>
                    <a href="register.php" class="btn btn-primary btn-sm">Sell Products</a>
                </div>
            </div>
        </div>
    </nav>

    <section class="page-header">
        <div class="container">
            <h1>Browse Products</h1>
            <p>Discover unique handmade items from local artisans</p>
        </div>
    </section>

    <section class="products-section">
        <div class="container">
            <div class="products-layout">
                <aside class="products-sidebar">
                    <form method="GET" action="">
                        <div class="filter-section">
                            <h3>Search</h3>
                            <div class="search-box">
                                <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>">
                                <i class="fas fa-search"></i>
                            </div>
                        </div>

                        <div class="filter-section">
                            <h3>Categories</h3>
                            <select name="category" class="filter-select" onchange="this.form.submit()">
                                <option value="all" <?php echo $category === 'all' ? 'selected' : ''; ?>>All Categories</option>
                                <option value="pottery" <?php echo $category === 'pottery' ? 'selected' : ''; ?>>Pottery & Ceramics</option>
                                <option value="textiles" <?php echo $category === 'textiles' ? 'selected' : ''; ?>>Textiles & Fabrics</option>
                                <option value="jewelry" <?php echo $category === 'jewelry' ? 'selected' : ''; ?>>Jewelry</option>
                                <option value="woodwork" <?php echo $category === 'woodwork' ? 'selected' : ''; ?>>Woodwork</option>
                                <option value="art" <?php echo $category === 'art' ? 'selected' : ''; ?>>Art & Paintings</option>
                                <option value="leather" <?php echo $category === 'leather' ? 'selected' : ''; ?>>Leather Goods</option>
                                <option value="metalwork" <?php echo $category === 'metalwork' ? 'selected' : ''; ?>>Metalwork</option>
                                <option value="basketry" <?php echo $category === 'basketry' ? 'selected' : ''; ?>>Basketry</option>
                                <option value="other" <?php echo $category === 'other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>

                        <div class="filter-section">
                            <h3>Price Range</h3>
                            <div class="price-inputs">
                                <input type="number" name="min_price" placeholder="Min ($)" value="<?php echo $min_price > 0 ? $min_price : ''; ?>" style="width: 100%;">
                            </div>
                            <div class="price-inputs" style="margin-top: 0.75rem;">
                                <input type="number" name="max_price" placeholder="Max ($)" value="<?php echo $max_price < 999999 ? $max_price : ''; ?>" style="width: 100%;">
                            </div>
                            <button type="submit" class="btn btn-primary btn-block" style="margin-top: 1rem;">Apply Filters</button>
                        </div>

                        <div class="filter-section">
                            <h3>Sort By</h3>
                            <select name="sort" class="filter-select" onchange="this.form.submit()">
                                <option value="featured" <?php echo $sort === 'featured' ? 'selected' : ''; ?>>Featured</option>
                                <option value="price-low" <?php echo $sort === 'price-low' ? 'selected' : ''; ?>>Price: Low to High</option>
                                <option value="price-high" <?php echo $sort === 'price-high' ? 'selected' : ''; ?>>Price: High to Low</option>
                                <option value="name" <?php echo $sort === 'name' ? 'selected' : ''; ?>>Name: A to Z</option>
                            </select>
                        </div>
                    </form>
                </aside>

                <div>
                    <div class="products-header">
                        <p style="color: var(--text-light);">Showing <?php echo $product_count; ?> product<?php echo $product_count !== 1 ? 's' : ''; ?></p>
                    </div>
                    <div class="products-grid">
                        <?php if (empty($products)): ?>
                            <p style="grid-column: 1/-1; text-align: center; padding: 2rem;">No products found.</p>
                        <?php else: ?>
                            <?php foreach ($products as $product): ?>
                                <div class="product-card">
                                    <?php 
                                    $image_src = !empty($product['image']) && file_exists($product['image']) 
                                        ? htmlspecialchars($product['image']) 
                                        : 'https://via.placeholder.com/400x300/6366f1/ffffff?text=No+Image';
                                    ?>
                                    <img src="<?php echo $image_src; ?>" 
                                         alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                         class="product-image"
                                         onerror="this.src='https://via.placeholder.com/400x300/6366f1/ffffff?text=Image+Not+Found'">
                                    <div class="product-info">
                                        <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                                        <p class="product-artisan"><i class="fas fa-user"></i> <?php echo htmlspecialchars($product['artisan_name']); ?></p>
                                        <p class="product-description"><?php echo htmlspecialchars($product['description']); ?></p>
                                        <div class="product-footer">
                                            <span class="product-price">$<?php echo number_format($product['price'], 2); ?></span>
                                            <form method="POST" action="cart.php" style="display: inline;">
                                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                                <input type="hidden" name="action" value="add">
                                                <button type="submit" class="btn-add-cart"><i class="fas fa-cart-plus"></i> Add</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</body>
</html>