<?php
require_once 'config.php';

if (!isset($_SESSION['order_success'])) {
    redirect('index.php');
}

$order_number = $_SESSION['order_success'];
unset($_SESSION['order_success']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Order Success - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
        .success-card { background: #fff; padding: 3rem; border-radius: 1rem; box-shadow: 0 10px 25px rgba(0,0,0,0.15); text-align: center; max-width: 500px; }
        .success-icon { width: 100px; height: 100px; border-radius: 50%; background: #10b981; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 3rem; margin: 0 auto 2rem; }
        .btn { padding: 1rem 2rem; border: none; border-radius: 0.5rem; font-weight: 600; cursor: pointer; text-decoration: none; display: inline-block; margin: 0.5rem; }
        .btn-primary { background: #2563eb; color: #fff; }
    </style>
</head>
<body>
    <div class="success-card">
        <div class="success-icon"><i class="fas fa-check"></i></div>
        <h1 style="color: #10b981; margin-bottom: 1rem;">Order Placed Successfully!</h1>
        <p style="color: #6b7280; margin-bottom: 1.5rem;">Thank you for your order. Your order number is:</p>
        <h2 style="color: #2563eb; margin-bottom: 2rem;"><?php echo htmlspecialchars($order_number); ?></h2>
        <p style="color: #6b7280; margin-bottom: 2rem;">We'll send you an email confirmation shortly.</p>
        <div>
            <a href="index.php" class="btn btn-primary">Continue Shopping</a>
            <a href="my_orders.php" class="btn" style="background: #f3f4f6; color: #374151;">View Orders</a>
        </div>
    </div>
</body>
</html>