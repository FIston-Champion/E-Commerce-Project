<?php
require_once 'config.php';

// Check if user is admin
if (!is_admin()) {
    header('Location: login.php');
    exit();
}

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $message_id = (int)$_POST['message_id'];
    $status = clean_input($_POST['status']);
    
    if (update_contact_message_status($message_id, $status)) {
        $success_msg = "Message status updated successfully.";
    } else {
        $error_msg = "Failed to update message status.";
    }
}

// Get messages
$status_filter = isset($_GET['status']) ? clean_input($_GET['status']) : null;
$messages = get_contact_messages($status_filter);

// Get counts
$total_messages = get_contact_message_count();
$unread_messages = get_contact_message_count('unread');
$read_messages = get_contact_message_count('read');
$replied_messages = get_contact_message_count('replied');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Messages - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f3f4f6; }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .header { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .stat-card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stat-card h3 { color: #666; margin-bottom: 10px; }
        .stat-card .number { font-size: 2rem; font-weight: bold; }
        .unread { border-left: 5px solid #ef4444; }
        .read { border-left: 5px solid #3b82f6; }
        .replied { border-left: 5px solid #10b981; }
        .filters { display: flex; gap: 10px; margin-bottom: 20px; }
        .filter-btn { padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; background: #e5e7eb; }
        .filter-btn.active { background: #3b82f6; color: white; }
        .messages-table { background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 15px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        th { background: #f9fafb; font-weight: 600; }
        .status-badge { padding: 4px 8px; border-radius: 20px; font-size: 0.875rem; }
        .status-unread { background: #fee2e2; color: #dc2626; }
        .status-read { background: #dbeafe; color: #1d4ed8; }
        .status-replied { background: #d1fae5; color: #047857; }
        .btn { padding: 6px 12px; border: none; border-radius: 5px; cursor: pointer; font-size: 0.875rem; }
        .btn-primary { background: #3b82f6; color: white; }
        .btn-danger { background: #ef4444; color: white; }
        .message-modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; }
        .modal-content { background: white; width: 90%; max-width: 600px; margin: 50px auto; padding: 30px; border-radius: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-envelope"></i> Contact Messages</h1>
            <p>Manage contact form submissions</p>
        </div>
        
        <?php if (isset($success_msg)): ?>
            <div style="background: #d1fae5; color: #047857; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
                <?php echo $success_msg; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_msg)): ?>
            <div style="background: #fee2e2; color: #dc2626; padding: 10px; border-radius: 5px; margin-bottom: 20px;">
                <?php echo $error_msg; ?>
            </div>
        <?php endif; ?>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Messages</h3>
                <div class="number"><?php echo $total_messages; ?></div>
            </div>
            <div class="stat-card unread">
                <h3>Unread Messages</h3>
                <div class="number"><?php echo $unread_messages; ?></div>
            </div>
            <div class="stat-card read">
                <h3>Read Messages</h3>
                <div class="number"><?php echo $read_messages; ?></div>
            </div>
            <div class="stat-card replied">
                <h3>Replied Messages</h3>
                <div class="number"><?php echo $replied_messages; ?></div>
            </div>
        </div>
        
        <div class="filters">
            <a href="admin_contact.php" class="filter-btn <?php echo !$status_filter ? 'active' : ''; ?>">All</a>
            <a href="admin_contact.php?status=unread" class="filter-btn <?php echo $status_filter === 'unread' ? 'active' : ''; ?>">Unread</a>
            <a href="admin_contact.php?status=read" class="filter-btn <?php echo $status_filter === 'read' ? 'active' : ''; ?>">Read</a>
            <a href="admin_contact.php?status=replied" class="filter-btn <?php echo $status_filter === 'replied' ? 'active' : ''; ?>">Replied</a>
        </div>
        
        <div class="messages-table">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Subject</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($messages as $message): ?>
                    <tr>
                        <td>#<?php echo $message['id']; ?></td>
                        <td><?php echo htmlspecialchars($message['first_name'] . ' ' . $message['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($message['email']); ?></td>
                        <td><?php echo htmlspecialchars($message['subject']); ?></td>
                        <td><?php echo date('M d, Y H:i', strtotime($message['created_at'])); ?></td>
                        <td>
                            <span class="status-badge status-<?php echo $message['status']; ?>">
                                <?php echo ucfirst($message['status']); ?>
                            </span>
                        </td>
                        <td>
                            <button onclick="viewMessage(<?php echo $message['id']; ?>)" class="btn btn-primary">
                                <i class="fas fa-eye"></i> View
                            </button>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="message_id" value="<?php echo $message['id']; ?>">
                                <select name="status" onchange="this.form.submit()" style="padding: 4px; border-radius: 4px; border: 1px solid #ccc;">
                                    <option value="unread" <?php echo $message['status'] === 'unread' ? 'selected' : ''; ?>>Unread</option>
                                    <option value="read" <?php echo $message['status'] === 'read' ? 'selected' : ''; ?>>Read</option>
                                    <option value="replied" <?php echo $message['status'] === 'replied' ? 'selected' : ''; ?>>Replied</option>
                                </select>
                                <input type="hidden" name="update_status" value="1">
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <div id="messageModal" class="message-modal">
        <div class="modal-content">
            <h2>Message Details</h2>
            <div id="messageContent"></div>
            <button onclick="closeModal()" style="margin-top: 20px; padding: 8px 16px; background: #ef4444; color: white; border: none; border-radius: 5px; cursor: pointer;">
                Close
            </button>
        </div>
    </div>
    
    <script>
        function viewMessage(id) {
            fetch('get_message.php?id=' + id)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const message = data.message;
                        const content = `
                            <p><strong>Name:</strong> ${message.first_name} ${message.last_name}</p>
                            <p><strong>Email:</strong> <a href="mailto:${message.email}">${message.email}</a></p>
                            <p><strong>Phone:</strong> ${message.phone || 'Not provided'}</p>
                            <p><strong>Subject:</strong> ${message.subject}</p>
                            <p><strong>Date:</strong> ${new Date(message.created_at).toLocaleString()}</p>
                            <p><strong>IP Address:</strong> ${message.ip_address}</p>
                            <p><strong>Status:</strong> ${message.status}</p>
                            <hr>
                            <p><strong>Message:</strong></p>
                            <p>${message.message.replace(/\n/g, '<br>')}</p>
                        `;
                        document.getElementById('messageContent').innerHTML = content;
                        document.getElementById('messageModal').style.display = 'block';
                    }
                });
        }
        
        function closeModal() {
            document.getElementById('messageModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('messageModal');
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>