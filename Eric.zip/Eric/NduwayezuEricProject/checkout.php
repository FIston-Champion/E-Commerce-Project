<?php
require_once 'config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];

// Get cart items
$session_id = $_SESSION['cart_session_id'] ?? session_id();
$cart_sql = "SELECT c.*, p.name, p.price, p.image, p.stock 
             FROM cart c 
             JOIN products p ON c.product_id = p.id 
             WHERE c.user_id = ?";
$stmt = $conn->prepare($cart_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

if (empty($cart_items)) {
    redirect('cart.php');
}

$subtotal = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart_items));
$shipping = 5.00;
$total = $subtotal + $shipping;

// Get user info
$user_sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($user_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Handle checkout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $address = clean_input($_POST['address']);
    $city = clean_input($_POST['city']);
    $phone = clean_input($_POST['phone']);
    $payment_method = clean_input($_POST['payment_method']);
    
    // Generate order number
    $order_number = 'ORD-' . time() . '-' . rand(1000, 9999);
    
    // Insert order with pending payment
    $status = 'pending';
    $payment_status = 'pending';
    $insert_order = "INSERT INTO orders (user_id, order_number, total_amount, shipping_fee, status, payment_method, payment_status, shipping_address, shipping_city, created_at) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($insert_order);
    $stmt->bind_param("isddsssss", $user_id, $order_number, $total, $shipping, $status, $payment_method, $payment_status, $address, $city);
    $stmt->execute();
    $order_id = $stmt->insert_id;
    
    // Insert order items
    foreach ($cart_items as $item) {
        $item_total = $item['price'] * $item['quantity'];
        $insert_item = "INSERT INTO order_items (order_id, product_id, product_name, product_price, quantity, subtotal, created_at) 
                       VALUES (?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $conn->prepare($insert_item);
        $stmt->bind_param("iisdid", $order_id, $item['product_id'], $item['name'], $item['price'], $item['quantity'], $item_total);
        $stmt->execute();
    }
    
    // Store order info in session for payment
    $_SESSION['pending_order'] = [
        'order_id' => $order_id,
        'order_number' => $order_number,
        'amount' => $total,
        'phone' => $phone,
        'user_id' => $user_id
    ];
    
    // Redirect based on payment method
    if ($payment_method === 'MTN Mobile Money') {
        redirect('payment_momo.php');
    } elseif ($payment_method === 'Airtel Money') {
        redirect('payment_airtel.php');
    } else {
        // Cash on Delivery - mark as confirmed
        $update_sql = "UPDATE orders SET payment_status = 'confirmed' WHERE id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        
        // Clear cart
        $clear_cart = "DELETE FROM cart WHERE user_id = ?";
        $stmt = $conn->prepare($clear_cart);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        
        $_SESSION['order_success'] = $order_number;
        redirect('order_success.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --success: #10b981;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; --border: #e2e8f0;
        }
        body { font-family: 'Poppins', sans-serif; background: var(--surface); color: var(--text); }
        .container { max-width: 1200px; margin: 0 auto; padding: 2rem; }
        
        .navbar {
            background: var(--background); box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
        }
        .nav-wrapper {
            max-width: 1200px; margin: 0 auto; padding: 1rem 2rem;
            display: flex; justify-content: space-between; align-items: center;
        }
        .logo {
            font-size: 1.5rem; font-weight: 800; color: var(--primary);
            text-decoration: none; display: flex; align-items: center; gap: 0.5rem;
        }
        
        .page-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; padding: 3rem 0; text-align: center; margin-bottom: 2rem; border-radius: 20px;
        }
        .page-header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
        
        .layout { display: grid; grid-template-columns: 1fr 400px; gap: 2rem; }
        .card { background: var(--background); padding: 2rem; border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.08); }
        
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 600; }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%; padding: 1rem; border: 2px solid var(--border);
            border-radius: 10px; font-family: inherit; font-size: 1rem;
            background: var(--background); color: var(--text);
        }
        .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
            outline: none; border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99,102,241,0.1);
        }
        .payment-select {
            cursor: pointer; font-weight: 500;
        }
        .payment-select option {
            padding: 1rem; font-size: 1rem;
        }
        
        .btn {
            padding: 1.25rem 2rem; border: none; border-radius: 50px;
            font-weight: 700; cursor: pointer; width: 100%; font-size: 1.1rem;
            display: flex; align-items: center; justify-content: center; gap: 0.5rem;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
        }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 25px rgba(99,102,241,0.3); }
        
        .summary-row {
            display: flex; justify-content: space-between;
            padding: 0.75rem 0; border-bottom: 1px solid var(--border);
        }
        .summary-total {
            font-size: 1.5rem; font-weight: 700;
            border-top: 2px solid var(--text); padding-top: 1rem; margin-top: 1rem;
        }
        
        .order-item {
            display: flex; gap: 1rem; margin-bottom: 1rem;
            padding-bottom: 1rem; border-bottom: 1px solid var(--border);
        }
        .order-item img { width: 60px; height: 60px; object-fit: cover; border-radius: 8px; }
        
        @media (max-width: 968px) {
            .layout { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-wrapper">
            <a href="index.php" class="logo">
                <i class="fas fa-store"></i> Artisan Market
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-lock"></i> Secure Checkout</h1>
            <p>Complete your order securely</p>
        </div>

        <div class="layout">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;">Shipping & Payment</h2>
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-user"></i> Full Name</label>
                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" readonly style="background: var(--surface);">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-phone"></i> Phone Number *</label>
                        <input type="tel" name="phone" placeholder="078XXXXXXX" 
                               pattern="07[2389][0-9]{7}" required
                               value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>"
                               title="Enter valid Rwandan phone number (e.g., 078XXXXXXX)">
                        <small style="color: #6b7280; display: block; margin-top: 0.5rem;">
                            📱 For delivery contact and Mobile Money payment
                        </small>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-map-marker-alt"></i> Shipping Address *</label>
                        <textarea name="address" rows="3" required placeholder="KG 123 St, Kicukiro"></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-city"></i> City *</label>
                        <input type="text" name="city" required placeholder="Kigali">
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-credit-card"></i> Payment Method *</label>
                        <select name="payment_method" required class="payment-select">
                            <option value="">-- Select Payment Method --</option>
                            <option value="MTN Mobile Money">💛 MTN Mobile Money (078XXXXXXX)</option>
                            <option value="Airtel Money">❤️ Airtel Money (073XXXXXXX)</option>
                            <option value="Cash on Delivery">💚 Cash on Delivery</option>
                        </select>
                        <small style="color: #6b7280; display: block; margin-top: 0.75rem; line-height: 1.6;">
                            <strong>Payment Options:</strong><br>
                            • <strong>MTN MoMo:</strong> Instant payment with MTN Mobile Money<br>
                            • <strong>Airtel Money:</strong> Instant payment with Airtel Money<br>
                            • <strong>Cash on Delivery:</strong> Pay when you receive your order
                        </small>
                    </div>
                    
                    <button type="submit" name="place_order" class="btn btn-primary">
                        <i class="fas fa-check-circle"></i> Continue to Payment ($<?php echo number_format($total, 2); ?>)
                    </button>
                </form>
            </div>

            <div>
                <div class="card" style="margin-bottom: 1.5rem;">
                    <h3 style="margin-bottom: 1.5rem;"><i class="fas fa-shopping-bag"></i> Order Summary</h3>
                    <?php foreach ($cart_items as $item): ?>
                        <div class="order-item">
                            <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="">
                            <div style="flex: 1;">
                                <h4 style="font-size: 1rem; margin-bottom: 0.25rem;"><?php echo htmlspecialchars($item['name']); ?></h4>
                                <p style="color: #6b7280; font-size: 0.9rem;">Qty: <?php echo $item['quantity']; ?></p>
                            </div>
                            <div style="font-weight: 700; color: var(--primary);">$<?php echo number_format($item['price'] * $item['quantity'], 2); ?></div>
                        </div>
                    <?php endforeach; ?>
                    
                    <div class="summary-row"><span>Subtotal</span><span>$<?php echo number_format($subtotal, 2); ?></span></div>
                    <div class="summary-row"><span>Shipping</span><span>$<?php echo number_format($shipping, 2); ?></span></div>
                    <div class="summary-row summary-total">
                        <span>Total</span>
                        <span style="color: var(--primary);">$<?php echo number_format($total, 2); ?></span>
                    </div>
                </div>

                <div class="card">
                    <h3 style="margin-bottom: 1rem;"><i class="fas fa-shield-alt"></i> Secure Payment</h3>
                    <p style="color: #6b7280; font-size: 0.875rem; line-height: 1.6;">
                        Your payment is secure and encrypted. We support MTN Mobile Money, Airtel Money, and Cash on Delivery for your convenience.
                    </p>
                </div>
            </div>
        </div>
    </div>

</body>
</html>