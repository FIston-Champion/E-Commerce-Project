<?php
require_once 'config.php';

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get product details
$product_sql = "SELECT p.*, u.full_name as artisan_name 
                FROM products p 
                LEFT JOIN users u ON p.user_id = u.id 
                WHERE p.id = ? AND p.status = 'active'";
$stmt = $conn->prepare($product_sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    redirect('products.php');
}

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    if (!is_logged_in()) {
        $_SESSION['error'] = "Please login to write a review.";
        redirect('login.php');
    }
    
    $user_id = $_SESSION['user_id'];
    $rating = (int)$_POST['rating'];
    $comment = clean_input($_POST['comment']);
    
    // Check if user has purchased this product
    $check_purchase = "SELECT COUNT(*) as count FROM order_items oi 
                      JOIN orders o ON oi.order_id = o.id 
                      WHERE o.user_id = ? AND oi.product_id = ? AND o.payment_status = 'paid'";
    $stmt = $conn->prepare($check_purchase);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $purchased = $stmt->get_result()->fetch_assoc()['count'] > 0;
    
    if (!$purchased) {
        $_SESSION['error'] = "You can only review products you've purchased.";
    } else {
        // Check if already reviewed
        $check_review = "SELECT id FROM reviews WHERE user_id = ? AND product_id = ?";
        $stmt = $conn->prepare($check_review);
        $stmt->bind_param("ii", $user_id, $product_id);
        $stmt->execute();
        $existing = $stmt->get_result()->fetch_assoc();
        
        if ($existing) {
            // Update existing review
            $update_sql = "UPDATE reviews SET rating = ?, comment = ?, updated_at = NOW() WHERE id = ?";
            $stmt = $conn->prepare($update_sql);
            $stmt->bind_param("isi", $rating, $comment, $existing['id']);
            $stmt->execute();
            $_SESSION['success'] = "Review updated successfully!";
        } else {
            // Insert new review
            $insert_sql = "INSERT INTO reviews (product_id, user_id, rating, comment, status, created_at) 
                          VALUES (?, ?, ?, ?, 'approved', NOW())";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bind_param("iiis", $product_id, $user_id, $rating, $comment);
            $stmt->execute();
            $_SESSION['success'] = "Review submitted successfully!";
        }
    }
    
    redirect("product_detail.php?id=$product_id");
}

// Get all approved reviews for this product
$reviews_sql = "SELECT r.*, u.full_name 
                FROM reviews r 
                JOIN users u ON r.user_id = u.id 
                WHERE r.product_id = ? AND r.status = 'approved' 
                ORDER BY r.created_at DESC";
$stmt = $conn->prepare($reviews_sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$reviews = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Calculate average rating
$avg_rating = 0;
if (!empty($reviews)) {
    $avg_rating = array_sum(array_column($reviews, 'rating')) / count($reviews);
}

// Check if current user can review
$can_review = false;
if (is_logged_in()) {
    $user_id = $_SESSION['user_id'];
    $check_sql = "SELECT COUNT(*) as count FROM order_items oi 
                  JOIN orders o ON oi.order_id = o.id 
                  WHERE o.user_id = ? AND oi.product_id = ? AND o.payment_status = 'paid'";
    $stmt = $conn->prepare($check_sql);
    $stmt->bind_param("ii", $user_id, $product_id);
    $stmt->execute();
    $can_review = $stmt->get_result()->fetch_assoc()['count'] > 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --success: #10b981; --danger: #ef4444;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; --border: #e2e8f0;
        }
        body { font-family: 'Poppins', sans-serif; background: var(--surface); color: var(--text); }
        .container { max-width: 1200px; margin: 0 auto; padding: 2rem; }
        
        .navbar {
            background: var(--background); box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
        }
        .nav-wrapper {
            max-width: 1200px; margin: 0 auto; padding: 1rem 2rem;
            display: flex; justify-content: space-between; align-items: center;
        }
        .logo {
            font-size: 1.5rem; font-weight: 800; color: var(--primary);
            text-decoration: none; display: flex; align-items: center; gap: 0.5rem;
        }
        
        .product-layout { display: grid; grid-template-columns: 1fr 1fr; gap: 3rem; margin-bottom: 3rem; }
        .product-image {
            width: 100%; height: 500px; object-fit: cover;
            border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        .product-info {
            background: var(--background); padding: 2rem;
            border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        }
        .product-title { font-size: 2.5rem; margin-bottom: 1rem; }
        .product-price {
            font-size: 3rem; font-weight: 800; color: var(--primary); margin-bottom: 1rem;
        }
        .product-artisan {
            color: #6b7280; margin-bottom: 1.5rem; font-size: 1.1rem;
        }
        .product-description { color: #4b5563; line-height: 1.8; margin-bottom: 2rem; }
        
        .rating-display {
            display: flex; align-items: center; gap: 1rem; margin-bottom: 2rem;
        }
        .stars { color: #fbbf24; font-size: 1.5rem; }
        
        .btn {
            padding: 1rem 2rem; border: none; border-radius: 50px;
            font-weight: 600; cursor: pointer; text-decoration: none;
            display: inline-flex; align-items: center; justify-content: center; gap: 0.5rem;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; width: 100%; font-size: 1.2rem;
        }
        
        .reviews-section {
            background: var(--background); padding: 2rem;
            border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        }
        .review-form {
            background: var(--surface); padding: 2rem;
            border-radius: 15px; margin-bottom: 2rem;
        }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 600; }
        .form-group textarea {
            width: 100%; padding: 1rem; border: 2px solid var(--border);
            border-radius: 10px; font-family: inherit; resize: vertical;
        }
        .star-rating { display: flex; gap: 0.5rem; font-size: 2rem; }
        .star-rating input { display: none; }
        .star-rating label {
            cursor: pointer; color: #d1d5db;
            transition: color 0.2s;
        }
        .star-rating input:checked ~ label,
        .star-rating label:hover,
        .star-rating label:hover ~ label { color: #fbbf24; }
        
        .review-item {
            padding: 1.5rem 0; border-bottom: 1px solid var(--border);
        }
        .review-header {
            display: flex; justify-content: space-between; margin-bottom: 0.5rem;
        }
        .review-author { font-weight: 600; }
        .review-stars { color: #fbbf24; }
        .review-date { color: #6b7280; font-size: 0.9rem; }
        .review-comment { color: #4b5563; line-height: 1.6; }
        
        .alert {
            padding: 1rem; border-radius: 10px; margin-bottom: 1.5rem;
            display: flex; align-items: center; gap: 0.5rem;
        }
        .alert-success { background: #d1fae5; color: #065f46; }
        .alert-error { background: #fee2e2; color: #991b1b; }
        
        @media (max-width: 968px) {
            .product-layout { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-wrapper">
            <a href="index.php" class="logo">
                <i class="fas fa-store"></i> Artisan Market
            </a>
        </div>
    </nav>

    <div class="container">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <i class="fas fa-exclamation-circle"></i> <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>

        <div class="product-layout">
            <div>
                <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>" 
                     class="product-image">
            </div>
            
            <div class="product-info">
                <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                
                <div class="rating-display">
                    <div class="stars">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star<?php echo $i <= round($avg_rating) ? '' : '-o'; ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <span><?php echo number_format($avg_rating, 1); ?> (<?php echo count($reviews); ?> reviews)</span>
                </div>
                
                <div class="product-price">$<?php echo number_format($product['price'], 2); ?></div>
                
                <div class="product-artisan">
                    <i class="fas fa-user"></i> By <?php echo htmlspecialchars($product['artisan_name']); ?>
                </div>
                
                <p class="product-description"><?php echo htmlspecialchars($product['description']); ?></p>
                
                <form method="POST" action="cart.php">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <input type="hidden" name="action" value="add">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-cart-plus"></i> Add to Cart
                    </button>
                </form>
            </div>
        </div>

        <div class="reviews-section">
            <h2 style="margin-bottom: 2rem;"><i class="fas fa-star"></i> Customer Reviews</h2>
            
            <?php if ($can_review): ?>
                <div class="review-form">
                    <h3 style="margin-bottom: 1.5rem;">Write a Review</h3>
                    <form method="POST">
                        <div class="form-group">
                            <label>Rating *</label>
                            <div class="star-rating">
                                <input type="radio" name="rating" value="5" id="star5" required>
                                <label for="star5"><i class="fas fa-star"></i></label>
                                <input type="radio" name="rating" value="4" id="star4">
                                <label for="star4"><i class="fas fa-star"></i></label>
                                <input type="radio" name="rating" value="3" id="star3">
                                <label for="star3"><i class="fas fa-star"></i></label>
                                <input type="radio" name="rating" value="2" id="star2">
                                <label for="star2"><i class="fas fa-star"></i></label>
                                <input type="radio" name="rating" value="1" id="star1">
                                <label for="star1"><i class="fas fa-star"></i></label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Your Review *</label>
                            <textarea name="comment" rows="4" placeholder="Share your thoughts about this product..." required></textarea>
                        </div>
                        
                        <button type="submit" name="submit_review" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i> Submit Review
                        </button>
                    </form>
                </div>
            <?php elseif (!is_logged_in()): ?>
                <div style="background: #fef3c7; padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem;">
                    <i class="fas fa-info-circle"></i> Please <a href="login.php" style="color: var(--primary); font-weight: 600;">login</a> to write a review.
                </div>
            <?php else: ?>
                <div style="background: #fef3c7; padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem;">
                    <i class="fas fa-info-circle"></i> You can only review products you've purchased.
                </div>
            <?php endif; ?>
            
            <?php if (empty($reviews)): ?>
                <p style="text-align: center; color: #6b7280; padding: 2rem;">No reviews yet. Be the first to review this product!</p>
            <?php else: ?>
                <?php foreach ($reviews as $review): ?>
                    <div class="review-item">
                        <div class="review-header">
                            <div>
                                <div class="review-author"><?php echo htmlspecialchars($review['full_name']); ?></div>
                                <div class="review-stars">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="fas fa-star<?php echo $i <= $review['rating'] ? '' : '-o'; ?>"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <div class="review-date"><?php echo date('M d, Y', strtotime($review['created_at'])); ?></div>
                        </div>
                        <p class="review-comment"><?php echo htmlspecialchars($review['comment']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>