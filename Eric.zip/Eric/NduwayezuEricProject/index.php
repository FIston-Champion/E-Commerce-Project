<?php 
require_once 'config.php'; 

// Get featured/latest products from database
$featured_sql = "SELECT p.*, u.full_name as artisan_name 
                 FROM products p 
                 LEFT JOIN users u ON p.user_id = u.id 
                 WHERE p.status = 'active' 
                 ORDER BY p.created_at DESC 
                 LIMIT 4";
$featured_result = $conn->query($featured_sql);
$featured_products = $featured_result ? $featured_result->fetch_all(MYSQLI_ASSOC) : [];
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artisan Market - Discover Authentic Handmade Products</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --accent: #ec4899; --success: #10b981; --warning: #f59e0b; --danger: #ef4444;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; --text-light: #475569; --border: #e2e8f0;
            --gray-100: #f1f5f9; --gray-200: #e2e8f0; --gray-700: #334155; --gray-900: #0f172a;
        }

        [data-theme="dark"] {
            --background: #0f172a; --surface: #1e293b; --text: #f8fafc; --text-light: #cbd5e1; --border: #334155;
            --gray-100: #334155; --gray-200: #475569; --gray-700: #cbd5e1; --gray-900: #f8fafc;
        }

        body { font-family: 'Poppins', sans-serif; line-height: 1.6; color: var(--text); background: var(--background); transition: all 0.3s ease; overflow-x: hidden; }
        html { scroll-behavior: smooth; }
        .container { max-width: 1280px; margin: 0 auto; padding: 0 2rem; }
        
        /* Navigation */
        .navbar { background: var(--background); backdrop-filter: blur(20px); box-shadow: 0 4px 30px rgba(0,0,0,0.05); position: sticky; top: 0; z-index: 1000; border-bottom: 1px solid var(--border); animation: slideDown 0.5s ease; }
        @keyframes slideDown { from { transform: translateY(-100%); } to { transform: translateY(0); } }
        .nav-wrapper { display: flex; justify-content: space-between; align-items: center; padding: 1.25rem 0; }
        .logo { display: flex; align-items: center; gap: 0.75rem; font-size: 1.5rem; font-weight: 800; background: linear-gradient(135deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-decoration: none; transition: transform 0.3s ease; }
        .logo:hover { transform: scale(1.05); }
        .logo i { font-size: 2rem; background: linear-gradient(135deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .nav-links { display: flex; list-style: none; gap: 2.5rem; align-items: center; }
        .nav-links a { color: var(--text); font-weight: 500; font-size: 0.95rem; transition: color 0.3s ease; text-decoration: none; }
        .nav-links a:hover, .nav-links a.active { color: var(--primary); font-weight: 600; }
        .nav-actions { display: flex; align-items: center; gap: 1rem; }
        .user-info { display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 1.25rem; background: var(--surface); border-radius: 50px; transition: all 0.3s ease; border: 2px solid var(--border); }
        .user-info:hover { transform: translateY(-2px); box-shadow: 0 4px 15px rgba(99,102,241,0.2); }
        .user-avatar { width: 40px; height: 40px; border-radius: 50%; background: linear-gradient(135deg, var(--primary), var(--secondary)); color: var(--background); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 1.1rem; box-shadow: 0 4px 10px rgba(99,102,241,0.3); }
        .theme-toggle { width: 40px; height: 40px; border-radius: 50%; background: var(--surface); border: 2px solid var(--border); display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.3s ease; color: var(--text); }
        .theme-toggle:hover { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: var(--background); transform: rotate(180deg); }
        .nav-icon { position: relative; font-size: 1.35rem; color: var(--text); text-decoration: none; transition: all 0.3s ease; }
        .nav-icon:hover { color: var(--primary); transform: scale(1.1); }
        .cart-count { position: absolute; top: -8px; right: -8px; background: linear-gradient(135deg, var(--danger), var(--accent)); color: var(--background); font-size: 0.7rem; width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }
        
        .btn { display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.75rem 1.75rem; border: none; border-radius: 50px; font-weight: 600; font-size: 0.95rem; cursor: pointer; transition: all 0.3s ease; text-decoration: none; }
        .btn-primary { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: var(--background); box-shadow: 0 4px 15px rgba(99,102,241,0.3); }
        .btn-primary:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(99,102,241,0.4); }
        .btn-secondary { background: transparent; color: var(--primary); border: 2px solid var(--primary); }
        .btn-secondary:hover { background: var(--primary); color: var(--background); }
        .btn-white { background: var(--background); color: var(--primary); box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        .btn-white:hover { transform: translateY(-3px); box-shadow: 0 8px 30px rgba(0,0,0,0.15); }
        .btn-danger { background: linear-gradient(135deg, var(--danger), var(--accent)); color: var(--background); }
        .btn-sm { padding: 0.6rem 1.5rem; font-size: 0.875rem; }
        .btn-lg { padding: 1.1rem 2.5rem; font-size: 1.1rem; }
        
        /* Hero */
        .hero { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); position: relative; padding: 8rem 0 6rem; overflow: hidden; }
        .hero-content { position: relative; z-index: 1; text-align: center; color: #fff; animation: fadeInUp 1s ease; }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .hero h1 { font-size: 4rem; font-weight: 800; margin-bottom: 1.5rem; line-height: 1.2; text-shadow: 0 4px 20px rgba(0,0,0,0.2); }
        .hero h1 .highlight { background: linear-gradient(90deg, #fbbf24, #f59e0b); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        .hero p { font-size: 1.35rem; margin-bottom: 2.5rem; opacity: 0.95; max-width: 700px; margin-left: auto; margin-right: auto; }
        .hero-buttons { display: flex; gap: 1.5rem; justify-content: center; flex-wrap: wrap; }
        @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-20px); } }
        .floating { animation: float 3s ease-in-out infinite; }
        
        /* Stats */
        .stats { background: var(--background); padding: 3rem 0; margin-top: -4rem; position: relative; z-index: 2; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem; }
        .stat-card { background: var(--surface); padding: 2rem; border-radius: 20px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,0.08); transition: all 0.3s ease; border: 1px solid var(--border); }
        .stat-card:hover { transform: translateY(-10px); box-shadow: 0 15px 50px rgba(99,102,241,0.15); }
        .stat-number { font-size: 3rem; font-weight: 800; background: linear-gradient(135deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 0.5rem; }
        .stat-label { color: var(--text-light); font-weight: 500; font-size: 0.95rem; }
        
        /* Sections */
        section { padding: 6rem 0; }
        .section-header { text-align: center; margin-bottom: 4rem; }
        .section-title { font-size: 3rem; font-weight: 800; color: var(--text); margin-bottom: 1rem; }
        .section-subtitle { font-size: 1.2rem; color: var(--text-light); max-width: 600px; margin: 0 auto; }
        
        /* Categories */
        .categories { background: var(--surface); }
        .categories-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem; }
        .category-card { background: var(--background); padding: 2.5rem; border-radius: 25px; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,0.08); transition: all 0.4s ease; cursor: pointer; border: 2px solid transparent; text-decoration: none; display: block; }
        .category-card:hover { transform: translateY(-15px); box-shadow: 0 20px 60px rgba(99,102,241,0.2); border-color: var(--primary); }
        .category-icon { width: 100px; height: 100px; margin: 0 auto 1.5rem; background: linear-gradient(135deg, var(--primary), var(--secondary)); border-radius: 25px; display: flex; align-items: center; justify-content: center; font-size: 2.5rem; color: var(--background); box-shadow: 0 10px 30px rgba(99,102,241,0.3); transition: all 0.3s ease; }
        .category-card:hover .category-icon { transform: rotate(10deg) scale(1.1); }
        .category-card h3 { font-size: 1.5rem; font-weight: 700; color: var(--text); margin-bottom: 0.75rem; }
        .category-card p { color: var(--text-light); font-size: 0.95rem; }
        
        /* Products */
        .featured-products { background: var(--background); }
        .products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 2.5rem; margin-bottom: 3rem; }
        .product-card { background: var(--background); border-radius: 25px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.08); transition: all 0.4s ease; border: 2px solid var(--border); }
        .product-card:hover { transform: translateY(-10px); box-shadow: 0 20px 60px rgba(99,102,241,0.15); border-color: var(--primary); }
        .product-image { width: 100%; height: 280px; object-fit: cover; transition: transform 0.4s ease; }
        .product-card:hover .product-image { transform: scale(1.1); }
        .product-info { padding: 2rem; }
        .product-category { display: inline-block; padding: 0.4rem 1rem; background: linear-gradient(135deg, var(--primary), var(--secondary)); color: var(--background); border-radius: 50px; font-size: 0.8rem; font-weight: 600; margin-bottom: 1rem; }
        .product-title { font-size: 1.4rem; font-weight: 700; color: var(--text); margin-bottom: 0.75rem; }
        .product-price { font-size: 2rem; font-weight: 800; background: linear-gradient(135deg, var(--primary), var(--secondary)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 1.5rem; }
        
        /* Features */
        .features { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; }
        .features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 3rem; }
        .feature-card { text-align: center; padding: 2rem; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); border-radius: 25px; border: 2px solid rgba(255,255,255,0.2); transition: all 0.3s ease; }
        .feature-card:hover { background: rgba(255,255,255,0.15); transform: translateY(-10px); }
        .feature-icon { width: 120px; height: 120px; margin: 0 auto 2rem; background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 30px; display: flex; align-items: center; justify-content: center; font-size: 3.5rem; color: #fff; box-shadow: 0 10px 40px rgba(0,0,0,0.2); }
        .feature-card h3 { font-size: 1.6rem; margin-bottom: 1rem; font-weight: 700; }
        .feature-card p { opacity: 0.9; font-size: 1.05rem; }
        
        /* Footer */
        .footer { background: var(--gray-900); color: #fff; padding: 4rem 0 2rem; }
        .footer-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 3rem; margin-bottom: 3rem; }
        .footer h3 { font-size: 1.3rem; margin-bottom: 1.5rem; font-weight: 700; }
        .footer p, .footer a { color: rgba(255,255,255,0.7); line-height: 2; transition: color 0.3s ease; text-decoration: none; }
        .footer a:hover { color: #fff; }
        .footer-bottom { text-align: center; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.1); color: rgba(255,255,255,0.6); }
        
        /* Scroll to top */
        .scroll-top { position: fixed; bottom: 2rem; right: 2rem; width: 50px; height: 50px; background: linear-gradient(135deg, var(--primary), var(--secondary)); color: var(--background); border-radius: 50%; display: none; align-items: center; justify-content: center; cursor: pointer; font-size: 1.5rem; box-shadow: 0 4px 20px rgba(99,102,241,0.4); transition: all 0.3s ease; z-index: 999; }
        .scroll-top:hover { transform: translateY(-5px); box-shadow: 0 8px 30px rgba(99,102,241,0.5); }
        .scroll-top.show { display: flex; }
        
        @media (max-width: 768px) { .nav-links { display: none; } .hero h1 { font-size: 2.5rem; } .hero p { font-size: 1.1rem; } .section-title { font-size: 2rem; } .hero-buttons { flex-direction: column; } .user-info span { display: none; } }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="index.php" class="logo"><i class="fas fa-store"></i><span>Artisan Market</span></a>
                <ul class="nav-links">
                    <li><a href="index.php" class="active">Home</a></li>
                    <li><a href="products.php">Shop</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
                <div class="nav-actions">
                    <?php if (is_logged_in()): ?>
                        <div class="user-info">
                            <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
                            <span style="font-weight: 600; font-size: 0.95rem;"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                        </div>
                        <?php if (is_artisan()): ?>
                            <a href="artisan-dashboard.php" class="btn btn-primary btn-sm"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                        <?php endif; ?>
                        <a href="logout.php" class="btn btn-danger btn-sm"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    <?php else: ?>
                        <a href="login.php" class="btn btn-primary btn-sm"><i class="fas fa-sign-in-alt"></i> Login</a>
                        <a href="register.php" class="btn btn-secondary btn-sm"><i class="fas fa-user-plus"></i> Register</a>
                    <?php endif; ?>
                    <button class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark Mode"><i class="fas fa-moon" id="themeIcon"></i></button>
                    <a href="cart.php" class="nav-icon"><i class="fas fa-shopping-cart"></i><span class="cart-count">0</span></a>
                </div>
            </div>
        </div>
    </nav>

    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1 class="floating">Discover Authentic <br><span class="highlight">Handmade Products</span></h1>
                <p>Support local artisans and find unique, handcrafted items made with passion and love</p>
                <div class="hero-buttons">
                    <a href="products.php" class="btn btn-white btn-lg"><i class="fas fa-shopping-bag"></i> Browse Products</a>
                    <a href="register.php" class="btn btn-secondary btn-lg" style="border-color: #fff; color: #fff;"><i class="fas fa-store"></i> Become a Seller</a>
                </div>
            </div>
        </div>
    </section>

    <section class="stats">
        <div class="container">
            <div class="stats-grid">
                <div class="stat-card"><div class="stat-number">500+</div><div class="stat-label">Unique Products</div></div>
                <div class="stat-card"><div class="stat-number">200+</div><div class="stat-label">Local Artisans</div></div>
                <div class="stat-card"><div class="stat-number">1000+</div><div class="stat-label">Happy Customers</div></div>
                <div class="stat-card"><div class="stat-number">4.9★</div><div class="stat-label">Average Rating</div></div>
            </div>
        </div>
    </section>

    <section class="categories">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Browse by Category</h2>
                <p class="section-subtitle">Explore our diverse collection of handmade treasures</p>
            </div>
            <div class="categories-grid">
                <a href="products.php?category=jewelry" class="category-card">
                    <div class="category-icon"><i class="fas fa-gem"></i></div>
                    <h3>Jewelry</h3>
                    <p>Exquisite handcrafted necklaces, bracelets & earrings</p>
                </a>
                <a href="products.php?category=art" class="category-card">
                    <div class="category-icon"><i class="fas fa-palette"></i></div>
                    <h3>Art & Paintings</h3>
                    <p>Unique artistic pieces that tell a story</p>
                </a>
                <a href="products.php?category=woodwork" class="category-card">
                    <div class="category-icon"><i class="fas fa-hammer"></i></div>
                    <h3>Woodwork</h3>
                    <p>Handcrafted wooden items and furniture</p>
                </a>
                <a href="products.php?category=pottery" class="category-card">
                    <div class="category-icon"><i class="fas fa-wine-bottle"></i></div>
                    <h3>Pottery & Ceramics</h3>
                    <p>Beautiful clay and ceramic creations</p>
                </a>
            </div>
        </div>
    </section>

    <section class="featured-products">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Featured Products</h2>
                <p class="section-subtitle">Hand-picked selections from our finest artisans</p>
            </div>
            <div class="products-grid">
                <?php if (empty($featured_products)): ?>
                    <!-- Fallback to static products if database is empty -->
                    <div class="product-card">
                        <img src="https://images.unsplash.com/photo-1590736969955-71cc94901144?w=500" class="product-image" alt="Basket">
                        <div class="product-info">
                            <span class="product-category">Home Decor</span>
                            <h3 class="product-title">Handwoven Basket</h3>
                            <div class="product-price">$25.99</div>
                            <a href="products.php" class="btn btn-primary" style="width: 100%;"><i class="fas fa-shopping-cart"></i> Add to Cart</a>
                        </div>
                    </div>
                    <div class="product-card">
                        <img src="https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=500" class="product-image" alt="Vase">
                        <div class="product-info">
                            <span class="product-category">Art & Crafts</span>
                            <h3 class="product-title">Ceramic Vase</h3>
                            <div class="product-price">$45.50</div>
                            <a href="products.php" class="btn btn-primary" style="width: 100%;"><i class="fas fa-shopping-cart"></i> Add to Cart</a>
                        </div>
                    </div>
                    <div class="product-card">
                        <img src="https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=500" class="product-image" alt="Necklace">
                        <div class="product-info">
                            <span class="product-category">Jewelry</span>
                            <h3 class="product-title">Beaded Necklace</h3>
                            <div class="product-price">$18.99</div>
                            <a href="products.php" class="btn btn-primary" style="width: 100%;"><i class="fas fa-shopping-cart"></i> Add to Cart</a>
                        </div>
                    </div>
                    <div class="product-card">
                        <img src="https://images.unsplash.com/photo-1513519245088-0e12902e35ca?w=500" class="product-image" alt="Art">
                        <div class="product-info">
                            <span class="product-category">Art & Crafts</span>
                            <h3 class="product-title">Traditional Wall Art</h3>
                            <div class="product-price">$65.00</div>
                            <a href="products.php" class="btn btn-primary" style="width: 100%;"><i class="fas fa-shopping-cart"></i> Add to Cart</a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Display actual products from database -->
                    <?php foreach ($featured_products as $product): ?>
                        <div class="product-card">
                            <?php 
                            $image_src = !empty($product['image']) && file_exists($product['image']) 
                                ? htmlspecialchars($product['image']) 
                                : 'https://via.placeholder.com/400x300/6366f1/ffffff?text=No+Image';
                            ?>
                            <img src="<?php echo $image_src; ?>" 
                                 class="product-image" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 onerror="this.src='https://via.placeholder.com/400x300/6366f1/ffffff?text=Image+Not+Found'">
                            <div class="product-info">
                                <span class="product-category"><?php echo ucfirst(htmlspecialchars($product['category'])); ?></span>
                                <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                                <div class="product-price">$<?php echo number_format($product['price'], 2); ?></div>
                                <form method="POST" action="cart.php" style="width: 100%;">
                                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                    <input type="hidden" name="action" value="add">
                                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                                        <i class="fas fa-shopping-cart"></i> Add to Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <div style="text-align: center;"><a href="products.php" class="btn btn-primary btn-lg"><i class="fas fa-arrow-right"></i> View All Products</a></div>
        </div>
    </section>

    <section class="features">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title" style="color: #fff;">Why Choose Us</h2>
                <p class="section-subtitle" style="color: rgba(255,255,255,0.9);">Experience the best in handcrafted excellence</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-certificate"></i></div>
                    <h3>100% Authentic</h3>
                    <p>Every product is verified handmade by local artisans with guaranteed authenticity</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-shipping-fast"></i></div>
                    <h3>Fast Delivery</h3>
                    <p>Quick and reliable shipping to your doorstep with real-time tracking</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon"><i class="fas fa-heart"></i></div>
                    <h3>Support Local</h3>
                    <p>Directly support artisans and help preserve traditional craftsmanship</p>
                </div>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div><h3>About Artisan Market</h3><p>We connect talented local artisans with customers who appreciate handmade quality, authenticity, and craftsmanship.</p></div>
                <div><h3>Quick Links</h3><p><a href="products.php">Shop Products</a></p><p><a href="about.php">About Us</a></p><p><a href="contact.php">Contact</a></p><p><a href="register.php">Become a Seller</a></p></div>
                <div><h3>Customer Service</h3><p><a href="#">Help Center</a></p><p><a href="#">Shipping Info</a></p><p><a href="#">Returns & Refunds</a></p><p><a href="#">Privacy Policy</a></p></div>
                <div><h3>Contact Us</h3><p><i class="fas fa-map-marker-alt"></i> KN 4 Ave, Kigali, Rwanda</p><p><i class="fas fa-phone"></i> +250 788 123 456</p><p><i class="fas fa-envelope"></i> info@artisanmarket.com</p></div>
            </div>
            <div class="footer-bottom"><p>&copy; 2024 Artisan Market. All rights reserved. Made with <i class="fas fa-heart" style="color: #ec4899;"></i> for artisans</p></div>
        </div>
    </footer>

    <div class="scroll-top" id="scrollTop"><i class="fas fa-arrow-up"></i></div>

    <script>
        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            const icon = document.getElementById('themeIcon');
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme') || 'light';
            const icon = document.getElementById('themeIcon');
            document.documentElement.setAttribute('data-theme', savedTheme);
            icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        });
        
        const scrollTop = document.getElementById('scrollTop');
        window.addEventListener('scroll', () => {
            scrollTop.classList.toggle('show', window.pageYOffset > 300);
        });
        scrollTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
        
        const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        document.querySelectorAll('.product-card, .category-card, .feature-card').forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'all 0.6s ease';
            observer.observe(el);
        });
    </script>
</body>
</html>