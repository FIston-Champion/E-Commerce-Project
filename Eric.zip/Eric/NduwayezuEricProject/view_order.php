<?php
require_once 'config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$user_id = $_SESSION['user_id'];

// Get order details
$order_sql = "SELECT o.*, u.full_name, u.email 
              FROM orders o 
              JOIN users u ON o.user_id = u.id 
              WHERE o.id = ? AND o.user_id = ?";
$stmt = $conn->prepare($order_sql);
$stmt->bind_param("ii", $order_id, $user_id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    redirect('account.php');
}

// Get order items
$items_sql = "SELECT oi.*, p.image 
              FROM order_items oi 
              LEFT JOIN products p ON oi.product_id = p.id 
              WHERE oi.order_id = ?";
$stmt = $conn->prepare($items_sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Status progress
$status_steps = [
    'pending' => ['label' => 'Order Placed', 'icon' => 'fa-check-circle', 'color' => '#fbbf24'],
    'processing' => ['label' => 'Processing', 'icon' => 'fa-cog', 'color' => '#3b82f6'],
    'shipped' => ['label' => 'Shipped', 'icon' => 'fa-truck', 'color' => '#8b5cf6'],
    'delivered' => ['label' => 'Delivered', 'icon' => 'fa-box-open', 'color' => '#10b981']
];

$current_status_index = array_search($order['status'], array_keys($status_steps));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order #<?php echo $order['order_number']; ?> - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --success: #10b981; --danger: #ef4444;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; --border: #e2e8f0;
        }
        body { font-family: 'Poppins', sans-serif; background: var(--surface); color: var(--text); }
        .container { max-width: 1200px; margin: 0 auto; padding: 2rem; }
        
        .navbar {
            background: var(--background); box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            position: sticky; top: 0; z-index: 1000;
        }
        .nav-wrapper {
            max-width: 1200px; margin: 0 auto; padding: 1rem 2rem;
            display: flex; justify-content: space-between; align-items: center;
        }
        .logo {
            font-size: 1.5rem; font-weight: 800; color: var(--primary);
            text-decoration: none; display: flex; align-items: center; gap: 0.5rem;
        }
        
        .page-header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; padding: 3rem 2rem; border-radius: 20px; margin-bottom: 2rem;
            text-align: center;
        }
        .page-header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
        
        .card {
            background: var(--background); padding: 2rem;
            border-radius: 20px; box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
        }
        
        /* Progress Tracker */
        .progress-tracker {
            display: flex; justify-content: space-between;
            position: relative; padding: 2rem 0;
        }
        .progress-line {
            position: absolute; top: 50%; left: 0; right: 0;
            height: 4px; background: #e5e7eb; transform: translateY(-50%);
            z-index: 1;
        }
        .progress-line-active {
            position: absolute; top: 50%; left: 0;
            height: 4px; background: linear-gradient(90deg, var(--primary), var(--secondary));
            transform: translateY(-50%); z-index: 2;
            transition: width 0.5s ease;
        }
        .progress-step {
            position: relative; z-index: 3;
            display: flex; flex-direction: column; align-items: center;
            flex: 1;
        }
        .progress-icon {
            width: 80px; height: 80px; border-radius: 50%;
            background: var(--background); border: 4px solid #e5e7eb;
            display: flex; align-items: center; justify-content: center;
            font-size: 2rem; color: #9ca3af;
            transition: all 0.3s ease; margin-bottom: 1rem;
        }
        .progress-step.active .progress-icon,
        .progress-step.completed .progress-icon {
            border-color: var(--primary);
            color: var(--primary);
            background: linear-gradient(135deg, rgba(99,102,241,0.1), rgba(139,92,246,0.1));
        }
        .progress-step.completed .progress-icon {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
        }
        .progress-label {
            font-weight: 600; text-align: center; color: #6b7280;
        }
        .progress-step.active .progress-label,
        .progress-step.completed .progress-label {
            color: var(--primary);
        }
        
        .order-info {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem; margin-bottom: 2rem;
        }
        .info-box {
            background: var(--surface); padding: 1.5rem;
            border-radius: 15px; border-left: 4px solid var(--primary);
        }
        .info-label { color: #6b7280; font-size: 0.9rem; margin-bottom: 0.5rem; }
        .info-value { font-weight: 700; font-size: 1.1rem; }
        
        .status-badge {
            display: inline-flex; align-items: center; gap: 0.5rem;
            padding: 0.5rem 1rem; border-radius: 50px; font-weight: 600;
        }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-processing { background: #dbeafe; color: #1e40af; }
        .status-shipped { background: #e0e7ff; color: #4c1d95; }
        .status-delivered { background: #d1fae5; color: #065f46; }
        
        .order-items {
            border-top: 2px solid var(--border); padding-top: 2rem;
        }
        .order-item {
            display: grid; grid-template-columns: 80px 1fr auto;
            gap: 1.5rem; padding: 1.5rem 0;
            border-bottom: 1px solid var(--border);
        }
        .item-image {
            width: 80px; height: 80px; object-fit: cover;
            border-radius: 10px; background: var(--surface);
        }
        .item-details h4 { margin-bottom: 0.5rem; }
        .item-details p { color: #6b7280; }
        .item-price {
            text-align: right;
        }
        .item-price .price { font-size: 1.5rem; font-weight: 700; color: var(--primary); }
        
        .order-summary {
            background: var(--surface); padding: 2rem;
            border-radius: 15px; margin-top: 2rem;
        }
        .summary-row {
            display: flex; justify-content: space-between;
            padding: 1rem 0; border-bottom: 1px solid var(--border);
        }
        .summary-total {
            font-size: 1.5rem; font-weight: 700;
            border-top: 2px solid var(--text);
            padding-top: 1rem; margin-top: 1rem;
        }
        
        .btn {
            padding: 1rem 2rem; border: none; border-radius: 50px;
            font-weight: 600; cursor: pointer; text-decoration: none;
            display: inline-flex; align-items: center; gap: 0.5rem;
        }
        .btn-secondary {
            background: var(--surface); color: var(--text);
            border: 2px solid var(--border);
        }
        
        @media (max-width: 768px) {
            .progress-tracker { flex-direction: column; gap: 2rem; }
            .progress-line, .progress-line-active { display: none; }
            .order-item { grid-template-columns: 60px 1fr; }
            .item-price { grid-column: 1 / -1; text-align: left; }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-wrapper">
            <a href="index.php" class="logo">
                <i class="fas fa-store"></i> Artisan Market
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="page-header">
            <h1><i class="fas fa-receipt"></i> Order Details</h1>
            <p>Track your order status</p>
        </div>

        <div class="card">
            <h2 style="margin-bottom: 2rem;">Order Progress</h2>
            
            <div class="progress-tracker">
                <div class="progress-line"></div>
                <div class="progress-line-active" style="width: <?php echo (($current_status_index + 1) / count($status_steps)) * 100; ?>%;"></div>
                
                <?php foreach ($status_steps as $key => $step): ?>
                    <?php
                    $step_index = array_search($key, array_keys($status_steps));
                    $is_completed = $step_index < $current_status_index;
                    $is_active = $step_index === $current_status_index;
                    ?>
                    <div class="progress-step <?php echo $is_completed ? 'completed' : ($is_active ? 'active' : ''); ?>">
                        <div class="progress-icon">
                            <i class="fas <?php echo $step['icon']; ?>"></i>
                        </div>
                        <div class="progress-label"><?php echo $step['label']; ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="card">
            <h2 style="margin-bottom: 2rem;">Order Information</h2>
            
            <div class="order-info">
                <div class="info-box">
                    <div class="info-label">Order Number</div>
                    <div class="info-value"><?php echo htmlspecialchars($order['order_number']); ?></div>
                </div>
                
                <div class="info-box">
                    <div class="info-label">Order Date</div>
                    <div class="info-value"><?php echo date('M d, Y', strtotime($order['created_at'])); ?></div>
                </div>
                
                <div class="info-box">
                    <div class="info-label">Status</div>
                    <div class="info-value">
                        <span class="status-badge status-<?php echo $order['status']; ?>">
                            <i class="fas fa-circle" style="font-size: 0.5rem;"></i>
                            <?php echo ucfirst($order['status']); ?>
                        </span>
                    </div>
                </div>
                
                <div class="info-box">
                    <div class="info-label">Payment Status</div>
                    <div class="info-value">
                        <span class="status-badge status-<?php echo $order['payment_status']; ?>">
                            <i class="fas fa-circle" style="font-size: 0.5rem;"></i>
                            <?php echo ucfirst($order['payment_status']); ?>
                        </span>
                    </div>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-top: 2rem;">
                <div>
                    <h3 style="margin-bottom: 1rem;"><i class="fas fa-shipping-fast"></i> Shipping Address</h3>
                    <p style="color: #6b7280; line-height: 1.6;">
                        <?php echo nl2br(htmlspecialchars($order['shipping_address'])); ?><br>
                        <?php echo htmlspecialchars($order['shipping_city']); ?>
                    </p>
                </div>
                
                <div>
                    <h3 style="margin-bottom: 1rem;"><i class="fas fa-credit-card"></i> Payment Method</h3>
                    <p style="color: #6b7280;"><?php echo htmlspecialchars($order['payment_method']); ?></p>
                </div>
            </div>

            <div class="order-items">
                <h3 style="margin-bottom: 1.5rem;"><i class="fas fa-box"></i> Order Items</h3>
                
                <?php foreach ($items as $item): ?>
                    <div class="order-item">
                        <img src="<?php echo htmlspecialchars($item['image'] ?? 'placeholder.jpg'); ?>" 
                             alt="<?php echo htmlspecialchars($item['product_name']); ?>"
                             class="item-image">
                        
                        <div class="item-details">
                            <h4><?php echo htmlspecialchars($item['product_name']); ?></h4>
                            <p>Quantity: <?php echo $item['quantity']; ?> × $<?php echo number_format($item['product_price'], 2); ?></p>
                        </div>
                        
                        <div class="item-price">
                            <div class="price">$<?php echo number_format($item['subtotal'], 2); ?></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="order-summary">
                <div class="summary-row">
                    <span>Subtotal</span>
                    <span>$<?php echo number_format($order['total_amount'] - $order['shipping_fee'], 2); ?></span>
                </div>
                <div class="summary-row">
                    <span>Shipping Fee</span>
                    <span>$<?php echo number_format($order['shipping_fee'], 2); ?></span>
                </div>
                <div class="summary-row summary-total">
                    <span>Total</span>
                    <span style="color: var(--primary);">$<?php echo number_format($order['total_amount'], 2); ?></span>
                </div>
            </div>

            <div style="margin-top: 2rem; text-align: center;">
                <a href="account.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to My Orders
                </a>
            </div>
        </div>
    </div>
</body>
</html>