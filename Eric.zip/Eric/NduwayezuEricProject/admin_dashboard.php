<?php
require_once 'config.php';

// Check if user is logged in and is admin
if (!is_logged_in()) {
    redirect('admin_login.php');
}

if (!is_admin()) {
    redirect('index.php'); // Redirect non-admins to homepage
}

$page_title = "Admin Dashboard - Artisan Market";

// Get statistics
$stats_sql = "SELECT 
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM products) as total_products,
    (SELECT COUNT(*) FROM orders) as total_orders,
    (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE payment_status = 'paid') as total_revenue,
    (SELECT COUNT(*) FROM contact_messages WHERE status = 'unread') as unread_messages";
$stats = $conn->query($stats_sql)->fetch_assoc();

// Get recent orders
$orders_sql = "SELECT o.*, u.full_name FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 10";
$recent_orders = $conn->query($orders_sql)->fetch_all(MYSQLI_ASSOC);

// Get recent users
$users_sql = "SELECT * FROM users ORDER BY created_at DESC LIMIT 10";
$recent_users = $conn->query($users_sql)->fetch_all(MYSQLI_ASSOC);

// Get products
$products_sql = "SELECT p.*, u.full_name as artisan FROM products p LEFT JOIN users u ON p.user_id = u.id ORDER BY p.created_at DESC LIMIT 20";
$products = $conn->query($products_sql)->fetch_all(MYSQLI_ASSOC);

// Get contact messages
$messages_sql = "SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 20";
$messages = $conn->query($messages_sql)->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --accent: #ec4899; --success: #10b981; --warning: #f59e0b; --danger: #ef4444;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; --text-light: #475569; --border: #e2e8f0;
            --gray-100: #f1f5f9; --gray-900: #0f172a;
        }

        [data-theme="dark"] {
            --background: #0f172a; --surface: #1e293b; --text: #f8fafc; --text-light: #cbd5e1; --border: #334155;
            --gray-100: #334155; --gray-900: #f8fafc;
        }

        body { font-family: 'Poppins', sans-serif; background: var(--background); color: var(--text); transition: all 0.3s ease; }
        
        /* Header Navigation */
        .navbar {
            background: var(--background);
            backdrop-filter: blur(20px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid var(--border);
        }

        .container { max-width: 1400px; margin: 0 auto; padding: 0 2rem; }
        
        .nav-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1.25rem 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            font-size: 1.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-decoration: none;
        }

        .logo i {
            font-size: 2rem;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1.25rem;
            background: var(--surface);
            border-radius: 50px;
            border: 2px solid var(--border);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--background);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.1rem;
        }

        .theme-toggle {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--surface);
            border: 2px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            color: var(--text);
        }

        .theme-toggle:hover {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--background);
            transform: rotate(180deg);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 50px;
            font-weight: 600;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-primary { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: var(--background); }
        .btn-danger { background: linear-gradient(135deg, var(--danger), var(--accent)); color: var(--background); }
        .btn-sm { padding: 0.6rem 1.25rem; font-size: 0.85rem; }
        
        /* Dashboard Content */
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 3rem 2rem;
            border-radius: 25px;
            margin: 2rem 0;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }

        .dashboard-header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }

        .stat-card {
            background: var(--surface);
            padding: 2rem;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            border: 2px solid var(--border);
            transition: all 0.3s ease;
        }

        .stat-card:hover { transform: translateY(-10px); box-shadow: 0 15px 50px rgba(99,102,241,0.15); }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 15px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.75rem;
            margin-bottom: 1rem;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 0.5rem;
        }

        .stat-label { color: var(--text-light); font-weight: 500; }
        
        .tabs {
            display: flex;
            gap: 1rem;
            margin-bottom: 2rem;
            border-bottom: 2px solid var(--border);
            flex-wrap: wrap;
        }

        .tab {
            padding: 1rem 2rem;
            cursor: pointer;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
            font-weight: 600;
            color: var(--text-light);
        }

        .tab:hover, .tab.active {
            border-bottom-color: var(--primary);
            color: var(--primary);
        }

        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .card {
            background: var(--surface);
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            margin-bottom: 2rem;
            border: 2px solid var(--border);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: var(--gray-100);
            padding: 1rem;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid var(--border);
            color: var(--text);
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid var(--border);
            color: var(--text);
        }

        tr:hover { background: var(--gray-100); }
        
        .badge {
            padding: 0.375rem 0.75rem;
            border-radius: 50px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .badge-success { background: #dcfce7; color: #10b981; }
        .badge-warning { background: #fef3c7; color: #f59e0b; }
        .badge-danger { background: #fee2e2; color: #ef4444; }
        
        @media (max-width: 768px) {
            .tabs { overflow-x: auto; }
            .stat-card { padding: 1.5rem; }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="admin_dashboard.php" class="logo">
                    <i class="fas fa-shield-alt"></i>
                    <span>Admin Panel</span>
                </a>
                <div class="nav-actions">
                    <div class="user-info">
                        <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
                        <span style="font-weight: 600; font-size: 0.95rem;"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    </div>
                    <a href="index.php" class="btn btn-primary btn-sm">
                        <i class="fas fa-home"></i> Main Site
                    </a>
                    <button class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark Mode">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                    <a href="logout.php" class="btn btn-danger btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Dashboard Content -->
    <div class="container">
        <div class="dashboard-header">
            <h1><i class="fas fa-chart-line"></i> Admin Dashboard</h1>
            <p>Manage your e-commerce platform</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-number"><?php echo $stats['total_users']; ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-box"></i></div>
                <div class="stat-number"><?php echo $stats['total_products']; ?></div>
                <div class="stat-label">Total Products</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
                <div class="stat-number"><?php echo $stats['total_orders']; ?></div>
                <div class="stat-label">Total Orders</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-dollar-sign"></i></div>
                <div class="stat-number">$<?php echo number_format($stats['total_revenue'], 0); ?></div>
                <div class="stat-label">Total Revenue</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-envelope"></i></div>
                <div class="stat-number"><?php echo $stats['unread_messages']; ?></div>
                <div class="stat-label">Unread Messages</div>
            </div>
        </div>

        <div class="tabs">
            <div class="tab active" onclick="showTab('orders')">
                <i class="fas fa-shopping-bag"></i> Orders
            </div>
            <div class="tab" onclick="showTab('products')">
                <i class="fas fa-box"></i> Products
            </div>
            <div class="tab" onclick="showTab('users')">
                <i class="fas fa-users"></i> Users
            </div>
            <div class="tab" onclick="showTab('messages')">
                <i class="fas fa-envelope"></i> Messages
            </div>
        </div>

        <div id="orders" class="tab-content active">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;"><i class="fas fa-shopping-bag"></i> Recent Orders</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_orders as $order): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                                <td><?php echo htmlspecialchars($order['full_name']); ?></td>
                                <td><strong>$<?php echo number_format($order['total_amount'], 2); ?></strong></td>
                                <td><span class="badge badge-warning"><?php echo ucfirst($order['status']); ?></span></td>
                                <td><span class="badge badge-warning"><?php echo ucfirst($order['payment_status']); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="products" class="tab-content">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;"><i class="fas fa-box"></i> All Products</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Artisan</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($product['artisan'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($product['category']); ?></td>
                                <td><strong>$<?php echo number_format($product['price'], 2); ?></strong></td>
                                <td><?php echo $product['stock']; ?></td>
                                <td><span class="badge badge-success"><?php echo ucfirst($product['status']); ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="users" class="tab-content">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;"><i class="fas fa-users"></i> Recent Users</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>User Type</th>
                            <th>Status</th>
                            <th>Registered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_users as $user): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($user['full_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><span class="badge badge-success"><?php echo ucfirst($user['user_type']); ?></span></td>
                                <td><span class="badge badge-success"><?php echo ucfirst($user['status']); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="messages" class="tab-content">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;"><i class="fas fa-envelope"></i> Contact Messages</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($messages as $msg): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($msg['first_name'] . ' ' . $msg['last_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($msg['email']); ?></td>
                                <td><?php echo htmlspecialchars($msg['subject']); ?></td>
                                <td><?php echo substr(htmlspecialchars($msg['message']), 0, 50) . '...'; ?></td>
                                <td><span class="badge badge-warning"><?php echo ucfirst($msg['status']); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function showTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');
            event.target.classList.add('active');
        }

        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            const icon = document.getElementById('themeIcon');
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            
            icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }

        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme') || 'light';
            const icon = document.getElementById('themeIcon');
            
            document.documentElement.setAttribute('data-theme', savedTheme);
            icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        });
    </script>
</body>
</html>