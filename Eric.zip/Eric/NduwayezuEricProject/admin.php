<?php
require_once 'config.php';

// Check if user is logged in and is admin
if (!is_logged_in()) {
    redirect('admin_login.php');
}

if (!is_admin()) {
    redirect('index.php');
}

$page_title = "Admin Dashboard - Artisan Market";

// Handle DELETE operations
if (isset($_GET['delete'])) {
    $type = $_GET['delete'];
    $id = (int)$_GET['id'];
    
    if ($type === 'product') {
        // First, get the product image path
        $get_image = $conn->query("SELECT image FROM products WHERE id = $id");
        $product = $get_image->fetch_assoc();
        
        // Instead of deleting, set product status to 'inactive' to preserve order history
        $conn->query("UPDATE products SET status = 'inactive' WHERE id = $id");
        
        // Optionally delete the image file (commented out to keep history)
        // if ($product && !empty($product['image']) && file_exists($product['image'])) {
        //     unlink($product['image']);
        // }
        
        $_SESSION['message'] = "Product deactivated successfully! (Order history preserved)";
    } elseif ($type === 'user') {
        // Set user status to inactive instead of deleting
        $conn->query("UPDATE users SET status = 'inactive' WHERE id = $id");
        $_SESSION['message'] = "User deactivated successfully!";
    } elseif ($type === 'order') {
        // Delete order items first (child records)
        $conn->query("DELETE FROM order_items WHERE order_id = $id");
        // Then delete the order
        $conn->query("DELETE FROM orders WHERE id = $id");
        $_SESSION['message'] = "Order and related items deleted successfully!";
    } elseif ($type === 'message') {
        $conn->query("DELETE FROM contact_messages WHERE id = $id");
        $_SESSION['message'] = "Message deleted successfully!";
    }
    
    redirect('admin.php');
}

// Handle MESSAGE STATUS update
if (isset($_POST['mark_read'])) {
    $msg_id = (int)$_POST['message_id'];
    $conn->query("UPDATE contact_messages SET status = 'read' WHERE id = $msg_id");
    $_SESSION['message'] = "Message marked as read!";
    redirect('admin.php');
}

if (isset($_POST['mark_unread'])) {
    $msg_id = (int)$_POST['message_id'];
    $conn->query("UPDATE contact_messages SET status = 'unread' WHERE id = $msg_id");
    $_SESSION['message'] = "Message marked as unread!";
    redirect('admin.php');
}

// Handle RESPOND to message
if (isset($_POST['respond_message'])) {
    $msg_id = (int)$_POST['message_id'];
    $response = clean_input($_POST['response']);
    
    // Get message details
    $msg_sql = "SELECT * FROM contact_messages WHERE id = $msg_id";
    $msg_result = $conn->query($msg_sql);
    $message = $msg_result->fetch_assoc();
    
    // Update message with response (you can add email sending here later)
    $conn->query("UPDATE contact_messages SET status = 'responded', admin_response = '$response', responded_at = NOW() WHERE id = $msg_id");
    
    $_SESSION['message'] = "Response sent to " . $message['email'];
    redirect('admin.php');
}

// Get statistics with STOCK TRACKING
$stats_sql = "SELECT 
    (SELECT COUNT(*) FROM users) as total_users,
    (SELECT COUNT(*) FROM products) as total_products,
    (SELECT COUNT(*) FROM orders) as total_orders,
    (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE payment_status = 'paid') as total_revenue,
    (SELECT COUNT(*) FROM contact_messages WHERE status = 'unread') as unread_messages,
    (SELECT COUNT(*) FROM products WHERE stock < 10) as low_stock_products,
    (SELECT COALESCE(SUM(stock), 0) FROM products) as total_stock_items";
$stats = $conn->query($stats_sql)->fetch_assoc();

// Get recent orders with FULL details
$orders_sql = "SELECT o.*, u.full_name, u.email as user_email FROM orders o 
               JOIN users u ON o.user_id = u.id 
               ORDER BY o.created_at DESC LIMIT 20";
$recent_orders = $conn->query($orders_sql)->fetch_all(MYSQLI_ASSOC);

// Get all users
$users_sql = "SELECT * FROM users ORDER BY created_at DESC";
$all_users = $conn->query($users_sql)->fetch_all(MYSQLI_ASSOC);

// Get products with STOCK INFO
$products_sql = "SELECT p.*, u.full_name as artisan,
                 COALESCE((SELECT SUM(oi.quantity) FROM order_items oi 
                          JOIN orders o ON oi.order_id = o.id 
                          WHERE oi.product_id = p.id AND o.payment_status = 'paid'), 0) as total_sold
                 FROM products p 
                 LEFT JOIN users u ON p.user_id = u.id 
                 ORDER BY p.created_at DESC";
$products = $conn->query($products_sql)->fetch_all(MYSQLI_ASSOC);

// Get contact messages
$messages_sql = "SELECT * FROM contact_messages ORDER BY created_at DESC";
$messages = $conn->query($messages_sql)->fetch_all(MYSQLI_ASSOC);

// Calculate remaining stock for each product
foreach ($products as &$product) {
    $product['remaining_stock'] = $product['stock'] - $product['total_sold'];
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --accent: #ec4899; 
            --success: #10b981; --warning: #f59e0b; --danger: #ef4444;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; 
            --text-light: #475569; --border: #e2e8f0;
            --gray-100: #f1f5f9; --gray-900: #0f172a;
        }

        [data-theme="dark"] {
            --background: #0f172a; --surface: #1e293b; --text: #f8fafc; 
            --text-light: #cbd5e1; --border: #334155;
            --gray-100: #334155; --gray-900: #f8fafc;
        }

        body { font-family: 'Poppins', sans-serif; background: var(--background); color: var(--text); transition: all 0.3s ease; }
        
        /* Navigation - same as before */
        .navbar {
            background: var(--background);
            backdrop-filter: blur(20px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid var(--border);
        }

        .container { max-width: 1400px; margin: 0 auto; padding: 0 2rem; }
        
        .nav-wrapper { display: flex; justify-content: space-between; align-items: center; padding: 1.25rem 0; }

        .logo {
            display: flex; align-items: center; gap: 0.75rem; font-size: 1.5rem; font-weight: 800;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text; -webkit-text-fill-color: transparent; text-decoration: none;
        }

        .logo i {
            font-size: 2rem;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        }

        .nav-actions { display: flex; align-items: center; gap: 1rem; }

        .user-info {
            display: flex; align-items: center; gap: 0.75rem; padding: 0.5rem 1.25rem;
            background: var(--surface); border-radius: 50px; border: 2px solid var(--border);
        }

        .user-avatar {
            width: 40px; height: 40px; border-radius: 50%;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--background); display: flex; align-items: center; justify-content: center;
            font-weight: 700; font-size: 1.1rem; box-shadow: 0 4px 10px rgba(99,102,241,0.3);
        }

        .theme-toggle {
            width: 40px; height: 40px; border-radius: 50%; background: var(--surface);
            border: 2px solid var(--border); display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: all 0.3s ease; color: var(--text);
        }

        .theme-toggle:hover {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: var(--background); transform: rotate(180deg);
        }

        .btn {
            display: inline-flex; align-items: center; gap: 0.5rem; padding: 0.75rem 1.5rem;
            border: none; border-radius: 50px; font-weight: 600; font-size: 0.9rem;
            cursor: pointer; transition: all 0.3s ease; text-decoration: none;
        }

        .btn-primary { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: var(--background); box-shadow: 0 4px 15px rgba(99,102,241,0.3); }
        .btn-primary:hover { transform: translateY(-3px); box-shadow: 0 8px 25px rgba(99,102,241,0.4); }
        .btn-danger { background: linear-gradient(135deg, var(--danger), var(--accent)); color: var(--background); }
        .btn-success { background: linear-gradient(135deg, var(--success), #059669); color: var(--background); }
        .btn-warning { background: linear-gradient(135deg, var(--warning), #d97706); color: var(--background); }
        .btn-sm { padding: 0.5rem 1rem; font-size: 0.85rem; }
        .btn-xs { padding: 0.35rem 0.75rem; font-size: 0.8rem; }
        
        /* Dashboard Content */
        .dashboard-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white; padding: 3rem 2rem; border-radius: 25px; margin: 2rem 0;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
        }

        .dashboard-header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
        
        /* Success Message */
        .success-message {
            background: #d1fae5; border-left: 4px solid var(--success);
            color: #065f46; padding: 1rem; border-radius: 10px; margin: 1rem 0;
            animation: slideDown 0.5s ease;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .stats-grid {
            display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem; margin-bottom: 3rem;
        }

        .stat-card {
            background: var(--surface); padding: 1.75rem; border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08); border: 2px solid var(--border);
            transition: all 0.3s ease;
        }

        .stat-card:hover { transform: translateY(-10px); box-shadow: 0 15px 50px rgba(99,102,241,0.15); }
        
        .stat-icon {
            width: 60px; height: 60px; border-radius: 15px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; display: flex; align-items: center; justify-content: center;
            font-size: 1.75rem; margin-bottom: 1rem;
        }

        .stat-number {
            font-size: 2.5rem; font-weight: 800;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            margin-bottom: 0.5rem;
        }

        .stat-label { color: var(--text-light); font-weight: 500; font-size: 0.9rem; }
        
        .action-buttons { display: flex; gap: 0.5rem; flex-wrap: wrap; }
        
        .tabs {
            display: flex; gap: 1rem; margin-bottom: 2rem; border-bottom: 2px solid var(--border);
            flex-wrap: wrap; position: relative;
        }

        .tab {
            padding: 1rem 2rem; cursor: pointer; border-bottom: 3px solid transparent;
            transition: all 0.3s; font-weight: 600; color: var(--text-light);
        }

        .tab:hover, .tab.active { border-bottom-color: var(--primary); color: var(--primary); }

        .tab-content { display: none; }
        .tab-content.active { display: block; }
        
        .print-btn {
            position: absolute; right: 0; top: 0.5rem;
            background: var(--success); color: white; border: none;
            padding: 0.5rem 1.25rem; border-radius: 8px; cursor: pointer;
            font-weight: 600; display: flex; align-items: center; gap: 0.5rem;
        }
        
        .card {
            background: var(--surface); border-radius: 20px; padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08); margin-bottom: 2rem;
            border: 2px solid var(--border);
        }

        table { width: 100%; border-collapse: collapse; }
        th {
            background: var(--gray-100); padding: 1rem; text-align: left; font-weight: 600;
            border-bottom: 2px solid var(--border); color: var(--text); white-space: nowrap;
        }
        td { padding: 1rem; border-bottom: 1px solid var(--border); color: var(--text); }
        tr:hover { background: var(--gray-100); }
        
        .badge {
            padding: 0.375rem 0.75rem; border-radius: 50px; font-size: 0.85rem; font-weight: 600;
        }

        .badge-success { background: #dcfce7; color: #10b981; }
        .badge-warning { background: #fef3c7; color: #f59e0b; }
        .badge-danger { background: #fee2e2; color: #ef4444; }
        .badge-info { background: #dbeafe; color: #3b82f6; }
        
        /* Low Stock Warning */
        .low-stock { background: #fef3c7; color: #92400e; font-weight: 600; }
        .out-of-stock { background: #fee2e2; color: #991b1b; font-weight: 600; }
        
        /* Modal for Respond */
        .modal {
            display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.7); z-index: 9999; align-items: center; justify-content: center;
        }

        .modal.active { display: flex; }

        .modal-content {
            background: var(--background); padding: 2rem; border-radius: 20px;
            max-width: 600px; width: 90%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }

        .modal-header {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 1.5rem;
        }

        .modal-header h3 { font-size: 1.5rem; color: var(--text); }

        .close-modal {
            background: none; border: none; font-size: 2rem; cursor: pointer;
            color: var(--text-light); line-height: 1;
        }

        textarea {
            width: 100%; padding: 1rem; border: 2px solid var(--border);
            border-radius: 10px; font-family: inherit; min-height: 150px;
            background: var(--surface); color: var(--text); resize: vertical;
        }

        textarea:focus {
            outline: none; border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(99,102,241,0.1);
        }
        
        @media (max-width: 768px) {
            .tabs { overflow-x: auto; }
            .stat-card { padding: 1.5rem; }
            .user-info span { display: none; }
            table { font-size: 0.9rem; }
            th, td { padding: 0.75rem 0.5rem; }
            .action-buttons { flex-direction: column; }
            .btn-xs { width: 100%; justify-content: center; }
        }
        
        @media print {
            .navbar, .tabs, .action-buttons, .print-btn, .theme-toggle { display: none !important; }
            .card { box-shadow: none; border: 1px solid #ddd; }
            body { background: white; color: black; }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="admin.php" class="logo">
                    <i class="fas fa-shield-alt"></i>
                    <span>Admin Panel</span>
                </a>
                <div class="nav-actions">
                    <div class="user-info">
                        <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
                        <span style="font-weight: 600; font-size: 0.95rem;"><?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    </div>
                    <a href="index.php" class="btn btn-primary btn-sm">
                        <i class="fas fa-home"></i> Main Site
                    </a>
                    <button class="theme-toggle" onclick="toggleTheme()" title="Toggle Dark Mode">
                        <i class="fas fa-moon" id="themeIcon"></i>
                    </button>
                    <a href="logout.php" class="btn btn-danger btn-sm">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Dashboard Content -->
    <div class="container">
        <div class="dashboard-header">
            <h1><i class="fas fa-chart-line"></i> Admin Dashboard</h1>
            <p>Manage your e-commerce platform</p>
        </div>

        <?php if (isset($_SESSION['message'])): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
            </div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-number"><?php echo $stats['total_users']; ?></div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-box"></i></div>
                <div class="stat-number"><?php echo $stats['total_products']; ?></div>
                <div class="stat-label">Total Products</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
                <div class="stat-number"><?php echo $stats['total_orders']; ?></div>
                <div class="stat-label">Total Orders</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-dollar-sign"></i></div>
                <div class="stat-number">$<?php echo number_format($stats['total_revenue'], 0); ?></div>
                <div class="stat-label">Total Revenue</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-envelope"></i></div>
                <div class="stat-number"><?php echo $stats['unread_messages']; ?></div>
                <div class="stat-label">Unread Messages</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
                <div class="stat-number"><?php echo $stats['low_stock_products']; ?></div>
                <div class="stat-label">Low Stock Items</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-cubes"></i></div>
                <div class="stat-number"><?php echo $stats['total_stock_items']; ?></div>
                <div class="stat-label">Total Stock Units</div>
            </div>
        </div>

        <div class="tabs">
            <div class="tab active" onclick="showTab('orders')">
                <i class="fas fa-shopping-bag"></i> Orders
            </div>
            <div class="tab" onclick="showTab('products')">
                <i class="fas fa-box"></i> Products & Stock
            </div>
            <div class="tab" onclick="showTab('users')">
                <i class="fas fa-users"></i> Users
            </div>
            <div class="tab" onclick="showTab('messages')">
                <i class="fas fa-envelope"></i> Messages
            </div>
            <button class="print-btn" onclick="window.print()">
                <i class="fas fa-print"></i> Print Report
            </button>
        </div>

        <!-- ORDERS TAB -->
        <div id="orders" class="tab-content active">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;"><i class="fas fa-shopping-bag"></i> Orders Management</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Order #</th>
                            <th>Customer</th>
                            <th>Email</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Payment</th>
                            <th>Date</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_orders as $order): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($order['order_number']); ?></strong></td>
                                <td><?php echo htmlspecialchars($order['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($order['user_email']); ?></td>
                                <td><strong>$<?php echo number_format($order['total_amount'], 2); ?></strong></td>
                                <td><span class="badge badge-warning"><?php echo ucfirst($order['status']); ?></span></td>
                                <td><span class="badge badge-<?php echo $order['payment_status'] === 'paid' ? 'success' : 'warning'; ?>"><?php echo ucfirst($order['payment_status']); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                <td class="no-print">
                                    <div class="action-buttons">
                                        <a href="edit_order.php?id=<?php echo $order['id']; ?>" class="btn btn-primary btn-xs">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <a href="?delete=order&id=<?php echo $order['id']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Delete this order?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- PRODUCTS TAB with STOCK TRACKING -->
        <div id="products" class="tab-content">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;"><i class="fas fa-box"></i> Products & Stock Management</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Artisan</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Initial Stock</th>
                            <th>Sold</th>
                            <th>Remaining</th>
                            <th>Status</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($product['artisan'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($product['category']); ?></td>
                                <td><strong>$<?php echo number_format($product['price'], 2); ?></strong></td>
                                <td><?php echo $product['stock']; ?></td>
                                <td><span class="badge badge-info"><?php echo $product['total_sold']; ?></span></td>
                                <td>
                                    <?php 
                                    $remaining = $product['remaining_stock'];
                                    if ($remaining <= 0) {
                                        echo '<span class="badge out-of-stock">OUT OF STOCK</span>';
                                    } elseif ($remaining < 10) {
                                        echo '<span class="badge low-stock">' . $remaining . ' (Low!)</span>';
                                    } else {
                                        echo '<span class="badge badge-success">' . $remaining . '</span>';
                                    }
                                    ?>
                                </td>
                                <td><span class="badge badge-success"><?php echo ucfirst($product['status']); ?></span></td>
                                <td class="no-print">
                                    <div class="action-buttons">
                                        <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn btn-primary btn-xs">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <a href="?delete=product&id=<?php echo $product['id']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Delete this product?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- USERS TAB -->
        <div id="users" class="tab-content">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;"><i class="fas fa-users"></i> Users Management</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>User Type</th>
                            <th>Status</th>
                            <th>Registered</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_users as $user): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($user['full_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><span class="badge badge-<?php echo $user['user_type'] === 'admin' ? 'danger' : 'success'; ?>"><?php echo ucfirst($user['user_type']); ?></span></td>
                                <td><span class="badge badge-<?php echo $user['status'] === 'active' ? 'success' : 'warning'; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                <td class="no-print">
                                    <div class="action-buttons">
                                        <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-primary btn-xs">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                            <a href="?delete=user&id=<?php echo $user['id']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Delete this user?')">
                                                <i class="fas fa-trash"></i> Delete
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- MESSAGES TAB -->
        <div id="messages" class="tab-content">
            <div class="card">
                <h2 style="margin-bottom: 1.5rem;"><i class="fas fa-envelope"></i> Contact Messages</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th class="no-print">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($messages as $msg): ?>
                            <tr style="<?php echo $msg['status'] === 'unread' ? 'background: #fef3c7;' : ''; ?>">
                                <td><strong><?php echo htmlspecialchars($msg['first_name'] . ' ' . $msg['last_name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($msg['email']); ?></td>
                                <td><?php echo htmlspecialchars($msg['subject']); ?></td>
                                <td><?php echo substr(htmlspecialchars($msg['message']), 0, 50) . '...'; ?></td>
                                <td><span class="badge badge-<?php echo $msg['status'] === 'unread' ? 'warning' : 'success'; ?>"><?php echo ucfirst($msg['status']); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></td>
                                <td class="no-print">
                                    <div class="action-buttons">
                                        <button class="btn btn-success btn-xs" onclick="openRespondModal(<?php echo $msg['id']; ?>, '<?php echo htmlspecialchars($msg['email']); ?>', '<?php echo htmlspecialchars($msg['first_name']); ?>')">
                                            <i class="fas fa-reply"></i> Respond
                                        </button>
                                        <?php if ($msg['status'] === 'unread'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="message_id" value="<?php echo $msg['id']; ?>">
                                                <button type="submit" name="mark_read" class="btn btn-primary btn-xs">
                                                    <i class="fas fa-check"></i> Mark Read
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="message_id" value="<?php echo $msg['id']; ?>">
                                                <button type="submit" name="mark_unread" class="btn btn-warning btn-xs">
                                                    <i class="fas fa-envelope"></i> Mark Unread
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <a href="?delete=message&id=<?php echo $msg['id']; ?>" class="btn btn-danger btn-xs" onclick="return confirm('Delete this message?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Respond Modal -->
    <div id="respondModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-reply"></i> Respond to Message</h3>
                <button class="close-modal" onclick="closeRespondModal()">&times;</button>
            </div>
            <form method="POST">
                <input type="hidden" name="message_id" id="respond_message_id">
                <p style="margin-bottom: 1rem; color: var(--text-light);">
                    Responding to: <strong id="respond_email"></strong>
                </p>
                <textarea name="response" placeholder="Type your response here..." required></textarea>
                <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                    <button type="submit" name="respond_message" class="btn btn-success" style="flex: 1;">
                        <i class="fas fa-paper-plane"></i> Send Response
                    </button>
                    <button type="button" class="btn btn-danger" style="flex: 1;" onclick="closeRespondModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showTab(tabName) {
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.getElementById(tabName).classList.add('active');
            event.target.closest('.tab').classList.add('active');
        }

        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            const icon = document.getElementById('themeIcon');
            
            html.setAttribute('data-theme', newTheme);
            localStorage.setItem('theme', newTheme);
            
            icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }

        document.addEventListener('DOMContentLoaded', function() {
            const savedTheme = localStorage.getItem('theme') || 'light';
            const icon = document.getElementById('themeIcon');
            
            document.documentElement.setAttribute('data-theme', savedTheme);
            icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        });

        function openRespondModal(messageId, email, name) {
            document.getElementById('respond_message_id').value = messageId;
            document.getElementById('respond_email').textContent = name + ' (' + email + ')';
            document.getElementById('respondModal').classList.add('active');
        }

        function closeRespondModal() {
            document.getElementById('respondModal').classList.remove('active');
        }

        document.getElementById('respondModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeRespondModal();
            }
        });
    </script>
</body>
</html>