<?php
$password = 'eric12';
$hash = password_hash($password, PASSWORD_DEFAULT);
echo "Copy this hash:<br>";
echo "<textarea rows='3' cols='80'>$hash</textarea>";
?>