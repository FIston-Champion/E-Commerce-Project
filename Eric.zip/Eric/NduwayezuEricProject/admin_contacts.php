<?php
require_once 'config.php';

// Check if user is admin (you can add proper authentication later)
// For now, anyone can access - add authentication in production!

// Get all contact messages
$sql = "SELECT * FROM contact_messages ORDER BY created_at DESC";
$result = $conn->query($sql);
$messages = [];
if ($result) {
    $messages = $result->fetch_all(MYSQLI_ASSOC);
}

// Get statistics
$total_messages = count($messages);
$unread_count = 0;
$read_count = 0;
foreach ($messages as $msg) {
    if ($msg['status'] === 'unread') $unread_count++;
    if ($msg['status'] === 'read') $read_count++;
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $message_id = (int)$_POST['message_id'];
    $new_status = clean_input($_POST['status']);
    
    $update_sql = "UPDATE contact_messages SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $new_status, $message_id);
    $stmt->execute();
    $stmt->close();
    
    header("Location: admin_contacts.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Messages - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root { --primary-color: #2563eb; --success-color: #10b981; --warning-color: #f59e0b; --danger-color: #ef4444; --dark-color: #1f2937; --light-color: #f3f4f6; --white: #fff; --border-color: #e5e7eb; --text-color: #374151; --shadow: 0 4px 6px rgba(0,0,0,0.1); }
        body { font-family: 'Segoe UI', sans-serif; background: var(--light-color); color: var(--text-color); }
        .container { max-width: 1400px; margin: 0 auto; padding: 2rem; }
        .header { background: linear-gradient(135deg, var(--primary-color), #7c3aed); color: var(--white); padding: 2rem; border-radius: 1rem; margin-bottom: 2rem; }
        .header h1 { font-size: 2rem; margin-bottom: 0.5rem; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
        .stat-card { background: var(--white); padding: 1.5rem; border-radius: 1rem; box-shadow: var(--shadow); }
        .stat-card h3 { color: var(--text-color); font-size: 0.875rem; margin-bottom: 0.5rem; }
        .stat-card .number { font-size: 2rem; font-weight: 700; color: var(--primary-color); }
        .messages-table { background: var(--white); border-radius: 1rem; padding: 1.5rem; box-shadow: var(--shadow); overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th { background: var(--light-color); padding: 1rem; text-align: left; font-weight: 600; border-bottom: 2px solid var(--border-color); }
        td { padding: 1rem; border-bottom: 1px solid var(--border-color); }
        tr:hover { background: var(--light-color); }
        .badge { padding: 0.375rem 0.75rem; border-radius: 0.25rem; font-size: 0.875rem; font-weight: 500; }
        .badge-unread { background: #fef3c7; color: #f59e0b; }
        .badge-read { background: #dcfce7; color: #10b981; }
        .badge-replied { background: #dbeafe; color: var(--primary-color); }
        .btn { padding: 0.5rem 1rem; border: none; border-radius: 0.5rem; cursor: pointer; font-weight: 500; text-decoration: none; }
        .btn-sm { padding: 0.375rem 0.75rem; font-size: 0.875rem; }
        .btn-primary { background: var(--primary-color); color: var(--white); }
        .btn-success { background: var(--success-color); color: var(--white); }
        .message-preview { max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .nav-links { margin-bottom: 1.5rem; }
        .nav-links a { display: inline-block; padding: 0.75rem 1.5rem; background: var(--white); border-radius: 0.5rem; text-decoration: none; color: var(--text-color); margin-right: 1rem; font-weight: 500; box-shadow: var(--shadow); }
        .nav-links a:hover { background: var(--primary-color); color: var(--white); }
    </style>
</head>
<body>
    <div class="container">
        <div class="nav-links">
            <a href="index.php"><i class="fas fa-home"></i> Back to Site</a>
            <a href="admin.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        </div>

        <div class="header">
            <h1><i class="fas fa-envelope"></i> Contact Messages</h1>
            <p>Manage customer inquiries and messages</p>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Messages</h3>
                <div class="number"><?php echo $total_messages; ?></div>
            </div>
            <div class="stat-card">
                <h3>Unread Messages</h3>
                <div class="number" style="color: var(--warning-color);"><?php echo $unread_count; ?></div>
            </div>
            <div class="stat-card">
                <h3>Read Messages</h3>
                <div class="number" style="color: var(--success-color);"><?php echo $read_count; ?></div>
            </div>
        </div>

        <div class="messages-table">
            <h2 style="margin-bottom: 1.5rem;">All Messages</h2>
            
            <?php if (empty($messages)): ?>
                <p style="text-align: center; padding: 2rem; color: var(--text-color);">No messages yet.</p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Subject</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($messages as $msg): ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></td>
                                <td><?php echo htmlspecialchars($msg['first_name'] . ' ' . $msg['last_name']); ?></td>
                                <td><?php echo htmlspecialchars($msg['email']); ?></td>
                                <td><?php echo htmlspecialchars($msg['subject']); ?></td>
                                <td class="message-preview"><?php echo htmlspecialchars($msg['message']); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $msg['status']; ?>">
                                        <?php echo ucfirst($msg['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="message_id" value="<?php echo $msg['id']; ?>">
                                        <?php if ($msg['status'] === 'unread'): ?>
                                            <input type="hidden" name="status" value="read">
                                            <button type="submit" name="update_status" class="btn btn-success btn-sm">
                                                <i class="fas fa-check"></i> Mark Read
                                            </button>
                                        <?php else: ?>
                                            <input type="hidden" name="status" value="unread">
                                            <button type="submit" name="update_status" class="btn btn-primary btn-sm">
                                                <i class="fas fa-undo"></i> Unread
                                            </button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>