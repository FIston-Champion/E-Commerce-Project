<?php
require_once 'config.php';

if (!is_logged_in() || !is_admin()) {
    redirect('admin_login.php');
}

$product_id = (int)$_GET['id'];
$success = '';
$error = '';

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $name = clean_input($_POST['name']);
    $description = clean_input($_POST['description']);
    $category = clean_input($_POST['category']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    $status = clean_input($_POST['status']);
    $image_url = clean_input($_POST['image_url']);
    
    // Handle image upload if new file provided
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $filename = $_FILES['product_image']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($filetype), $allowed)) {
            if (!file_exists('uploads/products')) {
                mkdir('uploads/products', 0777, true);
            }
            
            $new_filename = uniqid() . '_' . time() . '.' . $filetype;
            $destination = 'uploads/products/' . $new_filename;
            
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $destination)) {
                // Delete old image if it exists and is a local file
                if (!empty($product['image']) && file_exists($product['image']) && strpos($product['image'], 'uploads/') === 0) {
                    unlink($product['image']);
                }
                $image_url = $destination;
            }
        }
    }
    
    $update_sql = "UPDATE products SET name = ?, description = ?, category = ?, price = ?, stock = ?, status = ?, image = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("sssdissi", $name, $description, $category, $price, $stock, $status, $image_url, $product_id);
    
    if ($stmt->execute()) {
        $success = "Product updated successfully!";
    } else {
        $error = "Error updating product: " . $stmt->error;
    }
}

// Get product details
$product_sql = "SELECT p.*, u.full_name as artisan FROM products p 
                LEFT JOIN users u ON p.user_id = u.id 
                WHERE p.id = ?";
$stmt = $conn->prepare($product_sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    redirect('admin.php');
}

// Get sold quantity
$sold_sql = "SELECT COALESCE(SUM(oi.quantity), 0) as total_sold FROM order_items oi 
             JOIN orders o ON oi.order_id = o.id 
             WHERE oi.product_id = ? AND o.payment_status = 'paid'";
$sold_stmt = $conn->prepare($sold_sql);
$sold_stmt->bind_param("i", $product_id);
$sold_stmt->execute();
$sold_result = $sold_stmt->get_result()->fetch_assoc();
$total_sold = $sold_result['total_sold'];
$remaining = $product['stock'] - $total_sold;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --success: #10b981; --danger: #ef4444;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; --border: #e2e8f0;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh; padding: 2rem;
        }
        .container {
            max-width: 800px; margin: 0 auto; background: var(--background);
            border-radius: 30px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; padding: 3rem 2rem; text-align: center;
        }
        .header i { font-size: 3rem; margin-bottom: 1rem; }
        .header h1 { font-size: 2.5rem; margin-bottom: 0.5rem; }
        .body { padding: 3rem 2.5rem; }
        .alert {
            padding: 1rem; border-radius: 15px; margin-bottom: 1.5rem;
            display: flex; align-items: center; gap: 0.75rem;
        }
        .alert-success { background: #d1fae5; border-left: 4px solid var(--success); color: #065f46; }
        .alert-error { background: #fee2e2; border-left: 4px solid var(--danger); color: #991b1b; }
        .stock-info {
            background: #f8fafc; padding: 1.5rem; border-radius: 15px;
            margin-bottom: 2rem; border: 2px solid var(--border);
        }
        .stock-row {
            display: flex; justify-content: space-between; padding: 0.75rem 0;
            border-bottom: 1px solid var(--border);
        }
        .stock-row:last-child { border-bottom: none; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label {
            display: block; margin-bottom: 0.75rem; font-weight: 600;
            color: var(--text); font-size: 0.95rem;
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%; padding: 1rem; border: 2px solid var(--border);
            border-radius: 15px; font-size: 1rem; font-family: inherit;
            background: var(--surface); color: var(--text);
        }
        .form-group textarea { min-height: 120px; resize: vertical; }
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none; border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(99,102,241,0.1);
        }
        .form-row {
            display: grid; grid-template-columns: repeat(2, 1fr); gap: 1.5rem;
        }
        .btn {
            width: 100%; padding: 1.1rem; border: none; border-radius: 15px;
            font-size: 1.1rem; font-weight: 700; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
            gap: 0.75rem; text-decoration: none; margin-top: 1rem;
        }
        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white; box-shadow: 0 8px 20px rgba(99,102,241,0.3);
        }
        .btn-primary:hover { transform: translateY(-3px); }
        .btn-secondary {
            background: linear-gradient(135deg, #6b7280, #4b5563); color: white;
        }
        @media (max-width: 768px) {
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-box-open"></i>
            <h1>Edit Product</h1>
            <p><?php echo htmlspecialchars($product['name']); ?></p>
        </div>

        <div class="body">
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="stock-info">
                <h3 style="margin-bottom: 1rem; color: var(--primary);">Stock Information</h3>
                <div class="stock-row">
                    <span style="font-weight: 600;">Artisan:</span>
                    <span><?php echo htmlspecialchars($product['artisan'] ?? 'N/A'); ?></span>
                </div>
                <div class="stock-row">
                    <span style="font-weight: 600;">Current Stock:</span>
                    <span><?php echo $product['stock']; ?> units</span>
                </div>
                <div class="stock-row">
                    <span style="font-weight: 600;">Total Sold:</span>
                    <span><?php echo $total_sold; ?> units</span>
                </div>
                <div class="stock-row">
                    <span style="font-weight: 600;">Remaining:</span>
                    <span style="font-weight: 700; color: <?php echo $remaining <= 0 ? '#ef4444' : ($remaining < 10 ? '#f59e0b' : '#10b981'); ?>">
                        <?php echo $remaining; ?> units
                        <?php if ($remaining <= 0) echo ' (OUT OF STOCK)'; ?>
                        <?php if ($remaining > 0 && $remaining < 10) echo ' (LOW STOCK)'; ?>
                    </span>
                </div>
            </div>

            <form method="POST">
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Product Name</label>
                    <input type="text" name="name" required value="<?php echo htmlspecialchars($product['name']); ?>">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Description</label>
                    <textarea name="description"><?php echo htmlspecialchars($product['description']); ?></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-list"></i> Category</label>
                        <select name="category" required>
                            <option value="pottery" <?php echo $product['category'] === 'pottery' ? 'selected' : ''; ?>>Pottery & Ceramics</option>
                            <option value="textiles" <?php echo $product['category'] === 'textiles' ? 'selected' : ''; ?>>Textiles & Fabrics</option>
                            <option value="jewelry" <?php echo $product['category'] === 'jewelry' ? 'selected' : ''; ?>>Jewelry</option>
                            <option value="woodwork" <?php echo $product['category'] === 'woodwork' ? 'selected' : ''; ?>>Woodwork</option>
                            <option value="art" <?php echo $product['category'] === 'art' ? 'selected' : ''; ?>>Art & Paintings</option>
                            <option value="leather" <?php echo $product['category'] === 'leather' ? 'selected' : ''; ?>>Leather Goods</option>
                            <option value="metalwork" <?php echo $product['category'] === 'metalwork' ? 'selected' : ''; ?>>Metalwork</option>
                            <option value="basketry" <?php echo $product['category'] === 'basketry' ? 'selected' : ''; ?>>Basketry</option>
                            <option value="other" <?php echo $product['category'] === 'other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-dollar-sign"></i> Price</label>
                        <input type="number" name="price" step="0.01" required value="<?php echo $product['price']; ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-cubes"></i> Stock Quantity</label>
                        <input type="number" name="stock" required value="<?php echo $product['stock']; ?>">
                        <small style="color: #6b7280; display: block; margin-top: 0.5rem;">
                            Update this to restock items
                        </small>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-toggle-on"></i> Status</label>
                        <select name="status" required>
                            <option value="active" <?php echo $product['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $product['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="out_of_stock" <?php echo $product['status'] === 'out_of_stock' ? 'selected' : ''; ?>>Out of Stock</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-image"></i> Current Image</label>
                    <?php if (!empty($product['image'])): ?>
                        <img src="<?php echo htmlspecialchars($product['image']); ?>" 
                             alt="Current product image" 
                             style="width: 100%; max-width: 300px; height: auto; border-radius: 10px; margin-bottom: 1rem; border: 2px solid var(--border);">
                    <?php else: ?>
                        <p style="color: var(--text-light);">No image set</p>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-upload"></i> Upload New Image (Optional)</label>
                    <input type="file" name="product_image" accept="image/*"
                           style="padding: 0.75rem; border: 2px dashed var(--primary); background: var(--surface); cursor: pointer;">
                    <small style="color: var(--text-light); display: block; margin-top: 0.5rem;">
                        📁 Select a new image to replace the current one
                    </small>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-link"></i> Or Keep Current Image Path</label>
                    <input type="text" name="image_url" value="<?php echo htmlspecialchars($product['image']); ?>" readonly
                           style="background: var(--gray-100); cursor: not-allowed;">
                    <small style="color: var(--text-light); display: block; margin-top: 0.5rem;">
                        📝 Current image path (upload new image above to change)
                    </small>
                </div>

                <button type="submit" name="update_product" class="btn btn-primary">
                    <i class="fas fa-save"></i> Update Product
                </button>
                
                <a href="admin.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </form>
        </div>
    </div>
</body>
</html>