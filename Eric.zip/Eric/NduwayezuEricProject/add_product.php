<?php
require_once 'config.php';

// Check if user is logged in and is admin
if (!is_logged_in()) {
    redirect('admin_login.php');
}

if (!is_admin()) {
    redirect('index.php');
}

$success = '';
$error = '';

// Handle product creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = clean_input($_POST['name']);
    $description = clean_input($_POST['description']);
    $category = clean_input($_POST['category']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    $user_id = $_SESSION['user_id']; // Admin's ID
    
    // ==========================================
    // IMAGE UPLOAD FROM COMPUTER (OPTIONAL)
    // ==========================================
    
    $image_url = ''; // Default empty - will use placeholder
    
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $filename = $_FILES['product_image']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($filetype), $allowed)) {
            // Create uploads directory if it doesn't exist
            if (!file_exists('uploads/products')) {
                mkdir('uploads/products', 0777, true);
            }
            
            // Generate unique filename
            $new_filename = uniqid() . '_' . time() . '.' . $filetype;
            $destination = 'uploads/products/' . $new_filename;
            
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $destination)) {
                $image_url = $destination;
            } else {
                $error = "Failed to upload image. Product will be created without image.";
            }
        } else {
            $error = "Invalid file type. Only JPG, PNG, GIF, WEBP allowed. Product will be created without image.";
        }
    }
    // If no file uploaded (error 4), that's OK - use placeholder
    
    // Validation
    if (empty($name) || empty($price) || empty($stock)) {
        $error = "Name, price, and stock are required.";
    } else {
        // Insert product
        $insert_sql = "INSERT INTO products (user_id, name, description, category, price, stock, image, status, created_at) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("isssdis", $user_id, $name, $description, $category, $price, $stock, $image_url);
        
        if ($stmt->execute()) {
            $success = "Product added successfully!";
            // Clear form
            $_POST = array();
        } else {
            $error = "Error adding product: " . $stmt->error;
        }
    }
}

// Get all artisans for assignment (optional)
$artisans_sql = "SELECT id, full_name FROM users WHERE user_type = 'artisan' AND status = 'active'";
$artisans = $conn->query($artisans_sql)->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product - Admin Panel</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root {
            --primary: #6366f1; --secondary: #8b5cf6; --accent: #ec4899; 
            --success: #10b981; --danger: #ef4444;
            --background: #ffffff; --surface: #f8fafc; --text: #0f172a; 
            --text-light: #475569; --border: #e2e8f0;
        }

        [data-theme="dark"] {
            --background: #0f172a; --surface: #1e293b; --text: #f8fafc; 
            --text-light: #cbd5e1; --border: #334155;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            background: var(--background);
            border-radius: 30px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }

        .header {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            padding: 3rem 2rem;
            text-align: center;
        }

        .header i {
            font-size: 3rem;
            margin-bottom: 1rem;
        }

        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .body {
            padding: 3rem 2.5rem;
        }

        .alert {
            padding: 1rem;
            border-radius: 15px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .alert-success {
            background: #d1fae5;
            border-left: 4px solid var(--success);
            color: #065f46;
        }

        .alert-error {
            background: #fee2e2;
            border-left: 4px solid var(--danger);
            color: #991b1b;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.75rem;
            font-weight: 600;
            color: var(--text);
            font-size: 0.95rem;
        }

        .form-group label i {
            margin-right: 0.5rem;
            color: var(--primary);
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 1rem;
            border: 2px solid var(--border);
            border-radius: 15px;
            font-size: 1rem;
            font-family: inherit;
            transition: all 0.3s ease;
            background: var(--surface);
            color: var(--text);
        }

        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
        }

        .btn {
            width: 100%;
            padding: 1.1rem;
            border: none;
            border-radius: 15px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.75rem;
            text-decoration: none;
            margin-top: 1rem;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3);
        }

        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 30px rgba(99, 102, 241, 0.4);
        }

        .btn-secondary {
            background: linear-gradient(135deg, #6b7280, #4b5563);
            color: white;
        }

        .footer {
            text-align: center;
            margin-top: 2rem;
        }

        .footer a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .info-box {
            background: #dbeafe;
            border-left: 4px solid #3b82f6;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            color: #1e40af;
        }

        .comment {
            background: #fef3c7;
            border-left: 4px solid #f59e0b;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1rem;
            color: #92400e;
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
            }
            .body {
                padding: 2rem 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <i class="fas fa-plus-circle"></i>
            <h1>Add New Product</h1>
            <p>Add products to your artisan marketplace</p>
        </div>

        <div class="body">
            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <div class="info-box">
                <strong>ℹ️ Product Information:</strong>
                Fill in all the details below to add a new product to your marketplace.
            </div>

            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Product Name *</label>
                    <input type="text" name="name" required placeholder="Handcrafted Wooden Bowl" value="<?php echo $_POST['name'] ?? ''; ?>">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Description</label>
                    <textarea name="description" placeholder="Describe your product..."><?php echo $_POST['description'] ?? ''; ?></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label><i class="fas fa-list"></i> Category *</label>
                        <select name="category" required>
                            <option value="">Select Category</option>
                            <option value="pottery">Pottery & Ceramics</option>
                            <option value="textiles">Textiles & Fabrics</option>
                            <option value="jewelry">Jewelry</option>
                            <option value="woodwork">Woodwork</option>
                            <option value="art">Art & Paintings</option>
                            <option value="leather">Leather Goods</option>
                            <option value="metalwork">Metalwork</option>
                            <option value="basketry">Basketry</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label><i class="fas fa-dollar-sign"></i> Price *</label>
                        <input type="number" name="price" step="0.01" required placeholder="29.99" value="<?php echo $_POST['price'] ?? ''; ?>">
                    </div>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-cubes"></i> Stock Quantity *</label>
                    <input type="number" name="stock" required placeholder="50" value="<?php echo $_POST['stock'] ?? ''; ?>">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-upload"></i> Upload Product Image</label>
                    <input type="file" name="product_image" accept="image/*"
                           style="padding: 0.75rem; border: 2px dashed var(--primary); background: var(--surface); cursor: pointer;">
                    <small style="color: var(--text-light); display: block; margin-top: 0.5rem;">
                        📁 Select image from your computer (JPG, PNG, GIF, WEBP - Max 5MB)
                    </small>
                    <small style="color: #10b981; display: block; margin-top: 0.25rem;">
                        ✅ Images will be saved to: uploads/products/ (Optional - will use placeholder if not provided)
                    </small>
                </div>

                <button type="submit" name="add_product" class="btn btn-primary">
                    <i class="fas fa-plus-circle"></i>
                    Add Product
                </button>

                <a href="admin.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i>
                    Back to Dashboard
                </a>
            </form>

            <div class="footer">
                <a href="admin.php">
                    <i class="fas fa-th-large"></i>
                    View All Products
                </a>
            </div>
        </div>
    </div>
</body>
</html>