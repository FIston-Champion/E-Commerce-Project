<?php
require_once 'config.php';

// If already logged in, redirect
if (is_logged_in()) {
    redirect('index.php');
}

// Language translations (shortened for brevity - same as before)
$translations = [
    'en' => ['title' => 'Register - Artisan Market', 'create_account' => 'Create Account', 'register_subtitle' => 'Join our community today', 'full_name' => 'Full Name', 'email' => 'Email', 'phone' => 'Phone Number', 'password' => 'Password', 'confirm_password' => 'Confirm Password', 'user_type' => 'Register As', 'select_type' => 'Select user type', 'customer' => 'Customer', 'artisan' => 'Artisan (Seller)', 'agree_terms' => 'I agree to the', 'terms' => 'Terms & Conditions', 'register_btn' => 'Create Account', 'have_account' => 'Already have an account?', 'login' => 'Login', 'home' => 'Home', 'products' => 'Products', 'about' => 'About', 'contact' => 'Contact'],
    'fr' => ['title' => 'S\'inscrire - Marché Artisan', 'create_account' => 'Créer un compte', 'register_subtitle' => 'Rejoignez notre communauté aujourd\'hui', 'full_name' => 'Nom complet', 'email' => 'Email', 'phone' => 'Numéro de téléphone', 'password' => 'Mot de passe', 'confirm_password' => 'Confirmer le mot de passe', 'user_type' => 'S\'inscrire en tant que', 'select_type' => 'Sélectionner le type', 'customer' => 'Client', 'artisan' => 'Artisan', 'agree_terms' => 'J\'accepte les', 'terms' => 'Conditions', 'register_btn' => 'Créer un compte', 'have_account' => 'Vous avez déjà un compte?', 'login' => 'Se connecter', 'home' => 'Accueil', 'products' => 'Produits', 'about' => 'À propos', 'contact' => 'Contact'],
    'es' => ['title' => 'Registrarse', 'create_account' => 'Crear cuenta', 'register_subtitle' => 'Únete hoy', 'full_name' => 'Nombre completo', 'email' => 'Correo', 'phone' => 'Teléfono', 'password' => 'Contraseña', 'confirm_password' => 'Confirmar', 'user_type' => 'Registrarse como', 'select_type' => 'Seleccionar tipo', 'customer' => 'Cliente', 'artisan' => 'Artesano', 'agree_terms' => 'Acepto', 'terms' => 'Términos', 'register_btn' => 'Crear cuenta', 'have_account' => '¿Ya tienes cuenta?', 'login' => 'Iniciar sesión', 'home' => 'Inicio', 'products' => 'Productos', 'about' => 'Acerca de', 'contact' => 'Contacto'],
    'sw' => ['title' => 'Jisajili', 'create_account' => 'Fungua Akaunti', 'register_subtitle' => 'Jiunge leo', 'full_name' => 'Jina Kamili', 'email' => 'Barua pepe', 'phone' => 'Simu', 'password' => 'Nenosiri', 'confirm_password' => 'Thibitisha', 'user_type' => 'Jisajili Kama', 'select_type' => 'Chagua aina', 'customer' => 'Mteja', 'artisan' => 'Msanii', 'agree_terms' => 'Ninakubali', 'terms' => 'Masharti', 'register_btn' => 'Fungua', 'have_account' => 'Una akaunti?', 'login' => 'Ingia', 'home' => 'Nyumbani', 'products' => 'Bidhaa', 'about' => 'Kuhusu', 'contact' => 'Wasiliana'],
    'rw' => ['title' => 'Kwiyandikisha', 'create_account' => 'Fungura Konti', 'register_subtitle' => 'Injira uyu munsi', 'full_name' => 'Amazina', 'email' => 'Imeri', 'phone' => 'Telefoni', 'password' => 'Ijambo', 'confirm_password' => 'Emeza', 'user_type' => 'Iyandikishe Nka', 'select_type' => 'Hitamo', 'customer' => 'Umukiriya', 'artisan' => 'Umukoranabuhanga', 'agree_terms' => 'Nemera', 'terms' => 'Amategeko', 'register_btn' => 'Fungura', 'have_account' => 'Ufite konti?', 'login' => 'Injira', 'home' => 'Ahabanza', 'products' => 'Ibicuruzwa', 'about' => 'Aho dukomoka', 'contact' => 'Duhamagare']
];

$lang = $_SESSION['lang'] ?? 'en';
if (isset($_GET['lang']) && array_key_exists($_GET['lang'], $translations)) {
    $lang = $_GET['lang'];
    $_SESSION['lang'] = $lang;
}
$t = $translations[$lang];

$error = '';
$success = '';

// Handle registration
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $fullName = clean_input($_POST['fullName']);
    $email = clean_input($_POST['email']);
    $phone = clean_input($_POST['phone']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $userType = clean_input($_POST['userType']);
    
    // Validation
    if (empty($fullName) || empty($email) || empty($password) || empty($userType)) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match!";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } else {
        // Check if email already exists
        $check_sql = "SELECT id FROM users WHERE email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $error = "Email already registered!";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new user
            $insert_sql = "INSERT INTO users (full_name, email, phone, password, user_type, status, created_at) VALUES (?, ?, ?, ?, ?, 'active', NOW())";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("sssss", $fullName, $email, $phone, $hashed_password, $userType);
            
            if ($insert_stmt->execute()) {
                $success = "Registration successful! Redirecting to login...";
                header("refresh:2;url=login.php");
            } else {
                $error = "Registration failed. Please try again.";
            }
            $insert_stmt->close();
        }
        $check_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $t['title']; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root { --primary-color: #2563eb; --secondary-color: #7c3aed; --success-color: #10b981; --danger-color: #ef4444; --dark-color: #1f2937; --light-color: #f3f4f6; --white: #ffffff; --border-color: #e5e7eb; --text-color: #374151; --text-light: #6b7280; --shadow: 0 4px 6px rgba(0,0,0,0.1); --shadow-lg: 0 10px 25px rgba(0,0,0,0.15); }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: var(--text-color); }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .navbar { background-color: var(--white); box-shadow: var(--shadow); position: sticky; top: 0; z-index: 1000; }
        .nav-wrapper { display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; }
        .logo { display: flex; align-items: center; gap: 0.5rem; font-size: 1.5rem; font-weight: 700; color: var(--primary-color); text-decoration: none; }
        .logo i { font-size: 1.75rem; }
        .nav-links { display: flex; list-style: none; gap: 2rem; }
        .nav-links a { color: var(--text-color); font-weight: 500; text-decoration: none; }
        .btn { display: inline-block; padding: 0.75rem 1.5rem; border: none; border-radius: 0.5rem; font-size: 1rem; font-weight: 500; cursor: pointer; text-decoration: none; }
        .btn-primary { background-color: var(--primary-color); color: var(--white); }
        .btn-sm { padding: 0.5rem 1rem; font-size: 0.875rem; }
        .btn-block { width: 100%; }
        .btn-lg { padding: 1rem 2rem; font-size: 1.125rem; }
        .auth-section { padding: 4rem 0; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: calc(100vh - 80px); }
        .auth-card { max-width: 600px; margin: 0 auto; background-color: var(--white); border-radius: 1rem; padding: 2.5rem; box-shadow: var(--shadow-lg); }
        .auth-header { text-align: center; margin-bottom: 2rem; }
        .auth-header i { font-size: 4rem; color: var(--primary-color); margin-bottom: 1rem; }
        .auth-header h2 { font-size: 2rem; margin-bottom: 0.5rem; color: var(--dark-color); }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        .form-group input, .form-group select { width: 100%; padding: 0.875rem; border: 2px solid var(--border-color); border-radius: 0.5rem; font-size: 1rem; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: var(--primary-color); }
        .checkbox-label { display: flex; align-items: center; gap: 0.5rem; }
        .alert { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1.5rem; }
        .alert-error { background-color: #fee2e2; border-left: 4px solid var(--danger-color); color: var(--danger-color); }
        .alert-success { background-color: #dcfce7; border-left: 4px solid var(--success-color); color: var(--success-color); }
        .link { color: var(--primary-color); text-decoration: none; }
        .auth-footer { text-align: center; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border-color); }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="index.php" class="logo"><i class="fas fa-store"></i><span>Artisan Market</span></a>
                <ul class="nav-links">
                    <li><a href="index.php"><?php echo $t['home']; ?></a></li>
                    <li><a href="products.php"><?php echo $t['products']; ?></a></li>
                    <li><a href="about.php"><?php echo $t['about']; ?></a></li>
                    <li><a href="contact.php"><?php echo $t['contact']; ?></a></li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="auth-section">
        <div class="container">
            <div class="auth-card">
                <div class="auth-header">
                    <i class="fas fa-user-plus"></i>
                    <h2><?php echo $t['create_account']; ?></h2>
                    <p><?php echo $t['register_subtitle']; ?></p>
                </div>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
                <?php endif; ?>

                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label><?php echo $t['full_name']; ?> *</label>
                        <input type="text" name="fullName" required value="<?php echo isset($_POST['fullName']) ? htmlspecialchars($_POST['fullName']) : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label><?php echo $t['email']; ?> *</label>
                        <input type="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label><?php echo $t['phone']; ?></label>
                        <input type="tel" name="phone" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label><?php echo $t['password']; ?> *</label>
                        <input type="password" name="password" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label><?php echo $t['confirm_password']; ?> *</label>
                        <input type="password" name="confirmPassword" required minlength="6">
                    </div>
                    <div class="form-group">
                        <label><?php echo $t['user_type']; ?> *</label>
                        <select name="userType" required>
                            <option value=""><?php echo $t['select_type']; ?></option>
                            <option value="customer"><?php echo $t['customer']; ?></option>
                            <option value="artisan"><?php echo $t['artisan']; ?></option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="terms" required>
                            <span><?php echo $t['agree_terms']; ?> <a href="#" class="link"><?php echo $t['terms']; ?></a></span>
                        </label>
                    </div>
                    <button type="submit" name="register" class="btn btn-primary btn-block btn-lg">
                        <i class="fas fa-user-plus"></i> <?php echo $t['register_btn']; ?>
                    </button>
                </form>

                <div class="auth-footer">
                    <p><?php echo $t['have_account']; ?> <a href="login.php" class="link"><?php echo $t['login']; ?></a></p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>