<?php
require_once 'config.php';

// Check if user is logged in and is artisan
if (!is_logged_in()) {
    redirect('login.php');
}

if (!is_artisan() && !is_admin()) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'];

// Get artisan's statistics
$stats_sql = "SELECT 
    (SELECT COUNT(*) FROM products WHERE user_id = ?) as my_products,
    (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi 
     JOIN products p ON oi.product_id = p.id 
     WHERE p.user_id = ?) as total_sales,
    (SELECT COALESCE(SUM(oi.subtotal), 0) FROM order_items oi 
     JOIN products p ON oi.product_id = p.id 
     WHERE p.user_id = ?) as total_revenue";
$stmt = $conn->prepare($stats_sql);
$stmt->bind_param("iii", $user_id, $user_id, $user_id);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc();

// Get artisan's products
$products_sql = "SELECT * FROM products WHERE user_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($products_sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$my_products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Handle add product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_product'])) {
    $name = clean_input($_POST['name']);
    $description = clean_input($_POST['description']);
    $category = clean_input($_POST['category']);
    $price = (float)$_POST['price'];
    $stock = (int)$_POST['stock'];
    
    // Handle image upload from computer
    $image_path = '';
    
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $filename = $_FILES['product_image']['name'];
        $filetype = pathinfo($filename, PATHINFO_EXTENSION);
        
        if (in_array(strtolower($filetype), $allowed)) {
            // Create uploads directory if it doesn't exist
            if (!file_exists('uploads/products')) {
                mkdir('uploads/products', 0777, true);
            }
            
            // Generate unique filename
            $new_filename = uniqid() . '_' . time() . '.' . $filetype;
            $destination = 'uploads/products/' . $new_filename;
            
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $destination)) {
                $image_path = $destination;
            }
        }
    }
    
    // Insert product with uploaded image
    if (!empty($image_path)) {
        $insert_sql = "INSERT INTO products (user_id, name, description, category, price, stock, image, status, created_at) 
                       VALUES (?, ?, ?, ?, ?, ?, ?, 'active', NOW())";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param("isssdis", $user_id, $name, $description, $category, $price, $stock, $image_path);
        
        if ($stmt->execute()) {
            $success = "Product added successfully!";
            header("Location: artisan-dashboard.php");
            exit;
        }
    } else {
        $error = "Please upload a product image.";
    }
}

// Handle delete product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    $product_id = (int)$_POST['product_id'];
    
    // Check if product has been ordered
    $check_orders_sql = "SELECT COUNT(*) as order_count FROM order_items WHERE product_id = ?";
    $stmt = $conn->prepare($check_orders_sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $order_check = $result->fetch_assoc();
    
    if ($order_check['order_count'] > 0) {
        // Product has orders - deactivate instead of delete
        $update_sql = "UPDATE products SET status = 'inactive' WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("ii", $product_id, $user_id);
        $stmt->execute();
        $_SESSION['message'] = "Product deactivated (has existing orders). Contact admin to permanently delete.";
    } else {
        // No orders - safe to delete completely
        // Get product image path before deleting
        $get_image_sql = "SELECT image FROM products WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($get_image_sql);
        $stmt->bind_param("ii", $product_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $product = $result->fetch_assoc();
        
        // Delete the product
        $delete_sql = "DELETE FROM products WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("ii", $product_id, $user_id);
        $stmt->execute();
        
        // Delete image file if it exists
        if ($product && !empty($product['image']) && file_exists($product['image'])) {
            unlink($product['image']);
        }
        
        $_SESSION['message'] = "Product deleted successfully!";
    }
    
    header("Location: artisan-dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artisan Dashboard - Artisan Market</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', sans-serif; background: #f3f4f6; }
        .container { max-width: 1400px; margin: 0 auto; padding: 2rem; }
        .header { background: linear-gradient(135deg, #2563eb, #7c3aed); color: #fff; padding: 2rem; border-radius: 1rem; margin-bottom: 2rem; }
        .header h1 { font-size: 2rem; margin-bottom: 0.5rem; }
        .user-info { display: flex; align-items: center; gap: 1rem; margin-top: 1rem; }
        .user-avatar { width: 50px; height: 50px; border-radius: 50%; background: rgba(255,255,255,0.3); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: 700; }
        .nav-actions { display: flex; gap: 1rem; margin-top: 1rem; }
        .btn { padding: 0.75rem 1.5rem; border: none; border-radius: 0.5rem; font-weight: 500; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-primary { background: #2563eb; color: #fff; }
        .btn-success { background: #10b981; color: #fff; }
        .btn-danger { background: #ef4444; color: #fff; }
        .btn-sm { padding: 0.5rem 1rem; font-size: 0.875rem; }
        .stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 1.5rem; margin-bottom: 2rem; }
        .stat-card { background: #fff; padding: 2rem; border-radius: 1rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .stat-card h3 { color: #6b7280; font-size: 0.875rem; margin-bottom: 0.5rem; }
        .stat-card .number { font-size: 2.5rem; font-weight: 700; color: #2563eb; }
        .card { background: #fff; padding: 2rem; border-radius: 1rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-bottom: 2rem; }
        .products-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1.5rem; }
        .product-card { border: 2px solid #e5e7eb; padding: 1rem; border-radius: 0.75rem; transition: all 0.3s; }
        .product-card:hover { border-color: #2563eb; transform: translateY(-5px); }
        .product-card img { width: 100%; height: 200px; object-fit: cover; border-radius: 0.5rem; margin-bottom: 1rem; }
        .product-card h3 { margin-bottom: 0.5rem; }
        .product-card .price { color: #2563eb; font-size: 1.5rem; font-weight: 700; margin: 0.5rem 0; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 0.875rem; border: 2px solid #e5e7eb; border-radius: 0.5rem; font-family: inherit; }
        .form-group textarea { resize: vertical; min-height: 100px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
        .modal.active { display: flex; }
        .modal-content { background: #fff; padding: 2rem; border-radius: 1rem; max-width: 600px; width: 90%; max-height: 90vh; overflow-y: auto; }
        .modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
        .close-modal { background: none; border: none; font-size: 2rem; cursor: pointer; color: #6b7280; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div>
                    <h1><i class="fas fa-palette"></i> Artisan Dashboard</h1>
                    <p>Manage your products and sales</p>
                    <div class="user-info">
                        <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?></div>
                        <div>
                            <div style="font-weight: 600; font-size: 1.125rem;"><?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
                            <div style="opacity: 0.8;"><?php echo htmlspecialchars($_SESSION['user_email']); ?></div>
                        </div>
                    </div>
                </div>
                <div class="nav-actions">
                    <a href="index.php" class="btn" style="background: rgba(255,255,255,0.2); color: #fff;"><i class="fas fa-home"></i> Home</a>
                    <a href="logout.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </div>

        <div class="stats">
            <div class="stat-card">
                <h3>My Products</h3>
                <div class="number"><?php echo $stats['my_products']; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Sales</h3>
                <div class="number"><?php echo $stats['total_sales']; ?></div>
            </div>
            <div class="stat-card">
                <h3>Revenue</h3>
                <div class="number">$<?php echo number_format($stats['total_revenue'], 2); ?></div>
            </div>
        </div>

        <?php if (isset($_SESSION['message'])): ?>
            <div style="background: #d1fae5; border-left: 4px solid #10b981; padding: 1rem; border-radius: 0.5rem; margin-bottom: 2rem; color: #065f46;">
                <i class="fas fa-check-circle"></i> <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <h2>My Products</h2>
                <button onclick="openModal()" class="btn btn-success">
                    <i class="fas fa-plus"></i> Add New Product
                </button>
            </div>

            <?php if (empty($my_products)): ?>
                <div style="text-align: center; padding: 4rem 2rem; color: #6b7280;">
                    <i class="fas fa-box-open" style="font-size: 4rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                    <h3>No products yet</h3>
                    <p>Start selling by adding your first product!</p>
                    <button onclick="openModal()" class="btn btn-primary" style="margin-top: 1.5rem;">
                        <i class="fas fa-plus"></i> Add Your First Product
                    </button>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <?php foreach ($my_products as $product): ?>
                        <div class="product-card">
                            <?php 
                            $image_src = !empty($product['image']) && file_exists($product['image']) 
                                ? htmlspecialchars($product['image']) 
                                : 'https://via.placeholder.com/400x300/2563eb/ffffff?text=No+Image';
                            ?>
                            <img src="<?php echo $image_src; ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 onerror="this.src='https://via.placeholder.com/400x300/2563eb/ffffff?text=Image+Not+Found'">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p style="color: #6b7280; font-size: 0.875rem; margin-bottom: 0.5rem;"><?php echo ucfirst(htmlspecialchars($product['category'])); ?></p>
                            <div class="price">$<?php echo number_format($product['price'], 2); ?></div>
                            <p style="color: #6b7280; font-size: 0.875rem;">Stock: <?php echo $product['stock']; ?></p>
                            <p style="color: #6b7280; font-size: 0.875rem; margin-bottom: 1rem;">Status: 
                                <span style="color: <?php echo $product['status'] === 'active' ? '#10b981' : '#ef4444'; ?>; font-weight: 600;">
                                    <?php echo ucfirst($product['status']); ?>
                                </span>
                            </p>
                            <form method="POST" onsubmit="return confirm('Are you sure you want to delete this product?');">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <button type="submit" name="delete_product" class="btn btn-danger btn-sm" style="width: 100%;">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div id="addProductModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Product</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label><i class="fas fa-tag"></i> Product Name *</label>
                    <input type="text" name="name" required placeholder="e.g., Handwoven Basket">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-align-left"></i> Description *</label>
                    <textarea name="description" required placeholder="Describe your product..."></textarea>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-list"></i> Category *</label>
                    <select name="category" required>
                        <option value="">Select Category</option>
                        <option value="pottery">Pottery & Ceramics</option>
                        <option value="textiles">Textiles & Fabrics</option>
                        <option value="jewelry">Jewelry</option>
                        <option value="woodwork">Woodwork</option>
                        <option value="art">Art & Paintings</option>
                        <option value="leather">Leather Goods</option>
                        <option value="metalwork">Metalwork</option>
                        <option value="basketry">Basketry</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-dollar-sign"></i> Price (USD) *</label>
                    <input type="number" name="price" step="0.01" min="0" required placeholder="29.99">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-cubes"></i> Stock Quantity *</label>
                    <input type="number" name="stock" min="0" required placeholder="50">
                </div>
                <div class="form-group">
                    <label><i class="fas fa-image"></i> Upload Product Image *</label>
                    <input type="file" name="product_image" accept="image/*" required 
                           style="padding: 0.75rem; border: 2px dashed #2563eb; background: #f8fafc; cursor: pointer; border-radius: 0.5rem;">
                    <small style="color: #6b7280; display: block; margin-top: 0.5rem;">
                        📁 Choose image from your computer (JPG, PNG, GIF, WEBP)
                    </small>
                    <small style="color: #10b981; display: block; margin-top: 0.25rem;">
                        ✅ Images saved to: uploads/products/
                    </small>
                </div>
                <button type="submit" name="add_product" class="btn btn-success" style="width: 100%;">
                    <i class="fas fa-plus"></i> Add Product
                </button>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('addProductModal').classList.add('active');
        }
        function closeModal() {
            document.getElementById('addProductModal').classList.remove('active');
        }
        window.onclick = function(event) {
            const modal = document.getElementById('addProductModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>