<?php
require_once 'config.php';

// Your desired credentials
$email = 'eric@gmail.com';
$password = 'eric12';
$name = 'Eric Admin';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Fix Eric Admin Password</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            padding: 3rem; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .box {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            max-width: 600px;
            margin: 0 auto;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .success { background: #d4edda; padding: 1rem; margin: 1rem 0; border-radius: 8px; color: #155724; border-left: 4px solid #28a745; }
        .error { background: #f8d7da; padding: 1rem; margin: 1rem 0; border-radius: 8px; color: #721c24; border-left: 4px solid #dc3545; }
        .info { background: #d1ecf1; padding: 1rem; margin: 1rem 0; border-radius: 8px; color: #0c5460; border-left: 4px solid #17a2b8; }
        button { 
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white; 
            padding: 1rem 2rem; 
            border: none; 
            border-radius: 8px; 
            cursor: pointer; 
            font-size: 1.1rem;
            width: 100%;
            font-weight: 600;
        }
        button:hover { opacity: 0.9; }
        h1 { color: #667eea; }
        .creds { background: #f8f9fa; padding: 1rem; border-radius: 8px; margin: 1rem 0; border: 2px solid #667eea; }
        a { color: #667eea; text-decoration: none; font-weight: 600; }
    </style>
</head>
<body>
<div class='box'>";

echo "<h1>🔧 Fix Eric Admin Password</h1>";

// Check if eric@gmail.com exists
$check_sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($check_sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if (isset($_POST['fix_password'])) {
    // Generate NEW hash on THIS system
    $new_hash = password_hash($password, PASSWORD_DEFAULT);
    
    if ($result->num_rows > 0) {
        // UPDATE existing account
        $update_sql = "UPDATE users SET password = ?, full_name = ?, user_type = 'admin', status = 'active' WHERE email = ?";
        $upd_stmt = $conn->prepare($update_sql);
        $upd_stmt->bind_param("sss", $new_hash, $name, $email);
        
        if ($upd_stmt->execute()) {
            echo "<div class='success'>";
            echo "<h2>✅ PASSWORD FIXED!</h2>";
            echo "<p>Your admin password has been updated with a hash that works on YOUR system!</p>";
            echo "</div>";
            
            // Verify it works
            $verify_sql = "SELECT * FROM users WHERE email = ?";
            $ver_stmt = $conn->prepare($verify_sql);
            $ver_stmt->bind_param("s", $email);
            $ver_stmt->execute();
            $ver_result = $ver_stmt->get_result();
            $user = $ver_result->fetch_assoc();
            
            if (password_verify($password, $user['password'])) {
                echo "<div class='success'>";
                echo "<h3>✅ VERIFIED: Password Works!</h3>";
                echo "<p>I tested it and the password 'eric12' now works correctly!</p>";
                echo "</div>";
            }
            
            echo "<div class='creds'>";
            echo "<h3>🔑 Your Login Credentials:</h3>";
            echo "<p><strong>Email:</strong> $email</p>";
            echo "<p><strong>Password:</strong> $password</p>";
            echo "</div>";
            
            echo "<a href='admin_login.php' style='display: block; text-align: center; padding: 1rem; background: #28a745; color: white; border-radius: 8px; margin-top: 1rem;'>LOGIN NOW →</a>";
            
        } else {
            echo "<div class='error'>Error updating: " . $upd_stmt->error . "</div>";
        }
    } else {
        // CREATE new account
        $insert_sql = "INSERT INTO users (full_name, email, password, user_type, status, created_at) VALUES (?, ?, ?, 'admin', 'active', NOW())";
        $ins_stmt = $conn->prepare($insert_sql);
        $ins_stmt->bind_param("sss", $name, $email, $new_hash);
        
        if ($ins_stmt->execute()) {
            echo "<div class='success'>";
            echo "<h2>✅ ACCOUNT CREATED!</h2>";
            echo "<p>Your admin account has been created with a password hash that works on YOUR system!</p>";
            echo "</div>";
            
            echo "<div class='creds'>";
            echo "<h3>🔑 Your Login Credentials:</h3>";
            echo "<p><strong>Email:</strong> $email</p>";
            echo "<p><strong>Password:</strong> $password</p>";
            echo "</div>";
            
            echo "<a href='admin_login.php' style='display: block; text-align: center; padding: 1rem; background: #28a745; color: white; border-radius: 8px; margin-top: 1rem;'>LOGIN NOW →</a>";
        } else {
            echo "<div class='error'>Error creating: " . $ins_stmt->error . "</div>";
        }
    }
    
} else {
    // Show current status
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        echo "<div class='info'>";
        echo "<h3>📋 Account Status:</h3>";
        echo "<p>✅ Account exists: <strong>$email</strong></p>";
        echo "<p>👤 Name: {$user['full_name']}</p>";
        echo "<p>🔐 User Type: {$user['user_type']}</p>";
        echo "<p>📊 Status: {$user['status']}</p>";
        echo "</div>";
        
        // Test current password
        echo "<div class='info'>";
        echo "<h3>🧪 Testing Current Password:</h3>";
        if (password_verify($password, $user['password'])) {
            echo "<div class='success'>✅ Current password works! You should be able to login.</div>";
            echo "<a href='admin_login.php'>Go to Login →</a>";
        } else {
            echo "<div class='error'>❌ Current password doesn't work (this is the problem!)</div>";
            echo "<p><strong>Solution:</strong> Click the button below to fix it.</p>";
        }
        echo "</div>";
        
    } else {
        echo "<div class='error'>";
        echo "<h3>❌ Account Not Found</h3>";
        echo "<p>No account exists for <strong>$email</strong></p>";
        echo "<p>Click the button below to create it.</p>";
        echo "</div>";
    }
    
    echo "<form method='POST'>";
    echo "<button type='submit' name='fix_password'>";
    echo $result->num_rows > 0 ? "🔧 FIX PASSWORD NOW" : "➕ CREATE ACCOUNT NOW";
    echo "</button>";
    echo "</form>";
    
    echo "<div class='info' style='margin-top: 2rem;'>";
    echo "<h3>ℹ️ What This Does:</h3>";
    echo "<ul>";
    echo "<li>Generates a NEW password hash on YOUR PHP system</li>";
    echo "<li>Updates your database with the new hash</li>";
    echo "<li>The hash will be compatible with YOUR password_verify()</li>";
    echo "<li>You'll be able to login with: <strong>$password</strong></li>";
    echo "</ul>";
    echo "</div>";
}

echo "</div></body></html>";
?>