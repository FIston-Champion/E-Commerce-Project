<?php
require_once 'config.php';

// If already logged in, redirect
if (is_logged_in()) {
    if (is_admin()) {
        redirect('admin.php');
    } elseif (is_artisan()) {
        redirect('artisan-dashboard.php');
    } else {
        redirect('index.php');
    }
}

// Language translations
$translations = [
    'en' => [
        'title' => 'Login - Artisan Market',
        'welcome_back' => 'Welcome Back',
        'login_subtitle' => 'Login to your account',
        'email' => 'Email',
        'password' => 'Password',
        'remember_me' => 'Remember me',
        'forgot_password' => 'Forgot password?',
        'login_btn' => 'Login',
        'no_account' => "Don't have an account?",
        'signup' => 'Sign up',
        'home' => 'Home',
        'products' => 'Products',
        'about' => 'About',
        'contact' => 'Contact',
        'sell_products' => 'Sell Products'
    ],
    'fr' => [
        'title' => 'Connexion - Marché Artisan',
        'welcome_back' => 'Bon Retour',
        'login_subtitle' => 'Connectez-vous à votre compte',
        'email' => 'Email',
        'password' => 'Mot de passe',
        'remember_me' => 'Se souvenir de moi',
        'forgot_password' => 'Mot de passe oublié?',
        'login_btn' => 'Se connecter',
        'no_account' => "Vous n'avez pas de compte?",
        'signup' => "S'inscrire",
        'home' => 'Accueil',
        'products' => 'Produits',
        'about' => 'À propos',
        'contact' => 'Contact',
        'sell_products' => 'Vendre des produits'
    ],
    'es' => [
        'title' => 'Iniciar sesión - Mercado Artesano',
        'welcome_back' => 'Bienvenido de nuevo',
        'login_subtitle' => 'Inicia sesión en tu cuenta',
        'email' => 'Correo electrónico',
        'password' => 'Contraseña',
        'remember_me' => 'Recuérdame',
        'forgot_password' => '¿Olvidaste tu contraseña?',
        'login_btn' => 'Iniciar sesión',
        'no_account' => '¿No tienes una cuenta?',
        'signup' => 'Registrarse',
        'home' => 'Inicio',
        'products' => 'Productos',
        'about' => 'Acerca de',
        'contact' => 'Contacto',
        'sell_products' => 'Vender productos'
    ],
    'sw' => [
        'title' => 'Ingia - Soko la Wasanii',
        'welcome_back' => 'Karibu Tena',
        'login_subtitle' => 'Ingia kwenye akaunti yako',
        'email' => 'Barua pepe',
        'password' => 'Nenosiri',
        'remember_me' => 'Nikumbuke',
        'forgot_password' => 'Umesahau nenosiri?',
        'login_btn' => 'Ingia',
        'no_account' => 'Huna akaunti?',
        'signup' => 'Jisajili',
        'home' => 'Nyumbani',
        'products' => 'Bidhaa',
        'about' => 'Kuhusu',
        'contact' => 'Wasiliana',
        'sell_products' => 'Uza Bidhaa'
    ],
    'rw' => [
        'title' => 'Kwinjira - Isoko ry\'Abakoranabuhanga',
        'welcome_back' => 'Murakaza Neza',
        'login_subtitle' => 'Injira muri konti yawe',
        'email' => 'Imeri',
        'password' => 'Ijambo ry\'ibanga',
        'remember_me' => 'Nyibuke',
        'forgot_password' => 'Wibagiwe ijambo ry\'ibanga?',
        'login_btn' => 'Injira',
        'no_account' => 'Nta konti ufite?',
        'signup' => 'Iyandikishe',
        'home' => 'Ahabanza',
        'products' => 'Ibicuruzwa',
        'about' => 'Aho dukomoka',
        'contact' => 'Duhamagare',
        'sell_products' => 'Gura Ibicuruzwa'
    ]
];

// Get current language
$lang = isset($_SESSION['lang']) ? $_SESSION['lang'] : 'en';
if (isset($_GET['lang']) && array_key_exists($_GET['lang'], $translations)) {
    $lang = $_GET['lang'];
    $_SESSION['lang'] = $lang;
}
$t = $translations[$lang];

$error = '';
$success = '';

// Handle login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = clean_input($_POST['email']);
    $password = $_POST['password']; // Don't clean password, will verify with hash
    
    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        // Query database for user
        $sql = "SELECT * FROM users WHERE email = ? AND status = 'active'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Verify password
            if (password_verify($password, $user['password'])) {
                // Login successful - set session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['user_name'] = $user['full_name'];
                $_SESSION['user_type'] = $user['user_type'];
                $_SESSION['logged_in'] = true;
                
                // Update last login
                $update_sql = "UPDATE users SET last_login = NOW() WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("i", $user['id']);
                $update_stmt->execute();
                
                // Remember me functionality
                if (isset($_POST['remember'])) {
                    setcookie('remember_user', $user['id'], time() + (86400 * 30), "/"); // 30 days
                }
                
                // Redirect based on user type
                if ($user['user_type'] === 'admin') {
                    redirect('admin.php');
                } elseif ($user['user_type'] === 'artisan') {
                    redirect('artisan-dashboard.php');
                } else {
                    redirect('index.php');
                }
            } else {
                $error = "Invalid email or password!";
            }
        } else {
            $error = "Invalid email or password!";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $t['title']; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        :root {
            --primary-color: #2563eb; --secondary-color: #7c3aed; --success-color: #10b981;
            --danger-color: #ef4444; --dark-color: #1f2937; --light-color: #f3f4f6;
            --white: #ffffff; --border-color: #e5e7eb; --text-color: #374151;
            --text-light: #6b7280; --shadow: 0 4px 6px rgba(0,0,0,0.1); --shadow-lg: 0 10px 25px rgba(0,0,0,0.15);
        }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; color: var(--text-color); background-color: var(--white); }
        .container { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .navbar { background-color: var(--white); box-shadow: var(--shadow); position: sticky; top: 0; z-index: 1000; }
        .nav-wrapper { display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; }
        .logo { display: flex; align-items: center; gap: 0.5rem; font-size: 1.5rem; font-weight: 700; color: var(--primary-color); text-decoration: none; }
        .logo i { font-size: 1.75rem; }
        .nav-links { display: flex; list-style: none; gap: 2rem; }
        .nav-links a { color: var(--text-color); font-weight: 500; transition: color 0.3s ease; text-decoration: none; }
        .nav-links a:hover { color: var(--primary-color); }
        .nav-actions { display: flex; align-items: center; gap: 1.5rem; }
        .btn { display: inline-block; padding: 0.75rem 1.5rem; border: none; border-radius: 0.5rem; font-size: 1rem; font-weight: 500; cursor: pointer; transition: all 0.3s ease; text-decoration: none; }
        .btn-primary { background-color: var(--primary-color); color: var(--white); }
        .btn-primary:hover { background-color: #1d4ed8; }
        .btn-sm { padding: 0.5rem 1rem; font-size: 0.875rem; }
        .btn-block { width: 100%; }
        .btn-lg { padding: 1rem 2rem; font-size: 1.125rem; }
        .lang-selector { position: relative; }
        .lang-btn { background: none; border: 2px solid var(--border-color); padding: 0.5rem 1rem; border-radius: 0.5rem; cursor: pointer; display: flex; align-items: center; gap: 0.5rem; color: var(--text-color); font-weight: 500; }
        .lang-dropdown { position: absolute; top: 100%; right: 0; margin-top: 0.5rem; background-color: var(--white); border-radius: 0.5rem; box-shadow: var(--shadow-lg); display: none; min-width: 150px; z-index: 1000; }
        .lang-dropdown.active { display: block; }
        .lang-dropdown a { display: block; padding: 0.75rem 1rem; color: var(--text-color); text-decoration: none; transition: background-color 0.3s ease; }
        .lang-dropdown a:hover { background-color: var(--light-color); }
        .auth-section { padding: 4rem 0; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); min-height: calc(100vh - 80px); }
        .auth-card { max-width: 500px; margin: 0 auto; background-color: var(--white); border-radius: 1rem; padding: 2.5rem; box-shadow: var(--shadow-lg); }
        .auth-header { text-align: center; margin-bottom: 2rem; }
        .auth-header i { font-size: 4rem; color: var(--primary-color); margin-bottom: 1rem; }
        .auth-header h2 { font-size: 2rem; margin-bottom: 0.5rem; color: var(--dark-color); }
        .auth-header p { color: var(--text-light); }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; color: var(--dark-color); font-weight: 500; }
        .form-group input { width: 100%; padding: 0.875rem; border: 2px solid var(--border-color); border-radius: 0.5rem; font-size: 1rem; transition: border-color 0.3s ease; }
        .form-group input:focus { outline: none; border-color: var(--primary-color); }
        .form-options { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 0.5rem; }
        .checkbox-label { display: flex; align-items: center; gap: 0.5rem; cursor: pointer; color: var(--text-color); }
        .link { color: var(--primary-color); text-decoration: none; font-weight: 500; }
        .link:hover { text-decoration: underline; }
        .auth-footer { text-align: center; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid var(--border-color); }
        .alert { padding: 1rem; border-radius: 0.5rem; margin-bottom: 1.5rem; }
        .alert-error { background-color: #fee2e2; border-left: 4px solid var(--danger-color); color: var(--danger-color); }
        .alert-success { background-color: #dcfce7; border-left: 4px solid var(--success-color); color: var(--success-color); }
        @media (max-width: 768px) { .nav-links { display: none; } .auth-card { padding: 1.5rem; } }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="nav-wrapper">
                <a href="index.php" class="logo"><i class="fas fa-store"></i><span>Artisan Market</span></a>
                <ul class="nav-links">
                    <li><a href="index.php"><?php echo $t['home']; ?></a></li>
                    <li><a href="products.php"><?php echo $t['products']; ?></a></li>
                    <li><a href="about.php"><?php echo $t['about']; ?></a></li>
                    <li><a href="contact.php"><?php echo $t['contact']; ?></a></li>
                </ul>
                <div class="nav-actions">
                    <div class="lang-selector">
                        <button class="lang-btn" onclick="toggleLangDropdown()">
                            <i class="fas fa-globe"></i><span><?php echo strtoupper($lang); ?></span><i class="fas fa-chevron-down"></i>
                        </button>
                        <div class="lang-dropdown" id="langDropdown">
                            <a href="?lang=en">English</a>
                            <a href="?lang=fr">Français</a>
                            <a href="?lang=es">Español</a>
                            <a href="?lang=sw">Kiswahili</a>
                            <a href="?lang=rw">Kinyarwanda</a>
                        </div>
                    </div>
                    <a href="register.php" class="btn btn-primary btn-sm"><?php echo $t['sell_products']; ?></a>
                </div>
            </div>
        </div>
    </nav>

    <section class="auth-section">
        <div class="container">
            <div class="auth-card">
                <div class="auth-header">
                    <i class="fas fa-user-circle"></i>
                    <h2><?php echo $t['welcome_back']; ?></h2>
                    <p><?php echo $t['login_subtitle']; ?></p>
                </div>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($success)): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="form-group">
                        <label><?php echo $t['email']; ?></label>
                        <input type="email" name="email" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>

                    <div class="form-group">
                        <label><?php echo $t['password']; ?></label>
                        <input type="password" name="password" required>
                    </div>

                    <div class="form-options">
                        <label class="checkbox-label">
                            <input type="checkbox" name="remember">
                            <span><?php echo $t['remember_me']; ?></span>
                        </label>
                        <a href="#" class="link"><?php echo $t['forgot_password']; ?></a>
                    </div>

                    <button type="submit" name="login" class="btn btn-primary btn-block btn-lg">
                        <i class="fas fa-sign-in-alt"></i> <?php echo $t['login_btn']; ?>
                    </button>
                </form>

                <div class="auth-footer">
                    <p><?php echo $t['no_account']; ?> <a href="register.php" class="link"><?php echo $t['signup']; ?></a></p>
                </div>
            </div>
        </div>
    </section>

    <script>
        function toggleLangDropdown() {
            document.getElementById('langDropdown').classList.toggle('active');
        }
        document.addEventListener('click', function(event) {
            const langSelector = document.querySelector('.lang-selector');
            if (!langSelector.contains(event.target)) {
                document.getElementById('langDropdown').classList.remove('active');
            }
        });
    </script>
</body>
</html>